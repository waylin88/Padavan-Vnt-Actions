#!/bin/sh
# 自动重启检查脚本（More 页 → 自动重启）
#
# 由 crond 每分钟调用一次（见 rc.c init_crontab）：
#   当天星期在 sched_reboot_days 中且命中 sched_reboot_time 指定的时刻则重启设备。
#
# 配置项（NVRAM）：
#   sched_reboot_enable  0/1
#   sched_reboot_time    HH:MM（由 web 后端统一格式化为两位补零）
#   sched_reboot_days    7 位位图，依次为 周日..周六（由 web 后端校验，异常回退 1111111）

NVRAM=/usr/sbin/nvram

[ -x "$NVRAM" ] || NVRAM=/bin/nvram

[ "$($NVRAM get sched_reboot_enable)" = "1" ] || exit 0

# 星期位图：长度异常时按「每天」处理，与 web 后端保持一致
days=$($NVRAM get sched_reboot_days)
[ ${#days} -eq 7 ] || days=1111111

# date +%w：0=周日 .. 6=周六，正好对应位图下标
if [ "$(echo "$days" | cut -c$(( $(date +%w) + 1 )))" != "1" ]; then
	exit 0
fi

want=$($NVRAM get sched_reboot_time)
now=$(date +%H:%M)

# 时间格式为两位补零的 HH:MM，字符串比较即可
[ "$want" = "$now" ] || exit 0

# 同一分钟内只触发一次（防止重启被延迟/失败时反复触发）
mark=/tmp/sched_reboot.stamp
stamp=$(date +%Y%m%d%H%M)
if [ "$(cat $mark 2>/dev/null)" = "$stamp" ]; then
	exit 0
fi
echo "$stamp" > $mark

logger -t sched_reboot "auto reboot at $now"

sync
/sbin/reboot
exit 0
