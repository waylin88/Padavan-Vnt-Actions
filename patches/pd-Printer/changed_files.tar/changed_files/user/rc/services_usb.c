/*
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of
 * the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 * MA 02111-1307 USA
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <signal.h>
#include <unistd.h>
#include <errno.h>
#include <time.h>
#include <dirent.h>
#include <syslog.h>
#include <sys/fcntl.h>
#include <sys/vfs.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/stat.h>
#include <sys/mount.h>
#include <sys/ioctl.h>
#include <net/ethernet.h>
#include <linux/cdrom.h>
#include <scsi/scsi.h>
#include <scsi/scsi_ioctl.h>

#include <dev_info.h>
#include <usb_info.h>
#include <disk_initial.h>
#include <disk_share.h>

#include "rc.h"
#include "printer_table.h"
#include "switch.h"
#include "gpio_pins.h"

void
safe_remove_usb_device(int port, const char *dev_name)
{
	int modem_devnum = 0;

	if (dev_name && strncmp(dev_name, "sd", 2) != 0) {
		modem_devnum = atoi(dev_name);
		if (modem_devnum < 0)
			modem_devnum = 0;
	}

	if (port >= 1 && port <= BOARD_NUM_USB_PORTS) {
		if (modem_devnum) {
			usb_info_t *usb_info, *follow_usb;
			int has_modem_port = 0;
			
			usb_info = get_usb_info();
			for (follow_usb = usb_info; follow_usb != NULL; follow_usb = follow_usb->next) {
				if ((follow_usb->port_root == port) &&
				    (follow_usb->id_devnum == modem_devnum) &&
				    (follow_usb->dev_type == DEVICE_TYPE_MODEM_TTY ||
				     follow_usb->dev_type == DEVICE_TYPE_MODEM_ETH))
					has_modem_port |= 1;
			}
			free_usb_info(usb_info);
			
			if (has_modem_port) {
				if ( get_usb_modem_dev_wan(0, modem_devnum) ) {
					safe_remove_usb_modem();
					try_wan_reconnect(0, 0);
				}
			}
		} else {
			safe_remove_stor_device(port, port, dev_name, 1);
		}
		
	} else if (port == 0) {
		safe_remove_stor_device(1, BOARD_NUM_USB_PORTS, NULL, 1);
	}
}

#if defined (BOARD_GPIO_PWR_USB) || defined (BOARD_GPIO_PWR_USB2)
void
power_control_usb_port(int port, int power_on)
{
	unsigned int pin_power_1 = (BOARD_GPIO_PWR_USB_ON != 0) ? 1 : 0;
	unsigned int pin_power_0 = (BOARD_GPIO_PWR_USB_ON != 0) ? 0 : 1;
	unsigned int pin_power = (power_on) ? pin_power_1 : pin_power_0;

#if defined (BOARD_GPIO_PWR_USB)
	if (port == 0 || port == 1)
		cpu_gpio_set_pin(BOARD_GPIO_PWR_USB, pin_power);
#endif
#if defined (BOARD_GPIO_PWR_USB2)
	if (port == 0 || port == 2)
		cpu_gpio_set_pin(BOARD_GPIO_PWR_USB2, pin_power);
#endif
}
#endif

/* PRINTER_MAX_PORTS is defined in rc.h */

/* The physical USB port -> data-port offset mapping lives in
 * printer_table.c (printer_uid_by_devname / printer_offset_by_devname),
 * shared with the hotplug helper and printerd so that starting and
 * stopping a spooler can never pick different ports. */

/* ------------------------------------------------------------------ *
 * HP "SIHP" printers (LaserJet 1000/1005/1018/1020/P1005/P1006/P1007/ *
 * P1008/P1505) are "soft" printers: they must have their firmware      *
 * re-uploaded on every plug before they can accept print jobs.         *
 * The blobs live in the read-only rootfs (/etc_ro/hp).                 *
 * ------------------------------------------------------------------ */
#define HP_FW_DIR	"/etc_ro/hp"
#define HP_USB_VID	"03f0"

static const struct {
	const char *pid;
	const char *file;
} hp_firmware_map[] = {
	{ "0517", "sihp1000.dl"  },
	{ "1317", "sihp1005.dl"  },
	{ "4117", "sihp1018.dl"  },
	{ "2b17", "sihp1020.dl"  },
	{ "3d17", "sihpP1005.dl" },
	{ "3e17", "sihpP1006.dl" },
	{ "4817", "sihpP1007.dl" },
	{ "4917", "sihpP1008.dl" },
	{ "3f17", "sihpP1505.dl" },
	{ NULL,   NULL           },
};

static int
hp_dump_firmware(const char *src, const char *dev)
{
	char buf[4096];
	int ifd, ofd, ret = -1;
	ssize_t n, off;

	ifd = open(src, O_RDONLY);
	if (ifd < 0)
		return -1;

	ofd = open(dev, O_WRONLY);
	if (ofd < 0) {
		close(ifd);
		return -1;
	}

	while ((n = read(ifd, buf, sizeof(buf))) > 0) {
		for (off = 0; off < n; ) {
			ssize_t w = write(ofd, buf + off, n - off);
			if (w < 0) {
				if (errno == EINTR)
					continue;
				goto out;
			}
			off += w;
		}
	}
	if (n < 0)
		goto out;

	fsync(ofd);
	ret = 0;

out:
	close(ofd);
	close(ifd);
	return ret;
}

/*
 * Upload the matching HP firmware blob to a freshly plugged printer.
 * devname is the lp node name without directory (e.g. "lp0"); it is
 * mapped to /dev/usb/lpN, where N is the kernel enumeration index.
 */
void
hp_printer_upload_firmware(const char *devname)
{
	char port_id[64], vid[16], pid[16];
	char dev[64], src[128];
	const char *file = NULL;
	int i;

	if (!devname || strncmp(devname, "lp", 2) != 0)
		return;

	/* resolve physical port -> VID/PID from sysfs */
	if (!get_usb_port_by_device(devname, port_id, sizeof(port_id)))
		return;
	if (!get_usb_vid(port_id, vid, sizeof(vid)) ||
	    !get_usb_pid(port_id, pid, sizeof(pid)))
		return;

	if (strcasecmp(vid, HP_USB_VID) != 0)
		return;

	for (i = 0; hp_firmware_map[i].pid != NULL; i++) {
		if (strcasecmp(pid, hp_firmware_map[i].pid) == 0) {
			file = hp_firmware_map[i].file;
			break;
		}
	}

	if (file == NULL) {
		logmessage(LOGNAME, "HP printer %s (PID %s) has no firmware blob", devname, pid);
		return;
	}

	snprintf(dev, sizeof(dev), "/dev/usb/%s", devname);
	snprintf(src, sizeof(src), HP_FW_DIR "/%s", file);

	if (access(src, R_OK) != 0) {
		logmessage(LOGNAME, "HP firmware %s not found", src);
		return;
	}

	if (hp_dump_firmware(src, dev) == 0)
		logmessage(LOGNAME, "HP firmware %s uploaded to %s", file, dev);
	else
		logmessage(LOGNAME, "HP firmware %s upload to %s failed", src, dev);
}

static void kill_p910nd_pidfile(int offset);

void
start_p910nd(char *devlp)
{
	char offset_str[8];
	char nvkey[16];
	const char *devname;
	int uid, offset;

	/* rawd_enable: 0 = print server disabled (global master switch) */
	if (nvram_match("rawd_enable", "0")) 
		return;

	devname = strrchr(devlp, '/');
	devname = devname ? devname + 1 : devlp;

	uid = printer_uid_by_devname(devname);
	offset = printer_offset_by_devname(devname);

	/* if a stale daemon still holds this data port, drop it first */
	kill_p910nd_pidfile(offset);

	snprintf(offset_str, sizeof(offset_str), "%d", offset);

	/* bidirectional mode is per physical port: lp_bidir<uid> */
	snprintf(nvkey, sizeof(nvkey), "lp_bidir%d", uid);
	if (nvram_get_int(nvkey))
		eval("/usr/sbin/p910nd", "-b", "-f", devlp, offset_str);
	else
		eval("/usr/sbin/p910nd", "-f", devlp, offset_str);

	/* let printerd rescan sysfs and re-advertise the whole set */
	printerd_reload();
}

/*
 * Stop one p910nd daemon through its PID file (/var/run/p910<N>d.pid).
 *
 * Killing by pid file instead of by process name ("p910nd" vs the
 * "p9100d".."p9103d" names p910nd advertises) always targets the exact
 * spooler of that data port, which is what makes a fast unplug/replug of
 * a printer reliable.
 */
static void
kill_p910nd_pidfile(int offset)
{
	char pidfile[32];
	char buf[32];
	FILE *fp;
	int pid;

	snprintf(pidfile, sizeof(pidfile), "/var/run/p910%dd.pid", offset);

	fp = fopen(pidfile, "r");
	if (!fp)
		return;

	pid = 0;
	if (fgets(buf, sizeof(buf), fp))
		pid = atoi(buf);
	fclose(fp);

	if (pid > 0) {
		kill(pid, SIGTERM);
		usleep(60000);
		kill(pid, SIGKILL);
	}

	unlink(pidfile);
}

/*
 * mDNS / DNS-SD and SNMP discovery are handled by printerd, which reads
 * the same live printer table as the web status page.  The spooler code
 * only has to signal it after a plug/unplug.
 */

void
stop_p910nd(void)
{
	int i;

	for (i = 0; i < PRINTER_MAX_PORTS; i++)
		kill_p910nd_pidfile(i);

	printerd_reload();
}

/*
 * Stop the p910nd daemon bound to a single data port. Used on unplug so
 * that only the removed printer is affected: the other printers keep
 * their spooler (and any job in progress) untouched, with no delay.
 */
void
stop_printer_spooler(int offset)
{
	if (offset < 0 || offset >= PRINTER_MAX_PORTS)
		return;

	kill_p910nd_pidfile(offset);
	printerd_reload();
}

static void
exec_printer_daemons(void)
{
	int i;
	char dev_lp[16];

	for (i = 0; i < 10; i++) {
		sprintf(dev_lp, "/dev/usb/lp%d", i);
		if (check_if_dev_exist(dev_lp))
			start_p910nd(dev_lp);
	}
}

void
stop_usb_printer_spoolers(void)
{
	stop_p910nd();
}

void
restart_usb_printer_spoolers(void)
{
	stop_usb_printer_spoolers();
	exec_printer_daemons();
}

void
try_start_usb_printer_spoolers(void)
{
	stop_usb_printer_spoolers();
	exec_printer_daemons();
}

/*
 * printerd: single process answering both mDNS (5353) and SNMP (161).
 * It owns no printer state of its own - every announcement is rebuilt
 * from sysfs - so it only needs to be started once at boot and kept
 * alive by the watchdog.
 */
void
start_printerd(void)
{
	char *argv[2];
	pid_t pid;

	if (pids("printerd"))
		return;

	argv[0] = "/sbin/printerd";
	argv[1] = NULL;
	_eval(argv, ">/dev/null", 0, &pid);
}

void
stop_printerd(void)
{
	char *svcs[] = { "printerd", NULL };

	kill_services(svcs, 3, 1);
	unlink("/var/run/printerd.pid");
}

void
try_start_usb_modem_to_wan(void)
{
	int modem_prio, has_link;

	if (get_ap_mode())
		return;

	/* check modem prio mode  */
	modem_prio = nvram_get_int("modem_prio");
	if (modem_prio < 1)
		return;

	/* check modem already selected to WAN */
	if (get_usb_modem_wan(0))
		return;

	/* check modem enabled and ready */
	if (!get_modem_devnum())
		return;

	if (modem_prio == 2) {
		if (get_apcli_wisp_ifname())
			return;
		
		has_link = get_wan_ether_link_direct(0);
		if (has_link < 0)
			has_link = 0;
		
		if (has_link)
			return;
	}

	logmessage("USB hotplug", "try start USB Modem as WAN connection...");

	try_wan_reconnect(1, 0);
}

