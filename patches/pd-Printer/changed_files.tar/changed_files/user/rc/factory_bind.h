#ifndef _FACTORY_BIND_H_
#define _FACTORY_BIND_H_

/*
 * Flash UID binding.
 *
 * The record lives in the "Factory" MTD partition at FAC_REC_OFFSET:
 *
 *   off  size  field
 *   0    4     magic (see fac_mg[], binary blob)
 *   4    1     version (1)
 *   5    1     flags (0)
 *   6    8     flash unique id, as read from /proc/<kernel id node>
 *   14   2     reserved (0)
 *   16   256   RSA-2048 signature of bytes [0, FAC_REC_SIGNED)
 *
 * The signature is produced by the vendor private key.  Only the public key
 * is compiled into the firmware, so a dumped image cannot be used to re-sign
 * a record for another chip.
 */

#define FAC_REC_OFFSET		0x1000
#define FAC_REC_SIZE		272
#define FAC_REC_SIGNED		16
#define FAC_SIG_SIZE		256	/* RSA-2048 */
#define FAC_REC_VER		1

/* record magic, kept as bytes so it never shows up as a string */
extern const unsigned char fac_mg[4];

/* returned by factory_bind_status() */
#define FAC_ST_OK		0
#define FAC_ST_UNBOUND		1	/* no valid record */
#define FAC_ST_MISMATCH		2	/* record exists but is not for this chip */
#define FAC_ST_NO_UID		3	/* kernel id node missing or unreadable */

/* 0 on success, -1 when the kernel does not expose the id node */
int factory_bind_read_uid(unsigned char uid[8]);

/* status of the record currently stored in Factory */
int factory_bind_status(void);

/* verify an externally supplied record against the running chip */
int factory_bind_verify(const unsigned char *rec);

/* verify then persist; returns 0 on success */
int factory_bind_write(const unsigned char *rec);

/* verify an arbitrary message/signature pair with the firmware public key */
int factory_bind_verify_blob(const unsigned char *msg, int len,
				const unsigned char *sig);

/* target selector for factory_bind_write_mac() */
#define FAC_MAC_LAN		0
#define FAC_MAC_WAN		1
#define FAC_MAC_2G		2
#define FAC_MAC_5G		3

/* write LAN / WAN / 2.4GHz / 5GHz MAC to Factory; 0 on success */
int factory_bind_write_mac(int target, const unsigned char mac[6]);

#endif
