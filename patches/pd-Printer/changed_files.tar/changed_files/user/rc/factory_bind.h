#ifndef _FACTORY_BIND_H_
#define _FACTORY_BIND_H_

/*
 * Flash UID binding.
 *
 * The record lives in the "Factory" MTD partition at FAC_REC_OFFSET:
 *
 *   off  size  field
 *   0    4     magic "FBND"
 *   4    1     version (1)
 *   5    1     flags (0)
 *   6    8     flash unique id, little endian as read from /proc/flash_uid
 *   14   2     reserved (0)
 *   16   256   RSA-2048 signature of bytes [0, FAC_REC_SIGNED)
 *
 * The signature is produced by the vendor private key.  Only the public key
 * is compiled into the firmware, so a dumped image cannot be used to re-sign
 * a record for another chip.
 */

#define FAC_REC_OFFSET		0x1000
#define FAC_REC_SIZE		272
#define FAC_REC_SIGNED		16
#define FAC_SIG_SIZE		256	/* RSA-2048 */
#define FAC_REC_MAGIC		"FBND"
#define FAC_REC_VER		1

/* returned by factory_bind_status() */
#define FAC_ST_OK		0
#define FAC_ST_UNBOUND		1	/* no valid record */
#define FAC_ST_MISMATCH		2	/* record exists but is not for this chip */
#define FAC_ST_NO_UID		3	/* /proc/flash_uid missing or unreadable */

/* 0 on success, -1 when the kernel does not expose /proc/flash_uid */
int factory_bind_read_uid(unsigned char uid[8]);

/* status of the record currently stored in Factory */
int factory_bind_status(void);

/* verify an externally supplied record against the running chip */
int factory_bind_verify(const unsigned char *rec);

/* verify then persist; returns 0 on success */
int factory_bind_write(const unsigned char *rec);

/* verify an arbitrary message/signature pair with the firmware public key */
int factory_bind_verify_blob(const unsigned char *msg, int len,
				const unsigned char *sig);

/* write LAN (is_wan = 0) or WAN (is_wan = 1) MAC to Factory; 0 on success */
int factory_bind_write_mac(int is_wan, const unsigned char mac[6]);

#endif
