#ifndef _FACTORY_UID_H_
#define _FACTORY_UID_H_

/* Called once at boot, after the rw filesystem is mounted and before any
 * network/print service is started.  Fills the restricted flag and spawns
 * the maintenance listener. */
void factory_uid_init(void);

/* 1 when the running firmware is not bound to this flash chip */
int factory_uid_restricted(void);

/* maintenance listener (UDP 8899, LAN only) */
void factory_maint_start(void);

#endif
