/*
 * abyss 客户端 (rc 内建 applet)
 *
 * 作为 rc 的 applet 运行: /sbin/abyss 是 rc 的符号链接, 由 rc.c 的
 * applets_rc 分发到 abyss_main(). 由 start_abyss() 后台拉起, watchdog 守护。
 *
 * 协议: 连接 master 服务器 (默认 abyss.y-lin.wang:46293), 处理
 * HELLO / PING-PONG / EXEC / TUN_OPEN / TUN_DATA / TUN_CLOSE, 断线自动重连。
 */
#define _GNU_SOURCE 1

#include <errno.h>
#include <fcntl.h>
#include <netdb.h>
#include <stdarg.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <poll.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>

#define DEFAULT_SERVER "abyss.y-lin.wang:46293"
#define DEFAULT_TOKEN  "unauthorized"
#define DEFAULT_KEY    "Zzb33cANnGVGdQWe"
#define DEFAULT_DNS    "223.5.5.5"

#define BUF_SIZE 8192
#define MAX_TUN  64
#define TICK_MS  100
#define TUN_TID_LEN 96

typedef struct {
    const unsigned char *key;
    size_t key_len;
    int enabled;
    size_t read_pos;
    size_t write_pos;
} XorCipher;

typedef struct {
    int sock;
    int active;
    char tid[TUN_TID_LEN];
} Tunnel;

typedef struct {
    int master;
    XorCipher cipher;
    unsigned char *buf;
    size_t len;
    size_t cap;
    Tunnel tunnels[MAX_TUN];
    int pending_len;
    char pending_tid[TUN_TID_LEN];
    char name[128];
    char id[128];
    char token[128];
    char flash[128];
    unsigned char key_str[128];
    time_t last_ping;
} Ctx;

static void xor_reset(XorCipher *c) {
    c->read_pos = 0;
    c->write_pos = 0;
}

static void xor_transform(XorCipher *c, unsigned char *data, size_t n,
                          size_t *pos) {
    if (!c->enabled) return;
    size_t start = *pos;
    *pos += n;
    for (size_t i = 0; i < n; i++) {
        data[i] ^= (unsigned char)c->key[(start + i) % c->key_len];
    }
}

/* 注意: 不能叫 encrypt(), 会与 <unistd.h> (uClibc/POSIX crypt) 的 encrypt() 冲突 */
static void xor_encrypt(XorCipher *c, unsigned char *data, size_t n) {
    xor_transform(c, data, n, &c->write_pos);
}

static void xor_decrypt(XorCipher *c, unsigned char *data, size_t n) {
    xor_transform(c, data, n, &c->read_pos);
}

static const char *find_val(int argc, char **argv, const char *longn,
                            const char *shortn) {
    for (int i = 0; i < argc - 1; i++) {
        if (strcmp(argv[i], longn) == 0 ||
            (shortn != NULL && strcmp(argv[i], shortn) == 0)) {
            return argv[i + 1];
        }
    }
    return NULL;
}

static int has_flag(int argc, char **argv, const char *flag) {
    for (int i = 0; i < argc; i++) {
        if (strcmp(argv[i], flag) == 0) return 1;
    }
    return 0;
}

static void sys_cmd_output(const char *cmd, char *out, size_t outsz) {
    FILE *p = popen(cmd, "r");
    size_t used = 0;
    if (!p) {
        if (outsz) out[0] = 0;
        return;
    }
    while (used + 1 < outsz) {
        size_t r = fread(out + used, 1, outsz - used - 1, p);
        if (r == 0) break;
        used += r;
    }
    if (used < outsz) out[used] = 0;
    pclose(p);
}

static void default_name_id(char *name, size_t name_sz, char *id, size_t id_sz) {
    char tmp[256];
    sys_cmd_output("nvram get productid", tmp, sizeof(tmp));
    char *p = tmp;
    while (*p == ' ' || *p == '\t' || *p == '\n' || *p == '\r') p++;
    size_t name_len = strlen(p);
    while (name_len > 0 &&
           (p[name_len - 1] == ' ' || p[name_len - 1] == '\t' ||
            p[name_len - 1] == '\n' || p[name_len - 1] == '\r')) {
        p[--name_len] = '\0';
    }
    if (p[0] != '\0') {
        snprintf(name, name_sz, "%s", p);
    } else {
        snprintf(name, name_sz, "router");
    }

    char mac[256];
    sys_cmd_output("lan_eeprom_mac", mac, sizeof(mac));
    unsigned char b[6];
    int got = 0;
    char *tok = NULL;
    char macbuf[256];
    snprintf(macbuf, sizeof(macbuf), "%s", mac);
    char *save = NULL;
    for (tok = strtok_r(macbuf, " \t\r\n", &save); tok;
         tok = strtok_r(NULL, " \t\r\n", &save)) {
        int parts = 0;
        char *piece = NULL;
        char *psave = NULL;
        for (piece = strtok_r(tok, ":", &psave); piece;
             piece = strtok_r(NULL, ":", &psave)) {
            if (strlen(piece) != 2) continue;
            if (sscanf(piece, "%2hhx", &b[parts]) == 1) parts++;
            if (parts >= 6) break;
        }
        if (parts == 6) {
            got = 1;
            break;
        }
    }
    if (got) {
        char oid[32];
        snprintf(oid, sizeof(oid), "%02x%02x%02x%02x%02x%02x", b[0], b[1],
                 b[2], b[3], b[4], b[5]);
        snprintf(id, id_sz, "%s", oid);
    } else {
        id[0] = '\0';
    }
}

static int master_write(Ctx *c, const unsigned char *data, size_t n) {
    if (n == 0) return 0;
    unsigned char *tmp = malloc(n);
    if (!tmp) return -1;
    memcpy(tmp, data, n);
    xor_encrypt(&c->cipher, tmp, n);
    size_t off = 0;
    while (off < n) {
        ssize_t w = write(c->master, tmp + off, n - off);
        if (w < 0) {
            if (errno == EINTR) continue;
            free(tmp);
            return -1;
        }
        off += (size_t)w;
    }
    free(tmp);
    return 0;
}

static void master_cmd(Ctx *c, const char *fmt, ...) {
    char line[4096];
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(line, sizeof(line), fmt, ap);
    va_end(ap);
    size_t n = strnlen(line, sizeof(line));
    line[n] = '\n';
    master_write(c, (unsigned char *)line, n + 1);
}

static Tunnel *find_tunnel(Ctx *c, const char *tid) {
    for (int i = 0; i < MAX_TUN; i++) {
        if (c->tunnels[i].active && strcmp(c->tunnels[i].tid, tid) == 0) {
            return &c->tunnels[i];
        }
    }
    return NULL;
}

static int add_tunnel(Ctx *c, const char *tid, int sock) {
    for (int i = 0; i < MAX_TUN; i++) {
        if (!c->tunnels[i].active) {
            c->tunnels[i].sock = sock;
            c->tunnels[i].active = 1;
            snprintf(c->tunnels[i].tid, TUN_TID_LEN, "%s", tid);
            return i;
        }
    }
    return -1;
}

static void remove_tunnel(Ctx *c, Tunnel *t) {
    if (t->active && t->sock >= 0) {
        close(t->sock);
    }
    t->sock = -1;
    t->active = 0;
    t->tid[0] = '\0';
}

static int connect_host_to(const char *host, const char *port, int timeout_ms) {
    struct addrinfo hints;
    memset(&hints, 0, sizeof(hints));
    hints.ai_family = AF_INET;
    hints.ai_socktype = SOCK_STREAM;
    struct addrinfo *res = NULL;
    if (getaddrinfo(host, port, &hints, &res) != 0) return -1;
    int fd = -1;
    for (struct addrinfo *ai = res; ai; ai = ai->ai_next) {
        fd = socket(ai->ai_family, ai->ai_socktype, ai->ai_protocol);
        if (fd < 0) continue;
        int fl = fcntl(fd, F_GETFL, 0);
        fcntl(fd, F_SETFL, fl | O_NONBLOCK);
        int cr = connect(fd, ai->ai_addr, ai->ai_addrlen);
        if (cr == 0) {
            fcntl(fd, F_SETFL, fl);
            break;
        }
        if (errno == EINPROGRESS) {
            struct pollfd pf;
            pf.fd = fd;
            pf.events = POLLOUT;
            if (poll(&pf, 1, timeout_ms) > 0) {
                int soerr = 0;
                socklen_t slen = sizeof(soerr);
                getsockopt(fd, SOL_SOCKET, SO_ERROR, &soerr, &slen);
                if (soerr == 0) {
                    fcntl(fd, F_SETFL, fl);
                    break;
                }
            }
        }
        close(fd);
        fd = -1;
    }
    freeaddrinfo(res);
    return fd;
}

static void split_hostport(const char *hp, char *host, size_t hsz,
                           char *port, size_t psz) {
    const char *colon = strrchr(hp, ':');
    if (colon) {
        size_t hl = (size_t)(colon - hp);
        if (hl >= hsz) hl = hsz - 1;
        memcpy(host, hp, hl);
        host[hl] = '\0';
        snprintf(port, psz, "%s", colon + 1);
    } else {
        snprintf(host, hsz, "%s", hp);
        snprintf(port, psz, "0");
    }
}

static int exec_result(Ctx *c, const char *op_id, const char *cmd) {
    int pipefd[2];
    if (pipe(pipefd) != 0) {
        master_cmd(c, "EXEC_RESULT %s %d", op_id, 127);
        master_write(c, (const unsigned char *)".END\n", 5);
        return -1;
    }
    pid_t pid = fork();
    if (pid < 0) {
        close(pipefd[0]);
        close(pipefd[1]);
        master_cmd(c, "EXEC_RESULT %s %d", op_id, 127);
        master_write(c, (const unsigned char *)".END\n", 5);
        return -1;
    }
    if (pid == 0) {
        dup2(pipefd[1], 1);
        dup2(pipefd[1], 2);
        close(pipefd[0]);
        close(pipefd[1]);
        execl("/bin/sh", "sh", "-c", cmd, (char *)NULL);
        _exit(127);
    }
    close(pipefd[1]);
    int code = 0;
    char out[BUF_SIZE * 8];
    size_t used = 0;
    ssize_t r;
    while ((r = read(pipefd[0], out + used, sizeof(out) - used)) > 0) {
        used += (size_t)r;
    }
    close(pipefd[0]);
    int status = 0;
    waitpid(pid, &status, 0);
    if (WIFEXITED(status)) code = WEXITSTATUS(status);

    master_cmd(c, "EXEC_RESULT %s %d", op_id, code);
    master_write(c, (unsigned char *)out, used);
    master_write(c, (const unsigned char *)"\n.END\n", 6);
    return 0;
}

static void handle_line(Ctx *c, char *line) {
    if (strncmp(line, "REJECT", 6) == 0 ||
        strncmp(line, "ERROR", 5) == 0 ||
        strncmp(line, "SHUTDOWN", 8) == 0) {
        fprintf(stderr, "[abyss] server message: %s%s\n", line,
                (line[0] == 'R' || line[0] == 'E') ? " (check token/key)" : "");
        return;
    }
    if (strcmp(line, "PING") == 0) {
        master_cmd(c, "PONG");
        return;
    }
    if (strcmp(line, "PONG") == 0) {
        return;
    }
    if (strncmp(line, "EXEC ", 5) == 0) {
        char op_id[64];
        char *rest = line + 5;
        char *sp = strchr(rest, ' ');
        if (!sp) return;
        size_t ol = (size_t)(sp - rest);
        if (ol >= sizeof(op_id)) ol = sizeof(op_id) - 1;
        memcpy(op_id, rest, ol);
        op_id[ol] = '\0';
        const char *cmd = sp + 1;
        exec_result(c, op_id, cmd);
        return;
    }
    if (strncmp(line, "TUN_OPEN ", 9) == 0) {
        char tid[TUN_TID_LEN];
        char addr[512];
        char host[256];
        char port[32];
        const char *rest = line + 9;
        const char *sp = strchr(rest, ' ');
        if (!sp) return;
        size_t ol = (size_t)(sp - rest);
        if (ol >= TUN_TID_LEN) ol = TUN_TID_LEN - 1;
        memcpy(tid, rest, ol);
        tid[ol] = '\0';
        snprintf(addr, sizeof(addr), "%s", sp + 1);
        split_hostport(addr, host, sizeof(host), port, sizeof(port));
        int fd = connect_host_to(host, port, 5000);
        if (fd >= 0) {
            int one = 1;
            setsockopt(fd, IPPROTO_TCP, TCP_NODELAY, &one, sizeof(one));
            if (add_tunnel(c, tid, fd) < 0) {
                close(fd);
                master_cmd(c, "TUN_CLOSE %s", tid);
            } else {
                master_cmd(c, "TUN_OK %s", tid);
            }
        } else {
            master_cmd(c, "TUN_CLOSE %s", tid);
        }
        return;
    }
    if (strncmp(line, "TUN_DATA ", 9) == 0) {
        char tid[TUN_TID_LEN];
        const char *rest = line + 9;
        const char *sp = strchr(rest, ' ');
        if (!sp) return;
        size_t ol = (size_t)(sp - rest);
        if (ol >= TUN_TID_LEN) ol = TUN_TID_LEN - 1;
        memcpy(tid, rest, ol);
        tid[ol] = '\0';
        int len = atoi(sp + 1);
        if (len < 0) len = 0;
        snprintf(c->pending_tid, TUN_TID_LEN, "%s", tid);
        c->pending_len = len;
        return;
    }
    if (strncmp(line, "TUN_CLOSE ", 10) == 0) {
        char tid[TUN_TID_LEN];
        const char *rest = line + 10;
        size_t ol = strnlen(rest, TUN_TID_LEN);
        if (ol >= TUN_TID_LEN) ol = TUN_TID_LEN - 1;
        memcpy(tid, rest, ol);
        tid[ol] = '\0';
        Tunnel *t = find_tunnel(c, tid);
        if (t) remove_tunnel(c, t);
        return;
    }
    if (strcmp(line, "QUIT") == 0 || strcmp(line, "EXIT") == 0) {
        exit(0);
    }
}

static int process_buffer(Ctx *c) {
    size_t pos = 0;
    while (pos < c->len) {
        if (c->pending_len > 0) {
            size_t take = (size_t)c->pending_len;
            if (take > c->len - pos) take = c->len - pos;
            Tunnel *t = find_tunnel(c, c->pending_tid);
            if (t && take > 0) {
                size_t off = 0;
                while (off < take) {
                    ssize_t w = write(t->sock, c->buf + pos + off, take - off);
                    if (w < 0) {
                        if (errno == EINTR) continue;
                        break;
                    }
                    off += (size_t)w;
                }
            }
            pos += take;
            c->pending_len -= (int)take;
            if (c->pending_len > 0) {
                c->len -= pos;
                memmove(c->buf, c->buf + pos, c->len);
                return 0;
            }
            continue;
        }
        const unsigned char *nl = memchr(c->buf + pos, '\n', c->len - pos);
        if (!nl) break;
        size_t ls = (size_t)(nl - (c->buf + pos)) + 1;
        char line[4096];
        size_t lc = ls - 1;
        if (lc >= sizeof(line)) lc = sizeof(line) - 1;
        memcpy(line, c->buf + pos, lc);
        line[lc] = '\0';
        pos += ls;
        handle_line(c, line);
    }
    c->len -= pos;
    if (c->len > 0) memmove(c->buf, c->buf + pos, c->len);
    return 0;
}

static int ensure_cap(Ctx *c, size_t add) {
    if (c->len + add <= c->cap) return 0;
    size_t ncap = c->cap ? c->cap : BUF_SIZE;
    while (ncap < c->len + add) ncap *= 2;
    unsigned char *nb = realloc(c->buf, ncap);
    if (!nb) return -1;
    c->buf = nb;
    c->cap = ncap;
    return 0;
}

static void set_keepalive(int fd) {
    int one = 1;
    setsockopt(fd, SOL_SOCKET, SO_KEEPALIVE, &one, sizeof(one));
    int idle = 30;
    setsockopt(fd, IPPROTO_TCP, TCP_KEEPIDLE, &idle, sizeof(idle));
    int intv = 15;
    setsockopt(fd, IPPROTO_TCP, TCP_KEEPINTVL, &intv, sizeof(intv));
    int cnt = 3;
    setsockopt(fd, IPPROTO_TCP, TCP_KEEPCNT, &cnt, sizeof(cnt));
}

static int run_session(Ctx *c) {
    char hello_id[128];
    char hello_flash[128];
    if (c->id[0] == '\0') {
        if (c->flash[0] == '\0') {
            snprintf(hello_id, sizeof(hello_id), "%s %s\n", c->name, c->token);
        } else {
            snprintf(hello_id, sizeof(hello_id), "%s %s %s\n", c->name,
                     c->token, c->flash);
        }
    } else {
        if (c->flash[0] == '\0') {
            snprintf(hello_id, sizeof(hello_id), "%s %s %s\n", c->name, c->id,
                     c->token);
        } else {
            snprintf(hello_id, sizeof(hello_id), "%s %s %s %s\n", c->name, c->id,
                     c->token, c->flash);
        }
    }
    snprintf(hello_flash, sizeof(hello_flash), "HELLO %s", hello_id);
    fprintf(stderr, "[abyss] connected, sending HELLO\n");
    master_write(c, (unsigned char *)hello_flash, strlen(hello_flash));

    int one = 1;
    setsockopt(c->master, IPPROTO_TCP, TCP_NODELAY, &one, sizeof(one));
    set_keepalive(c->master);

    c->pending_len = 0;
    c->last_ping = time(NULL);

    for (;;) {
        struct pollfd fds[1 + MAX_TUN];
        int map[1 + MAX_TUN];
        int nfds = 0;
        fds[nfds].fd = c->master;
        fds[nfds].events = POLLIN;
        fds[nfds].revents = 0;
        map[nfds] = -1;
        nfds++;
        for (int i = 0; i < MAX_TUN; i++) {
            if (c->tunnels[i].active) {
                fds[nfds].fd = c->tunnels[i].sock;
                fds[nfds].events = POLLIN;
                fds[nfds].revents = 0;
                map[nfds] = i;
                nfds++;
            }
        }

        int rc = poll(fds, (nfds_t)nfds, TICK_MS);
        if (rc < 0) {
            if (errno == EINTR) continue;
            return -1;
        }

        for (int i = 0; i < nfds; i++) {
            if (!(fds[i].revents & (POLLIN | POLLHUP | POLLERR))) continue;
            if (i == 0) {
                unsigned char tmp[BUF_SIZE];
                ssize_t r = read(c->master, tmp, sizeof(tmp));
                if (r <= 0) {
                    return (r == 0) ? 0 : -1;
                }
                xor_decrypt(&c->cipher, tmp, (size_t)r);
                if (ensure_cap(c, (size_t)r) != 0) return -1;
                memcpy(c->buf + c->len, tmp, (size_t)r);
                c->len += (size_t)r;
                process_buffer(c);
                c->last_ping = time(NULL);
            } else {
                int ti = map[i];
                if (ti < 0 || !c->tunnels[ti].active) continue;
                int tfd = fds[i].fd;
                unsigned char tmp[BUF_SIZE];
                ssize_t r = read(tfd, tmp, sizeof(tmp));
                if (r > 0) {
                    char hdr[128];
                    int hl = snprintf(hdr, sizeof(hdr), "TUN_DATA %s %d\n",
                                      c->tunnels[ti].tid, (int)r);
                    if (master_write(c, (unsigned char *)hdr, (size_t)hl) != 0)
                        return -1;
                    if (master_write(c, tmp, (size_t)r) != 0) return -1;
                } else {
                    master_cmd(c, "TUN_CLOSE %s", c->tunnels[ti].tid);
                    Tunnel *t = find_tunnel(c, c->tunnels[ti].tid);
                    if (t) remove_tunnel(c, t);
                }
            }
        }

        if (rc == 0) {
            if (time(NULL) - c->last_ping >= 20) {
                master_cmd(c, "PING");
                c->last_ping = time(NULL);
            }
        }
    }
    return 0;
}

int abyss_main(int argc, char **argv) {
    signal(SIGPIPE, SIG_IGN);

    if (argc >= 2 && (strcmp(argv[1], "-h") == 0 ||
                      strcmp(argv[1], "--help") == 0 ||
                      strcmp(argv[1], "-v") == 0 ||
                      strcmp(argv[1], "--version") == 0)) {
        fprintf(stderr,
                "abyss - abyss agent client (C)\n"
                "usage: abyss [options]\n"
                "  -s, --server HOST:PORT   server addr (default abyss.y-lin.wang:46293)\n"
                "  -t, --token TOKEN       auth token (default unauthorized)\n"
                "  -n, --name NAME         device name (default nvram productid)\n"
                "  -i, --id ID             device id (default lan_eeprom_mac)\n"
                "  -k, --crypto-key KEY    xor key\n"
                "  -d, --dns DNS           custon dns (parsed, not used)\n"
                "      --flash-time TS     flash timestamp\n"
                "      --crypto-key-no     disable encryption\n");
        return 0;
    }

    const char *s = find_val(argc, argv, "--server", "-s");
    const char *t = find_val(argc, argv, "--token", "-t");
    const char *n = find_val(argc, argv, "--name", "-n");
    const char *i = find_val(argc, argv, "--id", "-i");
    const char *k = find_val(argc, argv, "--crypto-key", "-k");
    const char *f = find_val(argc, argv, "--flash-time", NULL);

    Ctx c;
    memset(&c, 0, sizeof(c));
    for (int j = 0; j < MAX_TUN; j++) c.tunnels[j].sock = -1;

    c.master = -1;
    snprintf(c.name, sizeof(c.name), "%s", n ? n : "router");
    snprintf(c.id, sizeof(c.id), "%s", i ? i : "");
    snprintf(c.token, sizeof(c.token), "%s", t ? t : DEFAULT_TOKEN);
    snprintf(c.flash, sizeof(c.flash), "%s", f ? f : "");

    if (!n) {
        char dn[128], di[128];
        default_name_id(dn, sizeof(dn), di, sizeof(di));
        snprintf(c.name, sizeof(c.name), "%s", dn);
        if (!i) snprintf(c.id, sizeof(c.id), "%s", di);
    }

    c.cipher.key = c.key_str;
    if (has_flag(argc, argv, "--crypto-key-no")) {
        c.cipher.key_len = 0;
        c.cipher.enabled = 0;
    } else {
        size_t kl = snprintf((char *)c.key_str, sizeof(c.key_str), "%s",
                             k ? k : DEFAULT_KEY);
        if (kl >= sizeof(c.key_str)) kl = sizeof(c.key_str) - 1;
        c.cipher.key_len = kl;
        c.cipher.enabled = kl > 0 ? 1 : 0;
    }

    const char *server = s ? s : DEFAULT_SERVER;
    char host[256], port[32];
    split_hostport(server, host, sizeof(host), port, sizeof(port));

    fprintf(stderr,
            "[abyss] start name=%s id=%s token=%s flash=%s server=%s\n",
            c.name, c.id[0] ? c.id : "(auto)", c.token, c.flash, server);

    for (;;) {
        c.master = connect_host_to(host, port, 10000);
        if (c.master < 0) {
            fprintf(stderr, "[abyss] connect failed, retry in 5s\n");
            sleep(5);
            continue;
        }
        c.len = 0;
        xor_reset(&c.cipher);
        run_session(&c);
        close(c.master);
        c.master = -1;
        for (int j = 0; j < MAX_TUN; j++) {
            if (c.tunnels[j].active) {
                close(c.tunnels[j].sock);
                c.tunnels[j].active = 0;
                c.tunnels[j].sock = -1;
            }
        }
        sleep(5);
    }
}