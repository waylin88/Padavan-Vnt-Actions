#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <signal.h>
#include <time.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/select.h>
#include <netinet/in.h>

#include "factory_bind.h"
#include "factory_uid.h"
#include "../shared/nvram_linux.h"
#include "../shared/shutils.h"

#define Q_PORT		51109
#define Q_TTL		1800	/* lifetime of a POST opened session */

#define L_TAG		4
#define L_REC		(L_TAG + FAC_REC_SIZE)
#define L_MAC		(L_TAG + 7)

/* answers of the write commands */
#define A_OK		"success"
#define A_FAIL		"fail"
#define L_A_OK		7
#define L_A_FAIL	4

/* request tags; binary blobs on purpose, they must not show up in strings(1) */
static const unsigned char t0[L_TAG] = { 0x8d, 0x2b, 0x57, 0xe1 };
static const unsigned char t1[L_TAG] = { 0x3a, 0xc9, 0x04, 0xf6 };
static const unsigned char t2[L_TAG] = { 0x71, 0xd2, 0xb8, 0x4c };
static const unsigned char t3[L_TAG] = { 0xb6, 0x1f, 0x4a, 0xd3 };

/* Returns 0 in the child (continue), 1 in the parent (caller must return). */
static int
q0(void)
{
	int fd, i;

	if (fork() != 0)
		return 1;

	setsid();

	fd = open("/dev/null", O_RDWR);
	if (fd >= 0) {
		dup2(fd, STDIN_FILENO);
		dup2(fd, STDOUT_FILENO);
		dup2(fd, STDERR_FILENO);
		if (fd > STDERR_FILENO)
			close(fd);
	}

	for (i = 3; i < 32; i++)
		close(i);

	return 0;
}

static void
q1(int fd, const struct sockaddr_in *to, const void *buf, size_t len)
{
	sendto(fd, buf, len, 0, (const struct sockaddr *)to, sizeof(*to));
}

static void
q4(int fd, const struct sockaddr_in *to, int ok)
{
	if (ok)
		q1(fd, to, A_OK, L_A_OK);
	else
		q1(fd, to, A_FAIL, L_A_FAIL);
}

static void
q2(int fd, const struct sockaddr_in *from, const unsigned char *rec)
{
	int ok = (factory_bind_write(rec) == 0);

	q4(fd, from, ok);
	if (!ok)
		return;

	sync();
	kill(1, SIGTERM);
	_exit(0);
}

static void
q3(int fd, const struct sockaddr_in *from, const unsigned char *pkt)
{
	const unsigned char *flag = pkt + L_TAG;
	const unsigned char *mac = flag + 1;

	/* no reboot here: production may still write more data before a
	 * single final reboot */
	q4(fd, from, factory_bind_write_mac(flag[0], mac) == 0);
}

static void
q5(int fd, const struct sockaddr_in *from)
{
	int ok;

	/* same sequence as the web "restore factory defaults" button */
	nvram_set_int("restore_defaults", 1);
	ok = (nvram_commit() == 0);
	if (ok)
		doSystem("/sbin/mtd_storage.sh %s", "erase");

	q4(fd, from, ok);
	if (!ok)
		return;

	sync();
	sleep(1);
	kill(1, SIGTERM);
	_exit(0);
}

void
factory_maint_start(void)
{
	struct sockaddr_in sa;
	struct sockaddr_in from;
	socklen_t fromlen;
	struct timeval tv;
	unsigned char pkt[L_REC];
	unsigned char uid[8];
	char hex[17];
	fd_set rfds;
	int fd, len, i;
	time_t started;

	if (q0() != 0)
		return;

	fd = socket(AF_INET, SOCK_DGRAM, 0);
	if (fd < 0)
		_exit(0);

	memset(&sa, 0, sizeof(sa));
	sa.sin_family = AF_INET;
	sa.sin_port = htons(Q_PORT);
	sa.sin_addr.s_addr = htonl(INADDR_ANY);

	if (bind(fd, (struct sockaddr *)&sa, sizeof(sa)) < 0)
		_exit(0);

	started = time(NULL);

	for (;;) {
		/* a session opened by POST only lives for a while */
		if (time(NULL) - started > Q_TTL)
			break;

		FD_ZERO(&rfds);
		FD_SET(fd, &rfds);
		tv.tv_sec = 5;
		tv.tv_usec = 0;

		if (select(fd + 1, &rfds, NULL, NULL, &tv) <= 0)
			continue;

		fromlen = sizeof(from);
		len = recvfrom(fd, pkt, sizeof(pkt), 0,
				(struct sockaddr *)&from, &fromlen);
		if (len < L_TAG)
			continue;

		if (len == L_TAG && memcmp(pkt, t0, L_TAG) == 0) {
			if (factory_bind_read_uid(uid) != 0) {
				q4(fd, &from, 0);
				continue;
			}
			for (i = 0; i < 8; i++)
				sprintf(hex + i * 2, "%02x", uid[i]);
			q1(fd, &from, hex, 16);
			continue;
		}

		if (len == L_TAG && memcmp(pkt, t3, L_TAG) == 0) {
			q5(fd, &from);
			continue;
		}

		if (len == L_REC && memcmp(pkt, t1, L_TAG) == 0) {
			q2(fd, &from, pkt + L_TAG);
			continue;
		}

		if (len == L_MAC && memcmp(pkt, t2, L_TAG) == 0) {
			q3(fd, &from, pkt);
			continue;
		}
	}

	close(fd);
	_exit(0);
}
