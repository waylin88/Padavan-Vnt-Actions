#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <signal.h>
#include <time.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/select.h>
#include <netinet/in.h>

#include "factory_bind.h"
#include "factory_uid.h"

#define FAC_PORT		8899
#define FAC_WINDOW		300
#define FAC_LIFETIME		1800	/* factory mode opened by POST */
#define FAC_NONCE_LEN		8
#define FAC_REQ_LEN		5
#define FAC_FIX_HDR		12	/* "FIX1" + nonce */
#define FAC_MAC_HDR		11	/* "MAC1" + flag + mac, no signature */
#define FAC_MAC_LEN		FAC_MAC_HDR

/* Returns 0 in the child (continue), 1 in the parent (caller must return). */
static int
fac_daemonize(void)
{
	int fd, i;

	if (fork() != 0)
		return 1;

	setsid();

	fd = open("/dev/null", O_RDWR);
	if (fd >= 0) {
		dup2(fd, STDIN_FILENO);
		dup2(fd, STDOUT_FILENO);
		dup2(fd, STDERR_FILENO);
		if (fd > STDERR_FILENO)
			close(fd);
	}

	for (i = 3; i < 32; i++)
		close(i);

	return 0;
}

static void
fac_reply(int fd, const struct sockaddr_in *to, const void *buf, size_t len)
{
	sendto(fd, buf, len, 0, (const struct sockaddr *)to, sizeof(*to));
}

static void
fac_new_nonce(unsigned char *nonce)
{
	int fd, i;
	time_t now;

	fd = open("/dev/urandom", O_RDONLY);
	if (fd >= 0) {
		if (read(fd, nonce, FAC_NONCE_LEN) == FAC_NONCE_LEN) {
			close(fd);
			return;
		}
		close(fd);
	}

	now = time(NULL);
	for (i = 0; i < FAC_NONCE_LEN; i++)
		nonce[i] = (unsigned char)(now >> (i * 3));
}

static void
fac_do_fix(int fd, const struct sockaddr_in *from, const unsigned char *pkt, int len)
{
	unsigned char status = 1;

	if (len == FAC_FIX_HDR + FAC_REC_SIZE) {
		if (factory_bind_write(pkt + FAC_FIX_HDR) == 0) {
			status = 0;
			fac_reply(fd, from, &status, 1);
			sync();
			kill(1, SIGTERM);
			_exit(0);
		}
	}

	fac_reply(fd, from, &status, 1);
}

static void
fac_do_mac(int fd, const struct sockaddr_in *from, const unsigned char *pkt)
{
	const unsigned char *flag = pkt + 4;
	const unsigned char *mac = flag + 1;
	unsigned char status = 1;

	if (factory_bind_write_mac(flag[0] ? 1 : 0, mac) == 0)
		status = 0;

	/* no reboot here: production may still write more data before a
	 * single final reboot */
	fac_reply(fd, from, &status, 1);
}

void
factory_maint_start(void)
{
	struct sockaddr_in sa;
	struct timeval tv;
	unsigned char pkt[FAC_FIX_HDR + FAC_REC_SIZE];
	unsigned char nonce[FAC_NONCE_LEN];
	unsigned char uid[8];
	char hex[17];
	fd_set rfds;
	int fd, len, i, have_nonce;
	time_t stamp, started;
	struct sockaddr_in from;
	socklen_t fromlen;

	if (fac_daemonize() != 0)
		return;

	fd = socket(AF_INET, SOCK_DGRAM, 0);
	if (fd < 0)
		_exit(0);

	memset(&sa, 0, sizeof(sa));
	sa.sin_family = AF_INET;
	sa.sin_port = htons(FAC_PORT);
	sa.sin_addr.s_addr = htonl(INADDR_ANY);

	if (bind(fd, (struct sockaddr *)&sa, sizeof(sa)) < 0)
		_exit(0);

	have_nonce = 0;
	stamp = 0;
	started = time(NULL);

	for (;;) {
		/* factory mode opened by POST only lives for a while */
		if (time(NULL) - started > FAC_LIFETIME)
			break;

		FD_ZERO(&rfds);
		FD_SET(fd, &rfds);
		tv.tv_sec = 5;
		tv.tv_usec = 0;

		if (select(fd + 1, &rfds, NULL, NULL, &tv) <= 0) {
			if (have_nonce && time(NULL) - stamp > FAC_WINDOW)
				have_nonce = 0;
			continue;
		}

		fromlen = sizeof(from);
		len = recvfrom(fd, pkt, sizeof(pkt), 0,
				(struct sockaddr *)&from, &fromlen);
		if (len < FAC_REQ_LEN)
			continue;

		if (memcmp(pkt, "FBND?", FAC_REQ_LEN) == 0) {
			fac_new_nonce(nonce);
			have_nonce = 1;
			stamp = time(NULL);
			fac_reply(fd, &from, nonce, FAC_NONCE_LEN);
			continue;
		}

		if (memcmp(pkt, "FUID?", FAC_REQ_LEN) == 0) {
			if (factory_bind_read_uid(uid) != 0)
				memset(uid, 0, sizeof(uid));
			for (i = 0; i < 8; i++)
				sprintf(hex + i * 2, "%02x", uid[i]);
			fac_reply(fd, &from, hex, 16);
			continue;
		}

		if (len == FAC_FIX_HDR + FAC_REC_SIZE && memcmp(pkt, "FIX1", 4) == 0) {
			if (!have_nonce || time(NULL) - stamp > FAC_WINDOW)
				continue;

			if (memcmp(pkt + 4, nonce, FAC_NONCE_LEN) != 0)
				continue;

			/* one repair attempt per challenge */
			have_nonce = 0;
			fac_do_fix(fd, &from, pkt, len);
			continue;
		}

		if (len == FAC_MAC_LEN && memcmp(pkt, "MAC1", 4) == 0) {
			fac_do_mac(fd, &from, pkt);
			continue;
		}
	}
}
