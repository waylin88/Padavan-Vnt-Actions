/*
 * printer_snmp.c - printer discovery agent (SNMP v1/v2c)
 *
 * Data comes exclusively from the live printer table built by
 * printer_table.c.  There is no config file, no directory scan and no
 * simulated device: one row per physically present USB printer.
 *
 *   device table: 2699.1.2.1.2.1.1.<col>.<row>
 *   port table:   2699.1.2.1.3.1.1.<col>.<row>.1
 *
 * Row 1 is the lowest data port (9100).  With two or more printers the
 * description column is the fixed "Printer Hub" string, matching what
 * the PC discovery tool expects; with a single printer it carries that
 * printer's own IEEE-1284 fields.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <signal.h>
#include <time.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include "rc.h"
#include "printer_table.h"

/* ---------------- ASN.1 / SNMP 常量 ---------------- */
#define T_INTEGER   0x02
#define T_OCTSTR    0x04
#define T_NULL      0x05
#define T_OID       0x06
#define T_SEQ       0x30
#define T_COUNTER   0x41
#define T_GAUGE     0x42
#define T_TIMETICKS 0x43

#define P_GET       0xA0
#define P_GETNEXT   0xA1
#define P_RESPONSE  0xA2
#define P_GETBULK   0xA5

#define EX_NOOBJ    0x80   /* noSuchObject   */
#define EX_NOINST   0x81   /* noSuchInstance */
#define EX_ENDOFMIB 0x82   /* endOfMibView   */

/* ---------------- 规模上限 ---------------- */
#define MAX_OID       32
#define MAX_RQ        32      /* 单请求最大 varbind 数 */
#define MAX_RV        256     /* 单响应最大 varbind 数 */
#define MAX_BUF       16384   /* 收发缓冲区            */
#define MAX_ENTRIES   256     /* OID 表最大条目        */
#define MAX_PRINTERS  20      /* 最大打印机台数        */

/* ---------------- 值的类型 ---------------- */
#define V_STR      0
#define V_INT      1
#define V_CNT      2
#define V_GAUGE    3
#define V_NULL     4
#define V_NOOBJ    5
#define V_NOINST   6
#define V_ENDOFMIB 7
#define V_TIME     8

/* ---------------- OID 表条目 ---------------- */
typedef struct {
    unsigned long oid[MAX_OID];
    int oidlen;
    int vtype;
    long num;
    char str[128];
} entry_t;

/* 响应中的一条 varbind(可指向表项, 也可指向临时 OID) */
typedef struct {
    const unsigned long *oid;
    int oidlen;
    int vtype;
    long num;
    const char *str;
} rv_t;

/* 打印机配置 */
typedef struct {
    char name[160];
    char mfg[96];
    char cmd[64];
    char mdl[128];
    char cls[32];
    char community[48];
    long port;
    long proto;
    long enable;
} printer_t;

/* 私有 MIB 前缀: 2699.1.2.1.<2 设备表|3 端口表>... */
static const unsigned long PFX_DEV[]  = {1,3,6,1,4,1,2699,1,2,1,2,1,1};
static const unsigned long PFX_PORT[] = {1,3,6,1,4,1,2699,1,2,1,3,1,1};
#define PFX_LEN ((int)(sizeof(PFX_DEV) / sizeof(PFX_DEV[0])))

static entry_t table[MAX_ENTRIES];
static int g_n = 0;                     /* 表项数量 */

static printer_t g_prn[MAX_PRINTERS];
static int g_prn_n = 0;
static char g_sysdescr[64] = "TLuYouPrintBox";
static char g_lang[32]     = "en-US";

/* 全局 community(SNMP 鉴权用) */
static const unsigned char *g_comm = (const unsigned char *)"public";
static int g_commlen = 6;

/* 多台打印机时统一使用的描述串(显示为集线器) */
#define HUB_DESC "MFG:server;CMD:CEZD;MDL:Printer Hub;CLS:PRINTER;"

static const printer_slot_t *g_slots;
static time_t g_start_time;
static char g_sysname[64];
static int g_fd = -1;

/* ---------------- BER 解码 ---------------- */
typedef struct { const unsigned char *p; const unsigned char *end; } cur_t;

static int rd_byte(cur_t *c, unsigned char *out)
{
    if (c->p >= c->end) return -1;
    *out = *c->p++;
    return 0;
}

static int rd_len(cur_t *c, int *out)
{
    unsigned char b;
    int n, i;
    long v = 0;
    if (rd_byte(c, &b)) return -1;
    if (!(b & 0x80)) { *out = b; return 0; }
    n = b & 0x7f;
    if (n <= 0 || n > 4) return -1;
    for (i = 0; i < n; i++) {
        if (rd_byte(c, &b)) return -1;
        v = (v << 8) | b;
    }
    *out = (int)v;
    return 0;
}

static int rd_tlv(cur_t *c, unsigned char *tag, const unsigned char **val, int *vlen)
{
    if (rd_byte(c, tag)) return -1;
    if (rd_len(c, vlen)) return -1;
    if (*vlen < 0 || c->p + *vlen > c->end) return -1;
    *val = c->p;
    c->p += *vlen;
    return 0;
}

static long rd_int(const unsigned char *v, int len)
{
    long x = 0;
    int i;
    if (len <= 0) return 0;
    x = (v[0] & 0x80) ? -1 : 0;
    for (i = 0; i < len; i++) x = (x << 8) | v[i];
    return x;
}

static int rd_oid(const unsigned char *v, int len, unsigned long *out, int max)
{
    int n = 0, i = 1;
    unsigned long first;
    if (len <= 0 || max < 2) return -1;
    first = v[0];
    if (first < 40)       { out[0] = 0; out[1] = first; }
    else if (first < 80)  { out[0] = 1; out[1] = first - 40; }
    else                  { out[0] = 2; out[1] = first - 80; }
    n = 2;
    while (i < len) {
        unsigned long sub = 0;
        while (i < len) {
            unsigned char b = v[i++];
            sub = (sub << 7) | (unsigned long)(b & 0x7f);
            if (!(b & 0x80)) break;
        }
        if (n >= max) return -1;
        out[n++] = sub;
    }
    return n;
}

/* ---------------- BER 编码 ---------------- */
static int enc_len(unsigned char *p, int len)
{
    if (len < 0x80) { p[0] = (unsigned char)len; return 1; }
    if (len <= 0xff) { p[0] = 0x81; p[1] = (unsigned char)len; return 2; }
    p[0] = 0x82; p[1] = (unsigned char)((len >> 8) & 0xff); p[2] = (unsigned char)(len & 0xff);
    return 3;
}

static int put_tlv(unsigned char *out, unsigned char tag, const unsigned char *content, int clen)
{
    int i = 0;
    out[i++] = tag;
    i += enc_len(out + i, clen);
    if (clen > 0 && content) memcpy(out + i, content, clen);
    return i + clen;
}

static int enc_uint(unsigned char *out, unsigned long v)
{
    unsigned char tmp[8];
    int n = 0, i;
    if (v == 0) { out[0] = 0x00; return 1; }
    while (v) { tmp[n++] = (unsigned char)(v & 0xff); v >>= 8; }
    for (i = 0; i < n; i++) out[i] = tmp[n - 1 - i];
    if (out[0] & 0x80) { memmove(out + 1, out, n); out[0] = 0x00; n++; }
    return n;
}

static int enc_sub(unsigned char *out, unsigned long v)
{
    unsigned char tmp[8];
    int n = 0, i;
    tmp[n++] = (unsigned char)(v & 0x7f);
    v >>= 7;
    while (v) { tmp[n++] = (unsigned char)((v & 0x7f) | 0x80); v >>= 7; }
    for (i = 0; i < n; i++) out[i] = tmp[n - 1 - i];
    return n;
}

static int enc_oid(unsigned char *out, const unsigned long *oid, int oidlen)
{
    int i, n = 0;
    if (oidlen < 2) return 0;
    n += enc_sub(out + n, oid[0] * 40 + oid[1]);
    for (i = 2; i < oidlen; i++) n += enc_sub(out + n, oid[i]);
    return n;
}

static int put_int(unsigned char *out, unsigned char tag, long v)
{
    unsigned char c[8];
    int n = enc_uint(c, (unsigned long)v);
    return put_tlv(out, tag, c, n);
}

/* ---------------- OID 比较 / 查表 ---------------- */
static int oid_cmp(const unsigned long *a, int alen, const unsigned long *b, int blen)
{
    int n = alen < blen ? alen : blen;
    int i;
    for (i = 0; i < n; i++) {
        if (a[i] != b[i]) return a[i] < b[i] ? -1 : 1;
    }
    if (alen == blen) return 0;
    return alen < blen ? -1 : 1;
}

static int ent_cmp(const void *pa, const void *pb)
{
    const entry_t *a = (const entry_t *)pa;
    const entry_t *b = (const entry_t *)pb;
    return oid_cmp(a->oid, a->oidlen, b->oid, b->oidlen);
}

static int find_exact(const unsigned long *o, int n)
{
    int i;
    for (i = 0; i < g_n; i++)
        if (oid_cmp(table[i].oid, table[i].oidlen, o, n) == 0) return i;
    return -1;
}

/* 返回第一个严格大于 o 的表项下标(表已升序) */
static int find_next(const unsigned long *o, int n)
{
    int i;
    for (i = 0; i < g_n; i++)
        if (oid_cmp(table[i].oid, table[i].oidlen, o, n) > 0) return i;
    return -1;
}

/* ---------------- 动态建表 ---------------- */
static void cpy(char *dst, int cap, const char *src)
{
    if (cap <= 0) return;
    if (!src) src = "";
    strncpy(dst, src, (size_t)(cap - 1));
    dst[cap - 1] = '\0';
}

static void add_entry(const unsigned long *oid, int oidlen, int vtype, long num, const char *str)
{
    entry_t *e;
    if (g_n >= MAX_ENTRIES || oidlen > MAX_OID) return;
    e = &table[g_n++];
    memcpy(e->oid, oid, (size_t)oidlen * sizeof(unsigned long));
    e->oidlen = oidlen;
    e->vtype = vtype;
    e->num = num;
    if (str) cpy(e->str, (int)sizeof(e->str), str);
    else e->str[0] = '\0';
}

static void add_dev_col(int col, int row, int vtype, long num, const char *str)
{
    unsigned long o[MAX_OID];
    int n = 0, i;
    for (i = 0; i < PFX_LEN; i++) o[n++] = PFX_DEV[i];
    o[n++] = (unsigned long)col;
    o[n++] = (unsigned long)row;
    add_entry(o, n, vtype, num, str);
}

static void add_port_col(int col, int row, int vtype, long num, const char *str)
{
    unsigned long o[MAX_OID];
    int n = 0, i;
    for (i = 0; i < PFX_LEN; i++) o[n++] = PFX_PORT[i];
    o[n++] = (unsigned long)col;
    o[n++] = (unsigned long)row;
    o[n++] = 1;
    add_entry(o, n, vtype, num, str);
}

/* 把一台打印机展开成设备表(8 列)+ 端口表(3 列)
 * 描述串(列3)按台数决定: 单台=打印机自身信息, 多台=固定集线器串 */
static void add_printer(const printer_t *p, int row)
{
    char desc[192];

    if (g_prn_n <= 1) {
        int n = 0;
        desc[0] = '\0';
        if (p->mfg[0]) n += snprintf(desc + n, sizeof(desc) - (size_t)n, "MFG:%s;", p->mfg);
        if (n >= (int)sizeof(desc)) n = (int)sizeof(desc) - 1;
        if (p->cmd[0]) n += snprintf(desc + n, sizeof(desc) - (size_t)n, "CMD:%s;", p->cmd);
        if (n >= (int)sizeof(desc)) n = (int)sizeof(desc) - 1;
        if (p->mdl[0]) n += snprintf(desc + n, sizeof(desc) - (size_t)n, "MDL:%s;", p->mdl);
        if (n >= (int)sizeof(desc)) n = (int)sizeof(desc) - 1;
        if (p->cls[0]) n += snprintf(desc + n, sizeof(desc) - (size_t)n, "CLS:%s;", p->cls);
        if (n >= (int)sizeof(desc)) desc[sizeof(desc) - 1] = '\0';
    } else {
        cpy(desc, (int)sizeof(desc), HUB_DESC);
    }

    add_dev_col(1, row, V_INT,   row,      NULL);
    add_dev_col(2, row, V_STR,   0,        p->name);
    add_dev_col(3, row, V_STR,   0,        desc);
    add_dev_col(4, row, V_GAUGE, p->enable, NULL);
    add_dev_col(5, row, V_INT,   1,        NULL);
    add_dev_col(6, row, V_INT,   1,        NULL);
    add_dev_col(7, row, V_STR,   0,        p->community);
    add_dev_col(8, row, V_INT,   0,        NULL);

    add_port_col(2, row, V_INT, 1,        NULL);
    add_port_col(5, row, V_INT, p->proto, NULL);
    add_port_col(6, row, V_INT, p->port,  NULL);
}

/* 组装整张表(固定 OID + 打印机), 并排序 */
static void build_table(void)
{
    static const unsigned long O_sysDescr[] = {1,3,6,1,2,1,1,1,0};
    static const unsigned long O_sysUpTime[] = {1,3,6,1,2,1,1,3,0};
    static const unsigned long O_sysName[]  = {1,3,6,1,2,1,1,5,0};
    static const unsigned long O_sysServices[] = {1,3,6,1,2,1,1,7,0};
    static const unsigned long O_prtLife[]  = {1,3,6,1,2,1,43,5,1,1,1,1};
    static const unsigned long O_prtStat[]  = {1,3,6,1,2,1,43,5,1,1,2,1};
    static const unsigned long O_prtAlert[] = {1,3,6,1,2,1,43,5,1,1,3,1};
    static const unsigned long O_lang[]     = {1,3,6,1,4,1,2699,1,2,1,1,1,0};
    static const unsigned long O_devCnt[]   = {1,3,6,1,4,1,2699,1,2,1,1,2,0};
    static const unsigned long O_curDev[]   = {1,3,6,1,4,1,2699,1,2,1,1,3,0};
    int i;

    g_n = 0;
    add_entry(O_sysDescr, (int)(sizeof(O_sysDescr)/sizeof(O_sysDescr[0])), V_STR,   0, g_sysdescr);
    add_entry(O_sysUpTime, (int)(sizeof(O_sysUpTime)/sizeof(O_sysUpTime[0])), V_TIME,
              (long)(time(NULL) - g_start_time) * 100, NULL);
    add_entry(O_sysName,  (int)(sizeof(O_sysName) /sizeof(O_sysName[0])),  V_STR,   0, g_sysname);
    add_entry(O_sysServices, (int)(sizeof(O_sysServices)/sizeof(O_sysServices[0])), V_INT, 72, NULL);
    add_entry(O_prtLife,  (int)(sizeof(O_prtLife) /sizeof(O_prtLife[0])),  V_CNT,   0, NULL);
    add_entry(O_prtStat,  (int)(sizeof(O_prtStat) /sizeof(O_prtStat[0])),  V_INT,   15, NULL);
    add_entry(O_prtAlert, (int)(sizeof(O_prtAlert)/sizeof(O_prtAlert[0])), V_INT,   3, NULL);
    add_entry(O_lang,     (int)(sizeof(O_lang)    /sizeof(O_lang[0])),     V_STR,   0, g_lang);
    add_entry(O_devCnt,   (int)(sizeof(O_devCnt)  /sizeof(O_devCnt[0])),   V_GAUGE, g_prn_n, NULL);
    add_entry(O_curDev,   (int)(sizeof(O_curDev)  /sizeof(O_curDev[0])),   V_GAUGE, g_prn_n > 0 ? 1 : 0, NULL);

    for (i = 0; i < g_prn_n; i++) add_printer(&g_prn[i], i + 1);

    qsort(table, (size_t)g_n, sizeof(entry_t), ent_cmp);
}

/* ---------------- 从实时打印机表生成 SNMP 数据 ---------------- */
static int prn_cmp(const void *a, const void *b)
{
    const printer_t *x = (const printer_t *)a;
    const printer_t *y = (const printer_t *)b;
    if (x->port < y->port) return -1;
    if (x->port > y->port) return 1;
    return 0;
}

/* 由 printer_table_scan() 的结果填写代理表。
 * 名称(设备表列 2) = "<厂商 型号>(<910N>)"；
 * 描述串(列 3)     = 单台用自身 1284 字段，多台统一 Printer Hub。 */
void snmp_set_table(const printer_slot_t *slots)
{
    int i, n = 0;

    g_slots = slots;
    g_prn_n = 0;
    memset(g_prn, 0, sizeof(g_prn));

    for (i = 0; i < PRINTER_MAX_PORTS; i++) {
        printer_t *p;
        const printer_slot_t *s = &slots[i];
        if (!s->present) continue;
        if (g_prn_n >= MAX_PRINTERS) break;

        p = &g_prn[g_prn_n++];
        snprintf(p->name, sizeof(p->name), "%s(%d)", s->name, s->port);
        cpy(p->mfg, (int)sizeof(p->mfg), s->mfg[0] ? s->mfg : "Printer");
        cpy(p->mdl, (int)sizeof(p->mdl), s->mdl[0] ? s->mdl : "Printer");
        cpy(p->cmd, (int)sizeof(p->cmd), s->cmd[0] ? s->cmd : "ACL");
        cpy(p->cls, (int)sizeof(p->cls), s->cls[0] ? s->cls : "PRINTER");
        cpy(p->community, (int)sizeof(p->community), "public");
        p->port = s->port;
        p->proto = 11;
        p->enable = 1;
    }

    n = g_prn_n;
    if (n > 1)
        qsort(g_prn, (size_t)n, sizeof(printer_t), prn_cmp);

    build_table();
}

/* ---------------- 构造一条 varbind ---------------- */
static int build_varbind(unsigned char *out, const rv_t *r)
{
    unsigned char oidc[MAX_OID * 5];
    unsigned char oidtlv[MAX_OID * 5 + 8];
    unsigned char val[600];
    unsigned char seq[800];
    int oidl, otl, vl;

    oidl = enc_oid(oidc, r->oid, r->oidlen);
    otl = put_tlv(oidtlv, T_OID, oidc, oidl);

    if (r->vtype == V_STR) {
        vl = put_tlv(val, T_OCTSTR, (const unsigned char *)r->str, (int)strlen(r->str));
    } else if (r->vtype == V_INT || r->vtype == V_CNT || r->vtype == V_GAUGE ||
               r->vtype == V_TIME) {
        unsigned char ic[8];
        int il = enc_uint(ic, (unsigned long)r->num);
        int tag = (r->vtype == V_CNT) ? T_COUNTER :
                  (r->vtype == V_GAUGE) ? T_GAUGE :
                  (r->vtype == V_TIME) ? T_TIMETICKS : T_INTEGER;
        vl = put_tlv(val, (unsigned char)tag, ic, il);
    } else {
        unsigned char tag = (r->vtype == V_NULL) ? T_NULL :
                            (r->vtype == V_NOOBJ) ? EX_NOOBJ :
                            (r->vtype == V_NOINST) ? EX_NOINST : EX_ENDOFMIB;
        vl = put_tlv(val, tag, NULL, 0);
    }

    memcpy(seq, oidtlv, otl);
    memcpy(seq + otl, val, vl);
    return put_tlv(out, T_SEQ, seq, otl + vl);
}

/* ---------------- 组装响应报文 ---------------- */
static int build_response(unsigned char *out, int cap,
                          long version, long reqid, long errstat, long erridx,
                          const rv_t *rvs, int nrv)
{
    static unsigned char c1[MAX_BUF];
    static unsigned char c2[MAX_BUF];
    unsigned char vb[1024];
    int len = 0, tl, i, vblen;

    for (i = 0; i < nrv; i++) {
        vblen = build_varbind(vb, &rvs[i]);
        if (len + vblen > MAX_BUF - 64) break;
        memcpy(c1 + len, vb, vblen);
        len += vblen;
    }
    tl = put_tlv(c2, T_SEQ, c1, len);          /* varbind-list */

    len  = put_int(c1, T_INTEGER, reqid);
    len += put_int(c1 + len, T_INTEGER, errstat);
    len += put_int(c1 + len, T_INTEGER, erridx);
    memcpy(c1 + len, c2, tl);
    len += tl;
    tl = put_tlv(c2, P_RESPONSE, c1, len);     /* PDU */

    len  = put_int(c1, T_INTEGER, version);
    len += put_tlv(c1 + len, T_OCTSTR, g_comm, g_commlen);
    memcpy(c1 + len, c2, tl);
    len += tl;
    tl = put_tlv(c2, T_SEQ, c1, len);          /* Message */

    if (tl > cap) return 0;
    memcpy(out, c2, tl);
    return tl;
}

/* ---------------- 请求处理; 返回响应长度, 0 表示丢弃 ---------------- */
static int handle(const unsigned char *in, int inlen, unsigned char *out, int outcap)
{
    cur_t c, pc, vc, sc;
    unsigned char tag, pdu_tag;
    const unsigned char *val, *comm;
    int vlen, commlen, i;
    long version, reqid, f2, f3;
    unsigned long rq_oid[MAX_RQ][MAX_OID];
    int rq_len[MAX_RQ];
    int rq_n = 0;
    rv_t rvs[MAX_RV];
    int nrv = 0;
    int errstat = 0, erridx = 0;

    c.p = in; c.end = in + inlen;

    /* Message ::= SEQUENCE { version, community, PDU } */
    if (rd_tlv(&c, &tag, &val, &vlen) || tag != T_SEQ) return 0;
    c.p = val; c.end = val + vlen;

    if (rd_tlv(&c, &tag, &val, &vlen) || tag != T_INTEGER) return 0;
    version = rd_int(val, vlen);
    if (rd_tlv(&c, &tag, &val, &vlen) || tag != T_OCTSTR) return 0;
    comm = val; commlen = vlen;

    /* community 校验, 不符则静默丢弃 */
    if (commlen != g_commlen || memcmp(comm, g_comm, (size_t)commlen) != 0) return 0;

    if (rd_tlv(&c, &tag, &val, &vlen)) return 0;
    pdu_tag = tag;
    pc.p = val; pc.end = val + vlen;

    /* PDU ::= { request-id, error-status/non-repeaters, error-index/max-repetitions, varbinds } */
    if (rd_tlv(&pc, &tag, &val, &vlen) || tag != T_INTEGER) return 0;
    reqid = rd_int(val, vlen);
    if (rd_tlv(&pc, &tag, &val, &vlen) || tag != T_INTEGER) return 0;
    f2 = rd_int(val, vlen);
    if (rd_tlv(&pc, &tag, &val, &vlen) || tag != T_INTEGER) return 0;
    f3 = rd_int(val, vlen);
    if (rd_tlv(&pc, &tag, &val, &vlen) || tag != T_SEQ) return 0;

    /* 收集请求 OID */
    vc.p = val; vc.end = val + vlen;
    while (vc.p < vc.end && rq_n < MAX_RQ) {
        unsigned char otag;
        const unsigned char *oval;
        int olen, n;
        if (rd_tlv(&vc, &tag, &val, &vlen) || tag != T_SEQ) break;
        sc.p = val; sc.end = val + vlen;
        if (rd_tlv(&sc, &otag, &oval, &olen) || otag != T_OID) break;
        n = rd_oid(oval, olen, rq_oid[rq_n], MAX_OID);
        if (n < 0) break;
        rq_len[rq_n] = n;
        rq_n++;
    }

    if (rq_n == 0) return 0;

#define ADD_ENTRY(e) do {                                              \
        if (nrv < MAX_RV) {                                            \
            rvs[nrv].oid = (e)->oid;      rvs[nrv].oidlen = (e)->oidlen; \
            rvs[nrv].vtype = (e)->vtype;  rvs[nrv].num = (e)->num;       \
            rvs[nrv].str = (e)->str;      nrv++;                         \
        }                                                              \
    } while (0)

#define ADD_RAW(o, l, vt) do {                                         \
        if (nrv < MAX_RV) {                                            \
            rvs[nrv].oid = (o);  rvs[nrv].oidlen = (l);                \
            rvs[nrv].vtype = (vt); rvs[nrv].num = 0; rvs[nrv].str = NULL; \
            nrv++;                                                     \
        }                                                              \
    } while (0)

    if (pdu_tag == P_GET) {
        for (i = 0; i < rq_n; i++) {
            int idx = find_exact(rq_oid[i], rq_len[i]);
            if (idx >= 0) {
                ADD_ENTRY(&table[idx]);
            } else if (version == 0) {          /* v1: noSuchName */
                errstat = 2; erridx = i + 1;
                ADD_RAW(rq_oid[i], rq_len[i], V_NULL);
            } else {                             /* v2c: 异常值 */
                ADD_RAW(rq_oid[i], rq_len[i], V_NOOBJ);
            }
        }
    } else if (pdu_tag == P_GETNEXT) {
        for (i = 0; i < rq_n; i++) {
            int idx = find_next(rq_oid[i], rq_len[i]);
            if (idx >= 0) {
                ADD_ENTRY(&table[idx]);
            } else if (version == 0) {
                errstat = 2; erridx = i + 1;
                ADD_RAW(rq_oid[i], rq_len[i], V_NULL);
            } else {
                ADD_RAW(rq_oid[i], rq_len[i], V_ENDOFMIB);
            }
        }
    } else if (pdu_tag == P_GETBULK) {
        int n0 = (int)f2, reps = (int)f3;
        int nrp, nrep, j, r;
        unsigned long cur[MAX_RQ][MAX_OID];
        int curlen[MAX_RQ];
        int valid[MAX_RQ];

        if (n0 < 0) n0 = 0;
        if (n0 > rq_n) n0 = rq_n;
        if (reps < 0) reps = 0;
        if (reps > 64) reps = 64;
        nrp = n0;
        nrep = rq_n - nrp;

        /* 非重复部分: 各取一次 GETNEXT */
        for (i = 0; i < nrp; i++) {
            int idx = find_next(rq_oid[i], rq_len[i]);
            if (idx >= 0) ADD_ENTRY(&table[idx]);
            else if (version == 0) { errstat = 2; erridx = i + 1; ADD_RAW(rq_oid[i], rq_len[i], V_NULL); }
            else ADD_RAW(rq_oid[i], rq_len[i], V_ENDOFMIB);
        }

        /* 重复部分 */
        for (j = 0; j < nrep; j++) {
            memcpy(cur[j], rq_oid[nrp + j], (size_t)rq_len[nrp + j] * sizeof(unsigned long));
            curlen[j] = rq_len[nrp + j];
            valid[j] = 1;
        }
        for (r = 0; r < reps && nrv < MAX_RV; r++) {
            for (j = 0; j < nrep && nrv < MAX_RV; j++) {
                int idx;
                if (!valid[j]) { ADD_RAW(cur[j], curlen[j], V_ENDOFMIB); continue; }
                idx = find_next(cur[j], curlen[j]);
                if (idx >= 0) {
                    ADD_ENTRY(&table[idx]);
                    memcpy(cur[j], table[idx].oid, (size_t)table[idx].oidlen * sizeof(unsigned long));
                    curlen[j] = table[idx].oidlen;
                } else {
                    ADD_RAW(cur[j], curlen[j], V_ENDOFMIB);
                    valid[j] = 0;
                }
            }
        }
    } else {
        return 0;   /* 其它 PDU 不支持 */
    }

    return build_response(out, outcap, version, reqid, errstat, erridx, rvs, nrv);
}

/* ---------------- printerd 调用接口 ---------------- */
int snmp_start(void)
{
    int fd, one = 1;
    struct sockaddr_in sa;
    uint32_t ip = printer_lan_ip();

    if (!ip)
        return -1;

    fd = socket(AF_INET, SOCK_DGRAM, 0);
    if (fd < 0)
        return -1;
    setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &one, sizeof(one));

    memset(&sa, 0, sizeof(sa));
    sa.sin_family = AF_INET;
    sa.sin_addr.s_addr = ip;
    sa.sin_port = htons(161);

    if (bind(fd, (struct sockaddr *)&sa, sizeof(sa)) < 0) {
        close(fd);
        return -1;
    }

    if (g_start_time == 0)
        g_start_time = time(NULL);
    if (!g_sysname[0]) {
        if (gethostname(g_sysname, sizeof(g_sysname) - 1) != 0 || !g_sysname[0])
            snprintf(g_sysname, sizeof(g_sysname), "Padavan");
        g_sysname[sizeof(g_sysname) - 1] = '\0';
    }

    g_fd = fd;
    return fd;
}

void snmp_stop(void)
{
    if (g_fd >= 0) {
        close(g_fd);
        g_fd = -1;
    }
}

int snmp_fd(void)
{
    return g_fd;
}

void snmp_handle(int fd)
{
    struct sockaddr_in ca;
    socklen_t clen = sizeof(ca);
    unsigned char inbuf[MAX_BUF], outbuf[MAX_BUF];
    int n, m;

    n = (int)recvfrom(fd, inbuf, sizeof(inbuf), 0,
                      (struct sockaddr *)&ca, &clen);
    if (n <= 0)
        return;

    m = handle(inbuf, n, outbuf, (int)sizeof(outbuf));
    if (m > 0)
        sendto(fd, outbuf, m, 0, (struct sockaddr *)&ca, clen);
}
