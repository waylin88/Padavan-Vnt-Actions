/*
 * Live printer table shared by the mDNS and SNMP parts of printerd.
 *
 * The only source of truth is the kernel: /sys/class/usb/lp* plus the
 * IEEE-1284 device id exposed by usblp.  No directory or config file is
 * consulted, so an unplugged printer can never be advertised and a name
 * can never diverge from what the web status page shows.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <ctype.h>
#include <dirent.h>

#include <usb_info.h>

#include "rc.h"
#include "printer_table.h"

static int
uid_clamp(int uid)
{
	if (uid < 1)
		uid = 1;
	if (uid > PRINTER_MAX_PORTS)
		uid = PRINTER_MAX_PORTS;
	return uid;
}

/* Physical port number from a kernel DEVPATH (".../1-1.3/1-1.3:1.0"). */
int
printer_uid_from_devpath(const char *devpath)
{
	char buf[256];
	char *colon, *slash, *dot;
	int uid;

	if (!devpath || !devpath[0])
		return 1;

	strncpy(buf, devpath, sizeof(buf) - 1);
	buf[sizeof(buf) - 1] = '\0';

	colon = strchr(buf, ':');
	if (colon)
		*colon = '\0';

	slash = strrchr(buf, '/');
	dot = slash ? strchr(slash, '.') : NULL;
	if (!dot)
		return 1;

	uid = atoi(dot + 1);
	return uid_clamp(uid);
}

/* Physical port number for an lp node. */
int
printer_uid_by_devname(const char *devname)
{
	char portstr[64];
	char *dot;
	int uid = 1;

	if (devname && get_usb_port_by_device(devname, portstr, sizeof(portstr))) {
		dot = strchr(portstr, '.');
		if (dot)
			uid = atoi(dot + 1);
	}

	return uid_clamp(uid);
}

/* Stable uid -> data-port offset mapping (nvram override, else uid-1). */
int
printer_offset_by_uid(int uid)
{
	char key[16];
	char *val;
	int offset;

	uid = uid_clamp(uid);
	snprintf(key, sizeof(key), "lp%d", uid);

	val = nvram_get(key);
	if (val) {
		offset = atoi(val);
		if (offset >= 0 && offset < PRINTER_MAX_PORTS)
			return offset;
	}

	offset = uid - 1;
	if (offset < 0)
		offset = 0;
	if (offset >= PRINTER_MAX_PORTS)
		offset = PRINTER_MAX_PORTS - 1;

	nvram_set_int(key, offset);
	nvram_commit();

	return offset;
}

int
printer_offset_by_devname(const char *devname)
{
	return printer_offset_by_uid(printer_uid_by_devname(devname));
}

int
printer_offset_from_devpath(const char *devpath)
{
	return printer_offset_by_uid(printer_uid_from_devpath(devpath));
}

static int
contains_ci(const char *hay, const char *needle)
{
	size_t nlen;

	if (!hay || !needle || !needle[0])
		return 0;
	nlen = strlen(needle);
	while (*hay) {
		if (strncasecmp(hay, needle, nlen) == 0)
			return 1;
		hay++;
	}
	return 0;
}

/* Same composition rule as the old dns-sd name:
 *  - HP reports "Hewlett-Packard" as brand -> use the model only
 *  - otherwise join brand and model unless the model already has it
 *  - "Printer" when neither is available
 */
static void
make_name(const char *mfg, const char *mdl, char *out, int out_size)
{
	if (mfg[0] && mdl[0]) {
		if (contains_ci(mfg, "Hewlett") || contains_ci(mdl, mfg))
			snprintf(out, out_size, "%s", mdl);
		else
			snprintf(out, out_size, "%s %s", mfg, mdl);
	} else if (mdl[0]) {
		snprintf(out, out_size, "%s", mdl);
	} else if (mfg[0]) {
		snprintf(out, out_size, "%s", mfg);
	} else {
		snprintf(out, out_size, "%s", "Printer");
	}
}

void
printer_table_scan(printer_slot_t *slots)
{
	DIR *dir;
	struct dirent *de;
	int i;

	if (!slots)
		return;

	memset(slots, 0, sizeof(printer_slot_t) * PRINTER_MAX_PORTS);
	for (i = 0; i < PRINTER_MAX_PORTS; i++) {
		slots[i].offset = i;
		slots[i].port = 9100 + i;
	}

	dir = opendir(SYS_PRINTER);
	if (!dir)
		return;

	while ((de = readdir(dir)) != NULL) {
		printer_slot_t *s;
		int offset;

		if (strncmp(de->d_name, "lp", 2) != 0 ||
		    !isdigit((unsigned char)de->d_name[2]))
			continue;

		offset = printer_offset_by_devname(de->d_name);
		if (offset < 0 || offset >= PRINTER_MAX_PORTS)
			continue;
		if (slots[offset].present)
			continue;

		s = &slots[offset];
		s->present = 1;
		s->uid = printer_uid_by_devname(de->d_name);
		snprintf(s->dev, sizeof(s->dev), "%s", de->d_name);
		s->port = 9100 + offset;

		get_printer_identity(s->dev,
				     s->mfg, sizeof(s->mfg),
				     s->mdl, sizeof(s->mdl),
				     s->cmd, sizeof(s->cmd),
				     s->cls, sizeof(s->cls));

		snprintf(s->brand, sizeof(s->brand), "%s",
			 s->mfg[0] ? s->mfg : "Printer");
		make_name(s->mfg, s->mdl, s->name, sizeof(s->name));
	}

	closedir(dir);
}

int
printer_table_count(const printer_slot_t *slots)
{
	int i, n = 0;

	for (i = 0; slots && i < PRINTER_MAX_PORTS; i++) {
		if (slots[i].present)
			n++;
	}
	return n;
}

uint32_t
printer_lan_ip(void)
{
	return (uint32_t)get_lan_ip4();
}
