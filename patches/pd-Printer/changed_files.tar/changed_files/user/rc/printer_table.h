#ifndef __PRINTER_TABLE_H__
#define __PRINTER_TABLE_H__

#include "rc.h"

typedef struct {
	int present;
	int offset;		/* 0..PRINTER_MAX_PORTS-1 -> 9100..9103 */
	int uid;		/* physical USB port number, 1..PRINTER_MAX_PORTS */
	int port;		/* 9100 + offset */
	char dev[16];		/* lp0 */
	char mfg[96];		/* raw IEEE-1284 MFG */
	char mdl[128];		/* raw IEEE-1284 MDL */
	char cmd[64];		/* raw IEEE-1284 CMD */
	char cls[32];		/* raw IEEE-1284 CLS */
	char brand[96];		/* display brand: MFG or "Printer" */
	char name[128];		/* display name: MDL or "Printer" */
} printer_slot_t;

/* Port assignment, shared by hotplug (unplug) and service start (plug). */
int printer_uid_from_devpath(const char *devpath);
int printer_uid_by_devname(const char *devname);
int printer_offset_by_uid(int uid);
int printer_offset_by_devname(const char *devname);
int printer_offset_from_devpath(const char *devpath);

/* Rebuild the table from the live usb printer nodes. */
void printer_table_scan(printer_slot_t *slots);
int printer_table_count(const printer_slot_t *slots);
uint32_t printer_lan_ip(void);

#endif
