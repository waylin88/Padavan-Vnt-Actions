/*
 * printerd.c - single-process USB printer discovery daemon.
 *
 * Replaces the "mdnsd + dns-sd" bundle and the standalone SNMP agent with
 * one process that owns both UDP sockets:
 *
 *   224.0.0.251:5353                mDNS / DNS-SD responder
 *   161/udp                         SNMP v1/v2c printer MIB agent
 *
 * Both views are rebuilt from the same live table (printer_table.c), so
 * the mDNS name, the SNMP description and the web status page can never
 * drift apart.  The daemon listens with a single select() loop; SIGHUP
 * (sent by the usb hotplug helper) forces an atomic rescan.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <unistd.h>
#include <errno.h>
#include <time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/select.h>

#include "rc.h"
#include "printer_table.h"

/* printer_mdns.c */
void mdns_set_table(const printer_slot_t *slots);
int  mdns_start(void);
void mdns_stop(void);
int  mdns_fd(void);
void mdns_handle(int fd);
void mdns_announce(void);
void mdns_tick(void);

/* printer_snmp.c */
void snmp_set_table(const printer_slot_t *slots);
int  snmp_start(void);
void snmp_stop(void);
int  snmp_fd(void);
void snmp_handle(int fd);

#define PRINTERD_PIDFILE "/var/run/printerd.pid"
#define PRINTERD_RETRY   5      /* seconds between LAN-IP retries */

static printer_slot_t g_slots[PRINTER_MAX_PORTS];
static volatile sig_atomic_t g_reload;
static volatile sig_atomic_t g_stop;

static void
on_signal(int sig)
{
	if (sig == SIGHUP)
		g_reload = 1;
	else
		g_stop = 1;
}

static void
write_pidfile(void)
{
	FILE *fp = fopen(PRINTERD_PIDFILE, "w");

	if (!fp)
		return;
	fprintf(fp, "%d\n", (int)getpid());
	fclose(fp);
}

static void
remove_pidfile(void)
{
	unlink(PRINTERD_PIDFILE);
}

/* Rescan sysfs and publish the new set on both sockets. */
static void
reload_table(void)
{
	printer_table_scan(g_slots);

	/* withdraw the old services before the table changes */
	mdns_stop();
	snmp_stop();

	mdns_set_table(g_slots);
	snmp_set_table(g_slots);

	if (printer_table_count(g_slots) > 0) {
		mdns_start();
		snmp_start();
	}
}

static int
is_printerd_pid(int pid)
{
	char path[32], buf[32];
	FILE *fp;

	snprintf(path, sizeof(path), "/proc/%d/comm", pid);
	fp = fopen(path, "r");
	if (!fp)
		return 0;
	if (!fgets(buf, sizeof(buf), fp)) {
		fclose(fp);
		return 0;
	}
	fclose(fp);

	buf[strcspn(buf, "\n")] = '\0';
	return strcmp(buf, "printerd") == 0;
}

/*
 * Ask a running printerd to rescan.  Called from the usb hotplug helper,
 * which runs in its own process, hence the signal instead of a direct
 * function call.
 */
void
printerd_reload(void)
{
	char buf[32];
	FILE *fp;
	int pid;

	fp = fopen(PRINTERD_PIDFILE, "r");
	if (!fp)
		return;

	pid = 0;
	if (fgets(buf, sizeof(buf), fp))
		pid = atoi(buf);
	fclose(fp);

	if (pid > 0 && is_printerd_pid(pid))
		kill(pid, SIGHUP);
}

int
printerd_main(int argc, char **argv)
{
	struct sigaction sa;
	time_t last_retry = 0;

	(void)argc;
	(void)argv;

	memset(&sa, 0, sizeof(sa));
	sa.sa_handler = on_signal;
	sigemptyset(&sa.sa_mask);
	sigaction(SIGHUP, &sa, NULL);
	sigaction(SIGTERM, &sa, NULL);
	sigaction(SIGINT, &sa, NULL);
	signal(SIGPIPE, SIG_IGN);

	write_pidfile();
	reload_table();

	while (!g_stop) {
		struct timeval tv;
		fd_set rfds;
		int mfd, sfd, maxfd;

		if (g_reload) {
			g_reload = 0;
			reload_table();
		}

		mfd = mdns_fd();
		sfd = snmp_fd();

		/* The LAN bridge may not have an address yet at boot. */
		if ((mfd < 0 || sfd < 0) && printer_table_count(g_slots) > 0) {
			time_t now = time(NULL);

			if (now - last_retry >= PRINTERD_RETRY) {
				last_retry = now;
				if (mfd < 0)
					mdns_start();
				if (sfd < 0)
					snmp_start();
				mfd = mdns_fd();
				sfd = snmp_fd();
			}
		}

		maxfd = -1;
		FD_ZERO(&rfds);
		if (mfd >= 0) {
			FD_SET(mfd, &rfds);
			maxfd = mfd;
		}
		if (sfd >= 0) {
			FD_SET(sfd, &rfds);
			if (sfd > maxfd)
				maxfd = sfd;
		}

		tv.tv_sec = 0;
		tv.tv_usec = 200000;
		if (maxfd >= 0) {
			/* EINTR (SIGHUP reload) leaves rfds undefined; skip. */
			if (select(maxfd + 1, &rfds, NULL, NULL, &tv) > 0) {
				if (mfd >= 0 && FD_ISSET(mfd, &rfds))
					mdns_handle(mfd);
				if (sfd >= 0 && FD_ISSET(sfd, &rfds))
					snmp_handle(sfd);
			}
		} else {
			usleep(200000);
		}

		mdns_tick();
	}

	mdns_stop();
	snmp_stop();
	remove_pidfile();
	return 0;
}
