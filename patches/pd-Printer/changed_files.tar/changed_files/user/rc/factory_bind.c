#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>

#include <openssl/rsa.h>
#include <openssl/obj_mac.h>
#include <openssl/sha.h>

#include "../shared/flash_mtd.h"
#include "factory_bind.h"
#include "factory_pub_key.h"

/* implemented in ralink.c, same helpers used by the lan/wan/radio*_eeprom_mac
 * applets */
extern int set_wired_mac(int is_wan, const char *mac);
extern int set_wireless_mac(int is_5ghz, const char *mac);

#define FAC_MTD_PART	"Factory"
#define FAC_ID_NODE	"/proc/u7c9a2"

/* record magic; bytes instead of a string so strings(1) shows nothing */
const unsigned char fac_mg[4] = { 0x96, 0x4d, 0xa1, 0x3e };

/* Read the "Factory" partition silently: rc runs with stdio on the serial
 * console and must not print anything when the record is missing/corrupt. */
static int
fac_mtd_read(unsigned char *buf, size_t count)
{
	char dev[32];
	char line[128];
	char name[64];
	unsigned int size, erasesize;
	FILE *fp;
	int fd, devnum, rd;

	fp = fopen("/proc/mtd", "r");
	if (!fp)
		return -1;

	dev[0] = '\0';
	while (fgets(line, sizeof(line), fp)) {
		if (sscanf(line, "mtd%d: %x %x \"%63[^\"]\"",
				&devnum, &size, &erasesize, name) != 4)
			continue;
		if (strcmp(name, FAC_MTD_PART) == 0) {
			snprintf(dev, sizeof(dev), "/dev/mtd%d", devnum);
			break;
		}
	}
	fclose(fp);

	if (!dev[0])
		return -1;

	fd = open(dev, O_RDONLY);
	if (fd < 0)
		return -1;

	if (lseek(fd, FAC_REC_OFFSET, SEEK_SET) < 0) {
		close(fd);
		return -1;
	}

	rd = read(fd, buf, count);
	close(fd);

	return (rd == (int)count) ? 0 : -1;
}

int
factory_bind_read_uid(unsigned char uid[8])
{
	char buf[64];
	char hex[20];
	int fd, n, i, len, all_zero;

	memset(uid, 0, 8);

	fd = open(FAC_ID_NODE, O_RDONLY);
	if (fd < 0)
		return -1;

	n = read(fd, buf, sizeof(buf) - 1);
	close(fd);

	if (n <= 0)
		return -2;

	buf[n] = '\0';
	if (sscanf(buf, "%19s", hex) != 1)
		return -2;

	len = strlen(hex);
	if (len != 8 && len != 16)
		return -2;

	for (i = 0; i < len / 2; i++) {
		unsigned int v;
		if (sscanf(hex + i * 2, "%2x", &v) != 1)
			return -2;
		uid[i] = (unsigned char)v;
	}

	all_zero = 1;
	for (i = 0; i < 8; i++) {
		if (uid[i]) {
			all_zero = 0;
			break;
		}
	}

	return all_zero ? -2 : 0;
}

static int
fac_verify_blob(const unsigned char *msg, int len, const unsigned char *sig)
{
	unsigned char digest[SHA256_DIGEST_LENGTH];
	const unsigned char *p;
	RSA *rsa;
	int ok;

	if (!msg || !sig || len <= 0 || len > 512)
		return 0;

	p = fac_pub_key_der;
	rsa = d2i_RSAPublicKey(NULL, &p, sizeof(fac_pub_key_der));
	if (!rsa)
		return 0;

	SHA256(msg, len, digest);
	ok = (RSA_verify(NID_sha256, digest, sizeof(digest),
			sig, FAC_SIG_SIZE, rsa) == 1);

	RSA_free(rsa);

	return ok;
}

static int
fac_verify(const unsigned char *rec)
{
	return fac_verify_blob(rec, FAC_REC_SIGNED, rec + FAC_REC_SIGNED);
}

int
factory_bind_verify_blob(const unsigned char *msg, int len,
			const unsigned char *sig)
{
	return fac_verify_blob(msg, len, sig) ? FAC_ST_OK : FAC_ST_MISMATCH;
}

int
factory_bind_write_mac(int target, const unsigned char mac[6])
{
	unsigned char empty[6] = { 0, 0, 0, 0, 0, 0 };
	char macstr[18];
	int rc;

	if (!mac || (mac[0] & 0x01) || memcmp(mac, empty, 6) == 0)
		return -1;

	sprintf(macstr, "%02X:%02X:%02X:%02X:%02X:%02X",
		mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]);

	/* per-board offsets, single-MAC check and the Factory write are all
	 * handled by the same helpers the eeprom_mac applets use */
	switch (target) {
	case FAC_MAC_LAN:
		rc = set_wired_mac(0, macstr);
		break;
	case FAC_MAC_WAN:
		rc = set_wired_mac(1, macstr);
		break;
	case FAC_MAC_2G:
		rc = set_wireless_mac(0, macstr);
		break;
	case FAC_MAC_5G:
#if defined (BOARD_HAS_5G_RADIO) && BOARD_HAS_5G_RADIO
		rc = set_wireless_mac(1, macstr);
#else
		return -1;	/* no 5GHz radio on this board */
#endif
		break;
	default:
		return -1;
	}

	return (rc == 0) ? 0 : -1;
}

int
factory_bind_verify(const unsigned char *rec)
{
	unsigned char uid[8];

	if (!rec)
		return FAC_ST_MISMATCH;

	if (memcmp(rec, fac_mg, 4) != 0 || rec[4] != FAC_REC_VER)
		return FAC_ST_UNBOUND;

	if (factory_bind_read_uid(uid) != 0)
		return FAC_ST_NO_UID;

	if (memcmp(rec + 6, uid, 8) != 0)
		return FAC_ST_MISMATCH;

	if (!fac_verify(rec))
		return FAC_ST_MISMATCH;

	return FAC_ST_OK;
}

int
factory_bind_status(void)
{
	unsigned char rec[FAC_REC_SIZE];
	unsigned char uid[8];
	int ret;

	ret = factory_bind_read_uid(uid);
	if (ret != 0)
		return FAC_ST_NO_UID;

	if (fac_mtd_read(rec, sizeof(rec)) != 0)
		return FAC_ST_UNBOUND;

	return factory_bind_verify(rec);
}

int
factory_bind_write(const unsigned char *rec)
{
	if (factory_bind_verify(rec) != FAC_ST_OK)
		return -1;

	if (flash_mtd_write(FAC_MTD_PART, FAC_REC_OFFSET,
			(unsigned char *)rec, FAC_REC_SIZE) != 0)
		return -2;

	return 0;
}
