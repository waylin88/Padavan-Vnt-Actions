/* -*- Mode: C; tab-width: 4 -*- */
/*
 * printer_mdns.c - minimal mDNS / DNS-SD printer responder (IPv4 only)
 *
 * Part of printerd.  The advertised instances come from the live printer
 * table built by printer_table.c (sysfs + IEEE-1284 device id), so a
 * printer is only advertised while it is physically plugged in and the
 * name never diverges from the web status page.
 *
 * Records emitted per printer:
 *   PTR  _services._dns-sd._udp.local. -> _pdl-datastream._tcp.local.
 *   PTR  _pdl-datastream._tcp.local.   -> <name> @ Printer_Port @ <port>...
 *   SRV  <instance>                    -> 0 0 <port> <host>.local.
 *   TXT  <instance>                    -> ty= product= usb_MFG= usb_MDL=
 *   A    <host>.local.                 -> LAN IPv4
 *
 * The whole protocol byte layout is built here; no libdns_sd is used.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <ctype.h>
#include <unistd.h>
#include <time.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include "rc.h"
#include "printer_table.h"

/* ------------------------------------------------------------------ */
/* constants                                                          */
/* ------------------------------------------------------------------ */
#define MDNS_GROUP     "224.0.0.251"
#define MDNS_PORT      5353
#define PKT_MAX        1500
#define TTL_STD        4500          /* same as mDNSResponder kStandardTTL */
#define MAX_SVCTYPES   4
#define MAX_INST       8
#define MAX_TXT        24
#define DEFAULT_PORT   9100

#define T_A    1
#define T_PTR  12
#define T_TXT  16
#define T_SRV  33
#define T_ANY  255

#define C_IN          1
#define C_CACHEFLUSH  0x8000
#define C_UNICAST_QU  0x8000

#define FLAG_RESPONSE 0x8400

#define W_ENUM 0x01
#define W_PTR  0x02
#define W_SRV  0x04
#define W_TXT  0x08
#define W_A    0x10
#define W_ALL  (W_ENUM | W_PTR | W_SRV | W_TXT | W_A)

#define REANNOUNCE_SEC 120

#define DEFAULT_SVCTYPE "_pdl-datastream._tcp"

/* ------------------------------------------------------------------ */
/* state                                                              */
/* ------------------------------------------------------------------ */
typedef struct {
    char name[160];                  /* instance name (display)      */
    char name_lc[160];               /* lowercase, for query match   */
    int  port;
    char txt[MAX_TXT][256];
    int  txt_count;
} inst_t;

static inst_t      g_insts[MAX_INST];
static int         g_inst_count = 0;

static char        g_svcs[MAX_SVCTYPES][64];
static int         g_svc_count = 0;

static char        g_host[64];
static char        g_hostq[80];
static unsigned    g_ip = 0;         /* LAN IPv4, network order */
static int         g_fd = -1;

static long        g_last_announce = 0;
static int         g_ann_left = 0;

/* ------------------------------------------------------------------ */
/* helpers                                                            */
/* ------------------------------------------------------------------ */
static void put16(unsigned char *b, int o, unsigned v)
{
    b[o]     = (unsigned char)(v >> 8);
    b[o + 1] = (unsigned char)(v & 0xff);
}

static void put32(unsigned char *b, int o, unsigned v)
{
    b[o]     = (unsigned char)(v >> 24);
    b[o + 1] = (unsigned char)((v >> 16) & 0xff);
    b[o + 2] = (unsigned char)((v >> 8) & 0xff);
    b[o + 3] = (unsigned char)(v & 0xff);
}

/* "a.b.local" -> \x01a\x01b\x05local\x00 */
static int put_name(unsigned char *b, int o, int limit, const char *name)
{
    const char *p = name;
    while (*p) {
        const char *dot = strchr(p, '.');
        int l = dot ? (int)(dot - p) : (int)strlen(p);
        if (l <= 0 || l > 63) return -1;
        if (o + 1 + l >= limit) return -1;
        b[o++] = (unsigned char)l;
        memcpy(b + o, p, l);
        o += l;
        if (!dot) break;
        p = dot + 1;
    }
    if (o + 1 > limit) return -1;
    b[o++] = 0;
    return o;
}

static int append_rr(unsigned char *b, int o, const char *name, unsigned type,
                     unsigned cls, int ttl, const unsigned char *rd, int rdlen)
{
    o = put_name(b, o, PKT_MAX, name);
    if (o < 0) return -1;
    if (o + 10 + rdlen > PKT_MAX) return -1;
    put16(b, o, type);          o += 2;
    put16(b, o, cls);           o += 2;
    put32(b, o, (unsigned)ttl); o += 4;
    put16(b, o, (unsigned)rdlen); o += 2;
    memcpy(b + o, rd, rdlen);   o += rdlen;
    return o;
}

static int parse_name(const unsigned char *p, int len, int off,
                      char *out, size_t outlen)
{
    size_t o = 0;
    int first = 1, jumps = 0, ret = -1;

    while (off < len) {
        unsigned char l = p[off];
        if ((l & 0xC0) == 0xC0) {                 /* compression pointer */
            if (off + 1 >= len) return -1;
            if (ret < 0) ret = off + 2;
            if (++jumps > 16) return -1;
            off = ((l & 0x3F) << 8) | p[off + 1];
            first = 1;
            continue;
        }
        if (l == 0) { off++; break; }
        if (l > 63 || off + 1 + l > len) return -1;
        if (!first) { if (o + 1 < outlen) out[o++] = '.'; }
        for (int i = 0; i < l; i++) {
            if (o + 1 < outlen) out[o++] = (char)tolower(p[off + 1 + i]);
        }
        first = 0;
        off += 1 + l;
    }
    if (ret < 0) ret = off;
    out[o < outlen ? o : outlen - 1] = 0;
    return ret;
}

static void str_tolower(char *dst, size_t n, const char *src)
{
    size_t i;
    for (i = 0; src[i] && i + 1 < n; i++) dst[i] = (char)tolower((unsigned char)src[i]);
    dst[i] = 0;
}

static void sanitize_host(char *dst, size_t n, const char *src)
{
    size_t i;
    for (i = 0; src[i] && i + 1 < n; i++) {
        unsigned char c = (unsigned char)src[i];
        dst[i] = (isalnum(c) || c == '-') ? (char)tolower(c) : '-';
    }
    if (i == 0) { snprintf(dst, n, "padavan"); return; }
    dst[i] = 0;
}

/* replace or append one "key=value" TXT item */
static void set_txt(inst_t *in, const char *kv)
{
    const char *eq = strchr(kv, '=');
    size_t klen = eq ? (size_t)(eq - kv) : strlen(kv);
    for (int i = 0; i < in->txt_count; i++) {
        const char *e2 = strchr(in->txt[i], '=');
        size_t l2 = e2 ? (size_t)(e2 - in->txt[i]) : strlen(in->txt[i]);
        if (klen == l2 && strncasecmp(in->txt[i], kv, klen) == 0) {
            snprintf(in->txt[i], sizeof in->txt[0], "%s", kv);
            return;
        }
    }
    if (in->txt_count < MAX_TXT)
        snprintf(in->txt[in->txt_count++], sizeof in->txt[0], "%s", kv);
}

static int build_txt_rdata(unsigned char *rd, const inst_t *in)
{
    int o = 0;
    for (int i = 0; i < in->txt_count; i++) {
        int l = (int)strlen(in->txt[i]);
        if (l > 255) l = 255;
        if (o + 1 + l > 512) return -1;
        rd[o++] = (unsigned char)l;
        memcpy(rd + o, in->txt[i], l);
        o += l;
    }
    if (o == 0) rd[o++] = 0;
    return o;
}

static int build_srv_rdata(unsigned char *rd, int port, const char *host)
{
    int o = 0;
    rd[o++] = 0; rd[o++] = 0;
    rd[o++] = 0; rd[o++] = 0;
    rd[o++] = (unsigned char)((port >> 8) & 0xff);
    rd[o++] = (unsigned char)(port & 0xff);
    return put_name(rd, o, 512, host);
}

/* ------------------------------------------------------------------ */
/* packet assembly                                                    */
/* ------------------------------------------------------------------ */
static unsigned char g_pkt[PKT_MAX];

static int build_packet(unsigned char *b, int ttl, unsigned mask,
                        int sel_inst, int sel_svc)
{
    int o = 12, an = 0, r;
    char inst_full[320], svc_full[80];
    unsigned char rd[512];
    static const char enumq[] = "_services._dns-sd._udp.local";

    if (mask & W_ENUM) {
        for (int t = 0; t < g_svc_count; t++) {
            if (sel_svc >= 0 && t != sel_svc) continue;
            r = put_name(rd, 0, 512, g_svcs[t]);
            if (r < 0) return -1;
            o = append_rr(b, o, enumq, T_PTR, C_IN, ttl, rd, r);
            if (o < 0) return -1;
            an++;
        }
    }

    for (int t = 0; t < g_svc_count; t++) {
        if (sel_svc >= 0 && t != sel_svc) continue;
        snprintf(svc_full, sizeof svc_full, "%s", g_svcs[t]);
        for (int i = 0; i < g_inst_count; i++) {
            const inst_t *in = &g_insts[i];
            int port;
            if (sel_inst >= 0 && i != sel_inst) continue;
            port = in->port > 0 ? in->port : DEFAULT_PORT;
            snprintf(inst_full, sizeof inst_full, "%s.%s", in->name, svc_full);

            if (mask & W_PTR) {
                r = put_name(rd, 0, 512, inst_full);
                if (r < 0) return -1;
                o = append_rr(b, o, svc_full, T_PTR, C_IN, ttl, rd, r);
                if (o < 0) return -1;
                an++;
            }
            if (mask & W_SRV) {
                r = build_srv_rdata(rd, port, g_hostq);
                if (r < 0) return -1;
                o = append_rr(b, o, inst_full, T_SRV, C_IN | C_CACHEFLUSH, ttl, rd, r);
                if (o < 0) return -1;
                an++;
            }
            if (mask & W_TXT) {
                r = build_txt_rdata(rd, in);
                if (r < 0) return -1;
                o = append_rr(b, o, inst_full, T_TXT, C_IN | C_CACHEFLUSH, ttl, rd, r);
                if (o < 0) return -1;
                an++;
            }
        }
    }

    if (mask & W_A) {
        memcpy(rd, &g_ip, 4);
        o = append_rr(b, o, g_hostq, T_A, C_IN | C_CACHEFLUSH, ttl, rd, 4);
        if (o < 0) return -1;
        an++;
    }

    if (o < 0) return -1;
    put16(b, 0, 0);
    put16(b, 2, FLAG_RESPONSE);
    put16(b, 4, 0);
    put16(b, 6, (unsigned)an);
    put16(b, 8, 0);
    put16(b, 10, 0);
    return o;
}

/* ------------------------------------------------------------------ */
/* network                                                            */
/* ------------------------------------------------------------------ */
static void send_packet(int fd, const unsigned char *pkt, int len,
                        const struct sockaddr_in *dst)
{
    if (fd < 0) return;
    sendto(fd, pkt, (size_t)len, 0,
           (const struct sockaddr *)dst, sizeof *dst);
}

/*
 * Send one response.  All records normally fit in a single datagram, but
 * four printers with long model names can exceed PKT_MAX; in that case
 * fall back to one datagram per instance so nothing is silently dropped
 * (build_packet() fails as a whole, it never truncates).
 */
static void send_built(int fd, int ttl, unsigned mask, int sel_inst,
                       int sel_svc, const struct sockaddr_in *dst)
{
    unsigned per = mask & (W_PTR | W_SRV | W_TXT | W_A);
    int len, i;

    len = build_packet(g_pkt, ttl, mask, sel_inst, sel_svc);
    if (len >= 0) {
        send_packet(fd, g_pkt, len, dst);
        return;
    }

    if (mask & W_ENUM) {
        len = build_packet(g_pkt, ttl, W_ENUM, -1, sel_svc);
        if (len >= 0)
            send_packet(fd, g_pkt, len, dst);
    }
    for (i = 0; i < g_inst_count && per; i++) {
        if (sel_inst >= 0 && i != sel_inst)
            continue;
        len = build_packet(g_pkt, ttl, per, i, sel_svc);
        if (len >= 0)
            send_packet(fd, g_pkt, len, dst);
    }
}

static void send_announce(int fd, int ttl, unsigned mask)
{
    struct sockaddr_in dst;

    if (fd < 0 || g_ip == 0 || g_inst_count == 0)
        return;

    memset(&dst, 0, sizeof dst);
    dst.sin_family = AF_INET;
    dst.sin_port   = htons(MDNS_PORT);
    dst.sin_addr.s_addr = inet_addr(MDNS_GROUP);
    send_built(fd, ttl, mask, -1, -1, &dst);
}

static void handle_query(int fd, const unsigned char *p, int len,
                         const struct sockaddr_in *from)
{
    unsigned flags, qd;
    int off = 12;
    unsigned mask = 0;
    int unicast = 0;
    int sel_inst = -1, sel_svc = -1, sel_set = 0;
    char qn[256], instq[400];

    if (len < 12) return;
    flags = (unsigned)((p[2] << 8) | p[3]);
    if (flags & 0x8000) return;
    qd = (unsigned)((p[4] << 8) | p[5]);
    if (qd == 0) return;

    for (unsigned i = 0; i < qd; i++) {
        int no = parse_name(p, len, off, qn, sizeof qn);
        unsigned qt, qc;
        if (no < 0 || no + 4 > len) return;
        qt = (unsigned)((p[no] << 8) | p[no + 1]);
        qc = (unsigned)((p[no + 2] << 8) | p[no + 3]);
        off = no + 4;

        if (qc & C_UNICAST_QU) unicast = 1;
        /* one-shot queries come from an ephemeral port: reply unicast */
        if (from->sin_port != htons(MDNS_PORT)) unicast = 1;

        if (qt == T_PTR || qt == T_ANY) {
            if (strcmp(qn, "_services._dns-sd._udp.local") == 0) {
                mask |= W_ENUM;
                sel_inst = -1; sel_svc = -1;
            }
            for (int t = 0; t < g_svc_count; t++) {
                if (strcmp(qn, g_svcs[t]) == 0) {
                    mask |= W_PTR | W_SRV | W_TXT | W_A;
                    if (!sel_set) { sel_inst = -1; sel_svc = t; sel_set = 1; }
                    else if (sel_inst != -1 || sel_svc != t) { sel_inst = -1; sel_svc = -1; }
                }
            }
        }
        for (int t = 0; t < g_svc_count; t++) {
            for (int i2 = 0; i2 < g_inst_count; i2++) {
                snprintf(instq, sizeof instq, "%s.%s", g_insts[i2].name_lc, g_svcs[t]);
                if (strcmp(qn, instq) != 0) continue;
                if (qt == T_SRV || qt == T_ANY) mask |= W_SRV | W_A;
                if (qt == T_TXT || qt == T_ANY) mask |= W_TXT;
                if (!sel_set) { sel_inst = i2; sel_svc = t; sel_set = 1; }
                else if (sel_inst != i2 || sel_svc != t) { sel_inst = -1; sel_svc = -1; }
            }
        }
        if ((qt == T_A || qt == T_ANY) && strcmp(qn, g_hostq) == 0)
            mask |= W_A;
    }

    if (!mask) return;

    if (unicast) {
        send_built(fd, TTL_STD, mask, sel_inst, sel_svc, from);
    } else {
        struct sockaddr_in dst;
        memset(&dst, 0, sizeof dst);
        dst.sin_family = AF_INET;
        dst.sin_port   = htons(MDNS_PORT);
        dst.sin_addr.s_addr = inet_addr(MDNS_GROUP);
        send_built(fd, TTL_STD, mask, sel_inst, sel_svc, &dst);
    }
}

/* ------------------------------------------------------------------ */
/* printerd interface                                                 */
/* ------------------------------------------------------------------ */

/* Rebuild the instance list from the live printer table. */
void mdns_set_table(const printer_slot_t *slots)
{
    int i;

    g_inst_count = 0;
    if (!slots)
        return;

    for (i = 0; i < PRINTER_MAX_PORTS; i++) {
        const printer_slot_t *s = &slots[i];
        inst_t *in;
        char buf[320];
        char suffix[32];
        int avail;

        if (!s->present) continue;
        if (g_inst_count >= MAX_INST) break;

        in = &g_insts[g_inst_count++];
        memset(in, 0, sizeof(*in));
        in->port = s->port;

        /* A DNS label is limited to 63 octets.  Keep the port suffix so
         * instances stay distinguishable even if the model name is cut. */
        snprintf(suffix, sizeof suffix, " @ Printer_Port @ %d", s->port);
        avail = 63 - (int)strlen(suffix);
        if (avail < 1)
            avail = 1;
        snprintf(in->name, sizeof(in->name), "%.*s%s", avail, s->name, suffix);
        str_tolower(in->name_lc, sizeof(in->name_lc), in->name);

        in->txt_count = 0;
        snprintf(buf, sizeof(buf), "ty=%s", s->name);
        set_txt(in, buf);
        snprintf(buf, sizeof(buf), "product=%s", s->name);
        set_txt(in, buf);
        snprintf(buf, sizeof(buf), "usb_MFG=%s", s->mfg[0] ? s->mfg : s->brand);
        set_txt(in, buf);
        snprintf(buf, sizeof(buf), "usb_MDL=%s", s->mdl[0] ? s->mdl : s->name);
        set_txt(in, buf);
    }
}

/* Announce the current instances (defined below). */
void mdns_announce(void);

/* Open the mDNS socket and announce the current instances. */
int mdns_start(void)
{
    int fd, one = 1;
    struct sockaddr_in bindaddr;
    struct ip_mreq mreq;
    struct in_addr local;
    char hostbuf[128];
    uint32_t ip = printer_lan_ip();

    if (!ip)
        return -1;
    g_ip = (unsigned)ip;

    if (gethostname(hostbuf, sizeof hostbuf) == 0 && hostbuf[0] &&
        strcmp(hostbuf, "localhost") != 0) {
        sanitize_host(g_host, sizeof g_host, hostbuf);
    } else {
        sanitize_host(g_host, sizeof g_host, "padavan");
    }
    snprintf(g_hostq, sizeof g_hostq, "%s.local", g_host);

    if (g_svc_count == 0)
        snprintf(g_svcs[g_svc_count++], sizeof g_svcs[0], "%s.local", DEFAULT_SVCTYPE);

    fd = socket(AF_INET, SOCK_DGRAM, 0);
    if (fd < 0)
        return -1;
    setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &one, sizeof one);
#ifdef SO_REUSEPORT
    setsockopt(fd, SOL_SOCKET, SO_REUSEPORT, &one, sizeof one);
#endif

    memset(&bindaddr, 0, sizeof bindaddr);
    bindaddr.sin_family = AF_INET;
    bindaddr.sin_port = htons(MDNS_PORT);
    bindaddr.sin_addr.s_addr = htonl(INADDR_ANY);
    if (bind(fd, (struct sockaddr *)&bindaddr, sizeof bindaddr) < 0) {
        close(fd);
        return -1;
    }

    local.s_addr = g_ip;
    setsockopt(fd, IPPROTO_IP, IP_MULTICAST_IF, &local, sizeof local);

    memset(&mreq, 0, sizeof mreq);
    mreq.imr_multiaddr.s_addr = inet_addr(MDNS_GROUP);
    mreq.imr_interface.s_addr = g_ip;
    setsockopt(fd, IPPROTO_IP, IP_ADD_MEMBERSHIP, &mreq, sizeof mreq);

    {
        unsigned char ttl = 255, loop = 1;
        setsockopt(fd, IPPROTO_IP, IP_MULTICAST_TTL, &ttl, sizeof ttl);
        setsockopt(fd, IPPROTO_IP, IP_MULTICAST_LOOP, &loop, sizeof loop);
    }

    g_fd = fd;
    mdns_announce();
    return fd;
}

/* Send goodbye and close the socket. */
void mdns_stop(void)
{
    if (g_fd < 0)
        return;

    send_announce(g_fd, 0, W_ALL);
    send_announce(g_fd, 0, W_ALL);
    close(g_fd);
    g_fd = -1;
}

int mdns_fd(void)
{
    return g_fd;
}

/* First announce plus two retries one second apart. */
void mdns_announce(void)
{
    send_announce(g_fd, TTL_STD, W_ALL);
    g_ann_left = 2;
    g_last_announce = (long)time(NULL);
}

/* Periodic re-announce; called from the printerd loop. */
void mdns_tick(void)
{
    long now;

    if (g_fd < 0)
        return;

    now = (long)time(NULL);
    if (g_ann_left > 0) {
        if (now - g_last_announce >= 1) {
            send_announce(g_fd, TTL_STD, W_ALL);
            g_ann_left--;
            g_last_announce = now;
        }
    } else if (now - g_last_announce >= REANNOUNCE_SEC) {
        send_announce(g_fd, TTL_STD, W_ALL);
        g_last_announce = now;
    }
}

/* Consume and answer one query packet. */
void mdns_handle(int fd)
{
    struct sockaddr_in from;
    socklen_t fromlen = sizeof from;
    ssize_t n;

    n = recvfrom(fd, g_pkt, sizeof g_pkt, 0,
                 (struct sockaddr *)&from, &fromlen);
    if (n <= 0)
        return;

    /* ignore our own multicast loopback */
    if (from.sin_addr.s_addr == g_ip)
        return;

    handle_query(fd, g_pkt, (int)n, &from);
}
