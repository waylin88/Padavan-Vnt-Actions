#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>

#include "factory_bind.h"
#include "factory_uid.h"

static int fac_restricted;

void
factory_uid_init(void)
{
	unsigned char uid[8];
	int ret;

	fac_restricted = 0;

	ret = factory_bind_read_uid(uid);
	if (ret == -1) {
		/* the kernel id node does not exist: no uid patch in this build,
		 * uid patch.  Locking every unit out would be worse than letting
		 * this build boot normally. */
		return;
	}

	if (ret == -2)
		fac_restricted = 1;
	else
		fac_restricted = (factory_bind_status() != FAC_ST_OK);

	if (fac_restricted) {
		/* marker for httpd, which must not expose the system command page */
		close(open("/tmp/.fac_restricted", O_CREAT | O_WRONLY, 0644));
	}

	/* the maintenance listener is NOT started here: factory mode stays off
	 * until someone opens it explicitly with a POST to /factory.cgi */
}

int
factory_uid_restricted(void)
{
	return fac_restricted;
}
