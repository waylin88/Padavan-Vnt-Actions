<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="/bootstrap/css/toggle.css">
<script type="text/javascript" src="/jquery.js"></script>
<style>
* { box-sizing: border-box; }
body { margin: 0; padding: 14px 24px; font-family: Arial, "Microsoft YaHei", sans-serif; background: #fff; color: #000; font-size: 14px; }
.container { max-width: 760px; margin: 0 auto; }
.card { background: #fff; border-radius: 8px; padding: 0 0 8px; margin-bottom: 16px; }
.card h3 { margin: 0 0 16px 0; font-size: 16px; color: #000; border-bottom: 1px solid #eee; padding-bottom: 10px; }
.card .card-body { padding: 0; }
.row { display: flex; align-items: center; margin-bottom: 12px; }
.row > label { width: 140px; flex-shrink: 0; color: #888; text-align: right; padding-right: 12px; }
.row .ctrl { flex: 1; }
form { max-width: 460px; margin: 0 auto; }
input[type="text"], input[type="password"], select { width: 100%; max-width: 320px; padding: 7px 10px; border: 1px solid #d0d0d0; border-radius: 4px; font-size: 14px; color: #333; height: 36px; }
input[type="text"]:focus, input[type="password"]:focus, select:focus { border-color: #ff6a00; outline: none; }
/* .btn / .btn-row 已移至公用样式 /bootstrap/css/toggle.css */
.section-divider { border: none; border-top: 1px solid #eee; margin: 16px 0; }
.enable-label { font-size: 14px; color: #000; }
/* Band header: plain text aligns with label column, color tag follows it, switch at tail */
.band-header { display: flex; align-items: center; margin: 0 0 12px 0; }
.band-header .band-title { width: 140px; flex-shrink: 0; text-align: right; padding-right: 12px; color: #888; font-size: 14px; font-weight: normal; white-space: nowrap; }
.band-header .band-ctrl { flex: 1; display: flex; align-items: center; justify-content: flex-end; }
.band-tag { display: inline-block; padding: 2px 8px; border-radius: 4px; font-size: 12px; margin-left: 8px; flex-shrink: 0; }
.band-2g { background: #fff3e0; color: #e65100; }
.band-5g { background: #e3f2fd; color: #1565c0; }
.toggle-row { display: flex; align-items: center; max-width: 460px; margin: 0 auto 16px; }
.toggle-row > label { width: 140px; flex-shrink: 0; color: #888; text-align: right; padding-right: 12px; }
.toggle-row .ctrl { flex: 1; }
.bridge-settings { transition: opacity .2s; }
.bridge-settings.disabled { display: none; }
/* Connection badge placed at end of SSID row */
.bridge-conn-badge { display: inline-block; padding: 2px 10px; border-radius: 10px; font-size: 12px; margin-left: 8px; flex-shrink: 0; }
.bridge-conn-badge.connected { background: #e8f5e9; color: #2e7d32; }
.bridge-conn-badge.disconnected { background: #ffebee; color: #c62828; }
.bridge-conn-badge.connecting { background: #fff3e0; color: #e65100; }
.ctrl-with-badge { display: flex; align-items: center; flex: 1; }
.ssid-wrap { position: relative; flex: 0 0 320px; max-width: 320px; }
.ssid-wrap input { width: 100%; padding-right: 36px; }
.ssid-dropdown-btn {
	position: absolute; right: 1px; top: 1px; bottom: 1px; width: 34px;
	background: #f5f5f5; border: none; border-left: 1px solid #d0d0d0;
	border-radius: 0 4px 4px 0; cursor: pointer; display: flex;
	align-items: center; justify-content: center;
}
.ssid-dropdown-btn:hover { background: #fff0e0; }
.ssid-dropdown-btn svg { width: 14px; height: 14px; fill: #666; transition: transform .2s; }
@media (max-width: 600px) {
	body { padding: 10px 10px; }
	.row > label { width: 90px; font-size: 13px; }
	.toggle-row > label { width: 90px; }
	.toggle-row { max-width: none; }
	.band-header .band-title { width: 90px; }
	input[type="text"], input[type="password"], select { max-width: none; }
	.ssid-wrap { max-width: none; flex: 1 1 auto; }
	form { max-width: none; }
	/* Hide connection badge on mobile due to width */
	.bridge-conn-badge { display: none; }
}
</style>
</head>
<body>
<div class="container">

<div class="card">
	<h3>无线设置</h3>
	<div class="card-body">
	<iframe name="hidden_frame_ap" id="hidden_frame_ap" src="" width="0" height="0" frameborder="0"></iframe>
	<form method="post" name="formAP" action="/start_apply.htm" target="hidden_frame_ap">
		<input type="hidden" name="current_page" value="wireless.asp">
		<input type="hidden" name="next_page" value="wireless.asp">
		<input type="hidden" name="next_host" value="">
		<input type="hidden" name="sid_list" value="WLANConfig11a;WLANConfig11b;">
		<input type="hidden" name="group_id" value="">
		<input type="hidden" name="action_mode" value=" Apply ">
		<input type="hidden" name="action_script" value="">

		<div class="band-header">
			<span class="band-title">2.4G WiFi</span>
			<span class="band-tag band-2g">2.4GHz</span>
			<div class="band-ctrl">
				<label class="enable-switch">
					<input type="checkbox" id="rt_radio_x_cb" onchange="document.getElementById('rt_radio_x').value=this.checked?'1':'0'">
					<span class="enable-slider"></span>
				</label>
			</div>
		</div>
		<input type="hidden" name="rt_radio_x" id="rt_radio_x" value="<% nvram_get_x("", "rt_radio_x"); %>">
		<div class="row">
			<label>WiFi 名称</label>
			<div class="ctrl"><input type="text" name="rt_ssid" value="<% nvram_get_x("", "rt_ssid"); %>" maxlength="32"></div>
		</div>
		<div class="row">
			<label>隐藏 WiFi</label>
			<div class="ctrl">
				<label class="enable-switch">
					<input type="checkbox" name="rt_closed" value="1" <% nvram_match_x("", "rt_closed", "1", "checked"); %>>
					<span class="enable-slider"></span>
				</label>
			</div>
		</div>
		<div class="row">
			<label>认证方式</label>
			<div class="ctrl">
				<select name="rt_auth_mode" onchange="togglePsk2g()">
					<option value="open" <% nvram_match_x("", "rt_auth_mode", "open", "selected"); %>>开放 (无密码)</option>
					<option value="psk" <% nvram_match_x("", "rt_auth_mode", "psk", "selected"); %>>WPA/WPA2 个人</option>
				</select>
			</div>
		</div>
		<div id="rtPskRow" class="row" style="display:none;">
			<label>WiFi 密码</label>
			<div class="ctrl"><input type="text" name="rt_wpa_psk" value="<% nvram_get_x("", "rt_wpa_psk"); %>" maxlength="64" placeholder="至少8位"></div>
		</div>

		<div id="band5gSection">
		<hr class="section-divider">

		<div class="band-header">
			<span class="band-title">5G WiFi</span>
			<span class="band-tag band-5g">5GHz</span>
			<div class="band-ctrl">
				<label class="enable-switch">
					<input type="checkbox" id="wl_radio_x_cb" onchange="document.getElementById('wl_radio_x').value=this.checked?'1':'0'">
					<span class="enable-slider"></span>
				</label>
			</div>
		</div>
		<input type="hidden" name="wl_radio_x" id="wl_radio_x" value="<% nvram_get_x("", "wl_radio_x"); %>">
		<div class="row">
			<label>WiFi 名称</label>
			<div class="ctrl"><input type="text" name="wl_ssid" value="<% nvram_get_x("", "wl_ssid"); %>" maxlength="32"></div>
		</div>
		<div class="row">
			<label>隐藏 WiFi</label>
			<div class="ctrl">
				<label class="enable-switch">
					<input type="checkbox" name="wl_closed" value="1" <% nvram_match_x("", "wl_closed", "1", "checked"); %>>
					<span class="enable-slider"></span>
				</label>
			</div>
		</div>
		<div class="row">
			<label>认证方式</label>
			<div class="ctrl">
				<select name="wl_auth_mode" onchange="togglePsk5g()">
					<option value="open" <% nvram_match_x("", "wl_auth_mode", "open", "selected"); %>>开放 (无密码)</option>
					<option value="psk" <% nvram_match_x("", "wl_auth_mode", "psk", "selected"); %>>WPA/WPA2 个人</option>
				</select>
			</div>
		</div>
		<div id="wlPskRow" class="row" style="display:none;">
			<label>WiFi 密码</label>
			<div class="ctrl"><input type="text" name="wl_wpa_psk" value="<% nvram_get_x("", "wl_wpa_psk"); %>" maxlength="64" placeholder="至少8位"></div>
		</div>
		</div><!-- /band5gSection -->

		<div class="btn-row">
			<button type="submit" class="btn" onclick="if(parent&&parent.showLoading)parent.showLoading(15,'正在应用WiFi设置，无线重启中...',true);">保存 WiFi 设置</button>
		</div>
	</form>
	</div>
</div>

<div class="card" id="bridgeCard">
	<h3>无线桥接</h3>
	<div class="card-body">

	<div class="toggle-row">
		<label>启用</label>
		<div class="ctrl">
			<label class="enable-switch">
				<input type="checkbox" id="bridgeEnable" onchange="toggleBridge()">
				<span class="enable-slider"></span>
			</label>
		</div>
	</div>

	<div class="bridge-settings" id="bridgeSettings">
	<iframe name="hidden_frame_bridge" id="hidden_frame_bridge" src="" width="0" height="0" frameborder="0"></iframe>
	<form method="post" name="formBridge" action="/start_apply.htm" target="hidden_frame_bridge">
		<input type="hidden" name="current_page" value="wireless.asp">
		<input type="hidden" name="next_page" value="wireless.asp">
		<input type="hidden" name="next_host" value="">
		<input type="hidden" name="group_id" value="">
		<input type="hidden" name="action_mode" value=" Apply ">
		<input type="hidden" name="action_script" value="">
		<input type="hidden" name="sid_list" value="WLANConfig11a;WLANConfig11b;">

		<input type="hidden" name="rt_mode_x" id="rt_mode_x" value="<% nvram_get_x("", "rt_mode_x"); %>">
		<input type="hidden" name="rt_radio_x" value="1">
		<input type="hidden" name="rt_country_code" value="CN">
		<input type="hidden" name="rt_wdsapply_x" value="0">
		<input type="hidden" name="rt_wdsnum_x_0" value="0">
		<input type="hidden" name="rt_wdslist_x_0" value="">
		<input type="hidden" name="rt_sta_auth_mode" id="rt_sta_auth_mode" value="<% nvram_get_x("", "rt_sta_auth_mode"); %>">
		<input type="hidden" name="rt_sta_wpa_mode" value="2">
		<input type="hidden" name="rt_sta_crypto" value="aes">
		<!-- Default WISP mode (AP-Client+AP WISP) -->
		<input type="hidden" name="rt_sta_wisp" id="rt_sta_wisp" value="1">
		<input type="hidden" name="rt_sta_auto" value="1">
		<input type="hidden" name="rt_sta_ssid_org" value="">
		<input type="hidden" name="rt_sta_wpa_psk_org" value="">

		<div id="bridge5gFields">
		<input type="hidden" name="wl_mode_x" id="wl_mode_x" value="<% nvram_get_x("", "wl_mode_x"); %>">
		<input type="hidden" name="wl_radio_x" value="1">
		<input type="hidden" name="wl_country_code" value="CN">
		<input type="hidden" name="wl_wdsapply_x" value="0">
		<input type="hidden" name="wl_wdsnum_x_0" value="0">
		<input type="hidden" name="wl_wdslist_x_0" value="">
		<input type="hidden" name="wl_sta_auth_mode" id="wl_sta_auth_mode" value="<% nvram_get_x("", "wl_sta_auth_mode"); %>">
		<input type="hidden" name="wl_sta_wpa_mode" value="2">
		<input type="hidden" name="wl_sta_crypto" value="aes">
		<!-- Default WISP mode (AP-Client+AP WISP) -->
		<input type="hidden" name="wl_sta_wisp" id="wl_sta_wisp" value="1">
		<input type="hidden" name="wl_sta_auto" value="1">
		<input type="hidden" name="wl_sta_ssid_org" value="">
		<input type="hidden" name="wl_sta_wpa_psk_org" value="">
		</div><!-- /bridge5gFields -->

		<div class="row">
			<label>上级 WiFi 名称</label>
			<div class="ctrl ctrl-with-badge">
				<div class="ssid-wrap">
					<input type="text" id="upstream_ssid" value="" placeholder="点击右侧按钮搜索" readonly style="background:#f5f5f5;cursor:not-allowed;">
					<button type="button" class="ssid-dropdown-btn" id="ssidDropdownBtn" onclick="if(parent&&parent.openWifiModal)parent.openWifiModal();" title="搜索WiFi">
						<svg viewBox="0 0 24 24"><path d="M15.5 14h-.79l-.28-.27a6.5 6.5 0 0 0 1.48-5.34c-.47-2.78-2.79-5-5.59-5.34a6.505 6.505 0 0 0-7.27 7.27c.34 2.8 2.56 5.12 5.34 5.59a6.5 6.5 0 0 0 5.34-1.48l.27.28v.79l4.25 4.25c.41.41 1.08.41 1.49 0 .41-.41.41-1.08 0-1.49L15.5 14zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"/></svg>
					</button>
				</div>
				<span class="bridge-conn-badge connecting" id="curStatus">查询中...</span>
				<input type="hidden" name="rt_sta_ssid" id="rt_sta_ssid" value="<% nvram_get_x("", "rt_sta_ssid"); %>">
				<input type="hidden" name="wl_sta_ssid" id="wl_sta_ssid" value="<% nvram_get_x("", "wl_sta_ssid"); %>">
			</div>
		</div>
		<div class="row">
			<label>认证方式</label>
			<div class="ctrl">
				<select id="sta_auth_mode" onchange="toggleStaPsk()">
					<option value="open">开放</option>
					<option value="psk" selected>WPA/WPA2 个人</option>
				</select>
			</div>
		</div>
		<div id="staPskRow" class="row">
			<label>上级 WiFi 密码</label>
			<div class="ctrl">
				<input type="text" id="sta_psk" placeholder="上级 WiFi 的密码">
				<input type="hidden" name="rt_sta_wpa_psk" id="rt_sta_wpa_psk" value="<% nvram_get_x("", "rt_sta_wpa_psk"); %>">
				<input type="hidden" name="wl_sta_wpa_psk" id="wl_sta_wpa_psk" value="<% nvram_get_x("", "wl_sta_wpa_psk"); %>">
			</div>
		</div>

	</div>

		<div class="btn-row">
			<button type="submit" class="btn" onclick="return onBridgeApply()">应用桥接设置</button>
		</div>
	</form>

	</div>
</div>

</div>

<script>
<% firmware_caps_hook(); %>
var selectedBand = "";
var $j = jQuery.noConflict();
var has5gRadio = (typeof support_5g_radio === "function") ? !!support_5g_radio() : true;

function togglePsk2g() {
	var open = document.formAP.rt_auth_mode.value === "open";
	document.getElementById("rtPskRow").style.display = open ? "none" : "";
}
function togglePsk5g() {
	var open = document.formAP.wl_auth_mode.value === "open";
	document.getElementById("wlPskRow").style.display = open ? "none" : "";
}
function toggleStaPsk() {
	var open = document.getElementById("sta_auth_mode").value === "open";
	document.getElementById("staPskRow").style.display = open ? "none" : "";
}

/* ── Bridge enable/disable toggle ── */
function toggleBridge() {
	var enabled = document.getElementById("bridgeEnable").checked;
	var settings = document.getElementById("bridgeSettings");
	if (enabled) {
		settings.style.display = "";
		settings.classList.remove("disabled");
	} else {
		settings.style.display = "none";
		/* Set both modes to 0 (AP only) to disable bridging */
		document.getElementById("rt_mode_x").value = "0";
		document.getElementById("wl_mode_x").value = "0";
		document.getElementById("rt_sta_wisp").value = "0";
		document.getElementById("wl_sta_wisp").value = "0";
	}
}

/* ── Apply selected AP (called from parent WiFi scan modal) ── */
function applySelectedAP(decoded, band, sec) {
	selectedBand = band;
	document.getElementById("upstream_ssid").value = decoded;

	/* Auto-fill auth mode based on security info */
	var authSelect = document.getElementById("sta_auth_mode");
	if (sec && sec.toUpperCase().indexOf("WPA") >= 0) {
		authSelect.value = "psk";
	} else if (sec && sec.toUpperCase().indexOf("OPEN") >= 0) {
		authSelect.value = "open";
	} else {
		/* default to psk (most common) */
		authSelect.value = "psk";
	}
	toggleStaPsk();

	/* Set mode_x=4 (AP-Client+AP), wisp=1 (WISP) by default */
	if (band === "2g") {
		document.getElementById("rt_sta_ssid").value = decoded;
		document.getElementById("wl_sta_ssid").value = "";
		document.getElementById("rt_mode_x").value = "4";
		document.getElementById("wl_mode_x").value = "0";
		document.getElementById("rt_sta_wisp").value = "1";
		document.getElementById("wl_sta_wisp").value = "0";
	} else {
		document.getElementById("wl_sta_ssid").value = decoded;
		document.getElementById("rt_sta_ssid").value = "";
		document.getElementById("wl_mode_x").value = "4";
		document.getElementById("rt_mode_x").value = "0";
		document.getElementById("wl_sta_wisp").value = "1";
		document.getElementById("rt_sta_wisp").value = "0";
	}

	/* Focus password field for quick entry */
	setTimeout(function() { document.getElementById("sta_psk").focus(); }, 150);
}

function onBridgeApply() {
	var enabled = document.getElementById("bridgeEnable").checked;
	if (!enabled) {
		/* Bridge disabled: mode_x already set to 0 by toggleBridge(), just submit */
		if (parent && parent.showLoading) {
			parent.showLoading(8, "正在关闭桥接...", true);
		}
		return true;
	}
	var ssid = document.getElementById("upstream_ssid").value;
	if (!ssid) {
		alert("请先搜索并选择上级 WiFi");
		return false;
	}
	var psk = document.getElementById("sta_psk").value;
	var auth = document.getElementById("sta_auth_mode").value;
	document.getElementById("rt_sta_wpa_psk").value = psk;
	document.getElementById("wl_sta_wpa_psk").value = psk;
	document.getElementById("rt_sta_auth_mode").value = auth;
	document.getElementById("wl_sta_auth_mode").value = auth;
	/* Default WISP mode */
	if (document.getElementById("rt_mode_x").value === "4") {
		document.getElementById("rt_sta_wisp").value = "1";
	}
	if (document.getElementById("wl_mode_x").value === "4") {
		document.getElementById("wl_sta_wisp").value = "1";
	}
	if (auth === "psk" && psk.length < 8) {
		alert("密码至少需要 8 位");
		return false;
	}
	/* 无线会重启复位，loading 后停留在当前页面不刷新 */
	if (parent && parent.showLoading) {
		parent.showLoading(20, "正在应用桥接设置，无线重启中...", true);
	}
	return true;
}

/* ── Bridge status (mode row removed per requirement) ── */
function loadBridgeStatus() {
	$j.ajax({
		url: '/bridge_status.asp',
		dataType: 'script',
		timeout: 5000,
		success: function() {
			if (typeof bridge_status !== 'undefined') {
				updateStatusDisplay(bridge_status);
			}
		},
		error: function() {
			var el = document.getElementById("curStatus");
			if (el) {
				el.textContent = "查询失败";
				el.className = "bridge-conn-badge disconnected";
			}
		}
	});
}

function updateStatusDisplay(s) {
	var statusEl = document.getElementById("curStatus");
	if (!statusEl) return;
	var activeMode = s.mode === 4 ? s.mode : (s.mode5g === 4 ? s.mode5g : 0);
	if (activeMode === 0) {
		statusEl.textContent = "未启用桥接";
		statusEl.className = "bridge-conn-badge disconnected";
		return;
	}
	if (s.connected) {
		statusEl.textContent = "已连接";
		statusEl.className = "bridge-conn-badge connected";
	} else {
		statusEl.textContent = "未连接";
		statusEl.className = "bridge-conn-badge disconnected";
	}
}

togglePsk2g();
togglePsk5g();
toggleStaPsk();

/* Initialize WiFi radio toggles from nvram */
(function() {
	var rtRadio = document.getElementById("rt_radio_x").value;
	var wlRadio = document.getElementById("wl_radio_x").value;
	document.getElementById("rt_radio_x_cb").checked = (rtRadio === "1" || rtRadio === "");
	document.getElementById("wl_radio_x_cb").checked = (wlRadio === "1" || wlRadio === "");
})();

/* ── Auto-fill bridge settings from NVRAM (original firmware style) ── */
function initBridgeSettings() {
	var rtMode = document.getElementById("rt_mode_x").value;
	var wlMode = document.getElementById("wl_mode_x").value;
	var rtSsid = document.getElementById("rt_sta_ssid").value;
	var wlSsid = document.getElementById("wl_sta_ssid").value;
	var rtPsk = document.getElementById("rt_sta_wpa_psk").value;
	var wlPsk = document.getElementById("wl_sta_wpa_psk").value;
	var rtAuth = document.getElementById("rt_sta_auth_mode").value;
	var wlAuth = document.getElementById("wl_sta_auth_mode").value;

	/* Set toggle state: bridge enabled if either mode is 4 (AP-Client+AP) */
	var bridgeEnabled = (rtMode === "4" || wlMode === "4");
	document.getElementById("bridgeEnable").checked = bridgeEnabled;
	toggleBridge();

	/* Determine active band: 2.4G if rt_mode_x==4, 5G if wl_mode_x==4 */
	if (rtMode === "4" && rtSsid) {
		/* 2.4G bridge active, fill fields */
		document.getElementById("upstream_ssid").value = rtSsid;
		document.getElementById("sta_auth_mode").value = rtAuth || "psk";
		document.getElementById("sta_psk").value = rtPsk || "";
		selectedBand = "2g";
	} else if (wlMode === "4" && wlSsid) {
		/* 5G bridge active, fill fields */
		document.getElementById("upstream_ssid").value = wlSsid;
		document.getElementById("sta_auth_mode").value = wlAuth || "psk";
		document.getElementById("sta_psk").value = wlPsk || "";
		selectedBand = "5g";
	}
	toggleStaPsk();
}
initBridgeSettings();

/* ── Single-band device: hide & strip all 5G related options ── */
if (!has5gRadio) {
	var s5 = document.getElementById("band5gSection");
	if (s5) {
		s5.style.display = "none";
		var sels = s5.querySelectorAll("input, select, textarea");
		for (var i = 0; i < sels.length; i++) sels[i].disabled = true;
	}
	var b5 = document.getElementById("bridge5gFields");
	if (b5) {
		var bels = b5.querySelectorAll("input");
		for (var k = 0; k < bels.length; k++) bels[k].disabled = true;
	}
	/* bridge SSID / PSK hidden fields that also write the 5G radio */
	var wlSsidEl = document.getElementById("wl_sta_ssid");
	if (wlSsidEl) wlSsidEl.disabled = true;
	var wlPskEl = document.getElementById("wl_sta_wpa_psk");
	if (wlPskEl) wlPskEl.disabled = true;
}

loadBridgeStatus();
setInterval(loadBridgeStatus, 15000);
</script>
</body>
</html>
