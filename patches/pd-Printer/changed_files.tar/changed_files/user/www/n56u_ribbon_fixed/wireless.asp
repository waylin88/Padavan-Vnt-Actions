<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="/bootstrap/css/toggle.css">
<script type="text/javascript" src="/jquery.js"></script>
<link rel="stylesheet" type="text/css" href="/bootstrap/css/page.css">
<link rel="stylesheet" type="text/css" href="/bootstrap/css/wireless.css">
</head>
<body>
<div class="container">

<div class="card">
	<h3><#Wl_WirelessSettings#></h3>
	<div class="card-body">
	<iframe name="hidden_frame_ap" id="hidden_frame_ap" src="" width="0" height="0" frameborder="0"></iframe>
	<form method="post" name="formAP" action="/start_apply.htm" target="hidden_frame_ap">
		<input type="hidden" name="current_page" value="wireless.asp">
		<input type="hidden" name="next_page" value="wireless.asp">
		<input type="hidden" name="next_host" value="">
		<input type="hidden" name="sid_list" value="WLANConfig11a;WLANConfig11b;">
		<input type="hidden" name="group_id" value="">
		<input type="hidden" name="action_mode" value=" Apply ">
		<input type="hidden" name="action_script" value="">

		<div class="band-header">
			<span class="band-title">2.4G WiFi</span>
			<span class="band-tag band-2g">2.4GHz</span>
			<div class="band-ctrl">
				<label class="enable-switch">
					<input type="checkbox" id="rt_radio_x_cb" onchange="document.getElementById('rt_radio_x').value=this.checked?'1':'0'">
					<span class="enable-slider"></span>
				</label>
			</div>
		</div>
		<input type="hidden" name="rt_radio_x" id="rt_radio_x" value="<% nvram_get_x("", "rt_radio_x"); %>">
		<div class="row">
			<label><#Wl_WifiName#></label>
			<div class="ctrl"><input type="text" name="rt_ssid" value="<% nvram_get_x("", "rt_ssid"); %>" maxlength="32"></div>
		</div>
		<div class="row">
			<label><#Wl_HideWifi#></label>
			<div class="ctrl">
				<label class="enable-switch">
					<input type="checkbox" name="rt_closed" value="1" <% nvram_match_x("", "rt_closed", "1", "checked"); %>>
					<span class="enable-slider"></span>
				</label>
			</div>
		</div>
		<div class="row">
			<label><#Wl_AuthMethod#></label>
			<div class="ctrl">
				<select name="rt_auth_mode" onchange="togglePsk2g()">
					<option value="open" <% nvram_match_x("", "rt_auth_mode", "open", "selected"); %>><#Wl_OpenNoPassword#></option>
					<option value="psk" <% nvram_match_x("", "rt_auth_mode", "psk", "selected"); %>><#Wl_WpaWpa2Personal#></option>
				</select>
			</div>
		</div>
		<div id="rtPskRow" class="row" style="display:none;">
			<label><#Wl_WifiPassword#></label>
			<div class="ctrl"><input type="text" name="rt_wpa_psk" value="<% nvram_get_x("", "rt_wpa_psk"); %>" maxlength="64" placeholder="<#Wl_AtLeast8Chars#>"></div>
		</div>

		<div id="band5gSection">
		<hr class="section-divider">

		<div class="band-header">
			<span class="band-title">5G WiFi</span>
			<span class="band-tag band-5g">5GHz</span>
			<div class="band-ctrl">
				<label class="enable-switch">
					<input type="checkbox" id="wl_radio_x_cb" onchange="document.getElementById('wl_radio_x').value=this.checked?'1':'0'">
					<span class="enable-slider"></span>
				</label>
			</div>
		</div>
		<input type="hidden" name="wl_radio_x" id="wl_radio_x" value="<% nvram_get_x("", "wl_radio_x"); %>">
		<div class="row">
			<label><#Wl_WifiName#></label>
			<div class="ctrl"><input type="text" name="wl_ssid" value="<% nvram_get_x("", "wl_ssid"); %>" maxlength="32"></div>
		</div>
		<div class="row">
			<label><#Wl_HideWifi#></label>
			<div class="ctrl">
				<label class="enable-switch">
					<input type="checkbox" name="wl_closed" value="1" <% nvram_match_x("", "wl_closed", "1", "checked"); %>>
					<span class="enable-slider"></span>
				</label>
			</div>
		</div>
		<div class="row">
			<label><#Wl_AuthMethod#></label>
			<div class="ctrl">
				<select name="wl_auth_mode" onchange="togglePsk5g()">
					<option value="open" <% nvram_match_x("", "wl_auth_mode", "open", "selected"); %>><#Wl_OpenNoPassword#></option>
					<option value="psk" <% nvram_match_x("", "wl_auth_mode", "psk", "selected"); %>><#Wl_WpaWpa2Personal#></option>
				</select>
			</div>
		</div>
		<div id="wlPskRow" class="row" style="display:none;">
			<label><#Wl_WifiPassword#></label>
			<div class="ctrl"><input type="text" name="wl_wpa_psk" value="<% nvram_get_x("", "wl_wpa_psk"); %>" maxlength="64" placeholder="<#Wl_AtLeast8Chars#>"></div>
		</div>
		</div><!-- /band5gSection -->

		<div class="btn-row">
			<button type="submit" class="btn" onclick="if(parent&&parent.showLoading)parent.showLoading(15,'<#Wl_ApplyingWifiRestart#>',true);"><#Wl_SaveWifiSettings#></button>
		</div>
	</form>
	</div>
</div>

<div class="card" id="bridgeCard">
	<h3><#Wl_WirelessBridge#></h3>
	<div class="card-body">

	<div class="toggle-row">
		<label><#Wl_Enable#></label>
		<div class="ctrl">
			<label class="enable-switch">
				<input type="checkbox" id="bridgeEnable" onchange="toggleBridge()">
				<span class="enable-slider"></span>
			</label>
		</div>
	</div>

	<div class="bridge-settings" id="bridgeSettings">
	<iframe name="hidden_frame_bridge" id="hidden_frame_bridge" src="" width="0" height="0" frameborder="0"></iframe>
	<form method="post" name="formBridge" action="/start_apply.htm" target="hidden_frame_bridge">
		<input type="hidden" name="current_page" value="wireless.asp">
		<input type="hidden" name="next_page" value="wireless.asp">
		<input type="hidden" name="next_host" value="">
		<input type="hidden" name="group_id" value="">
		<input type="hidden" name="action_mode" value=" Apply ">
		<input type="hidden" name="action_script" value="">
		<input type="hidden" name="sid_list" value="WLANConfig11a;WLANConfig11b;">

		<input type="hidden" name="rt_mode_x" id="rt_mode_x" value="<% nvram_get_x("", "rt_mode_x"); %>">
		<input type="hidden" name="rt_radio_x" value="1">
		<input type="hidden" name="rt_country_code" value="CN">
		<input type="hidden" name="rt_wdsapply_x" value="0">
		<input type="hidden" name="rt_wdsnum_x_0" value="0">
		<input type="hidden" name="rt_wdslist_x_0" value="">
		<input type="hidden" name="rt_sta_auth_mode" id="rt_sta_auth_mode" value="<% nvram_get_x("", "rt_sta_auth_mode"); %>">
		<input type="hidden" name="rt_sta_wpa_mode" value="2">
		<input type="hidden" name="rt_sta_crypto" value="aes">
		<!-- Default WISP mode (AP-Client+AP WISP) -->
		<input type="hidden" name="rt_sta_wisp" id="rt_sta_wisp" value="1">
		<input type="hidden" name="rt_sta_auto" value="1">
		<input type="hidden" name="rt_sta_ssid_org" value="">
		<input type="hidden" name="rt_sta_wpa_psk_org" value="">

		<div id="bridge5gFields">
		<input type="hidden" name="wl_mode_x" id="wl_mode_x" value="<% nvram_get_x("", "wl_mode_x"); %>">
		<input type="hidden" name="wl_radio_x" value="1">
		<input type="hidden" name="wl_country_code" value="CN">
		<input type="hidden" name="wl_wdsapply_x" value="0">
		<input type="hidden" name="wl_wdsnum_x_0" value="0">
		<input type="hidden" name="wl_wdslist_x_0" value="">
		<input type="hidden" name="wl_sta_auth_mode" id="wl_sta_auth_mode" value="<% nvram_get_x("", "wl_sta_auth_mode"); %>">
		<input type="hidden" name="wl_sta_wpa_mode" value="2">
		<input type="hidden" name="wl_sta_crypto" value="aes">
		<!-- Default WISP mode (AP-Client+AP WISP) -->
		<input type="hidden" name="wl_sta_wisp" id="wl_sta_wisp" value="1">
		<input type="hidden" name="wl_sta_auto" value="1">
		<input type="hidden" name="wl_sta_ssid_org" value="">
		<input type="hidden" name="wl_sta_wpa_psk_org" value="">
		</div><!-- /bridge5gFields -->

		<div class="row">
			<label><#Wl_UpstreamWifiName#></label>
			<div class="ctrl ctrl-with-badge">
				<div class="ssid-wrap">
					<input type="text" id="upstream_ssid" value="" placeholder="<#Wl_ClickRightButtonToSearch#>" readonly style="background:#f5f5f5;cursor:not-allowed;">
					<button type="button" class="ssid-dropdown-btn" id="ssidDropdownBtn" onclick="if(parent&&parent.openWifiModal)parent.openWifiModal();" title="<#Wl_SearchWifi#>">
						<svg viewBox="0 0 24 24"><path d="M15.5 14h-.79l-.28-.27a6.5 6.5 0 0 0 1.48-5.34c-.47-2.78-2.79-5-5.59-5.34a6.505 6.505 0 0 0-7.27 7.27c.34 2.8 2.56 5.12 5.34 5.59a6.5 6.5 0 0 0 5.34-1.48l.27.28v.79l4.25 4.25c.41.41 1.08.41 1.49 0 .41-.41.41-1.08 0-1.49L15.5 14zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"/></svg>
					</button>
				</div>
				<span class="bridge-conn-badge connecting" id="curStatus"><#Wl_Querying#></span>
				<input type="hidden" name="rt_sta_ssid" id="rt_sta_ssid" value="<% nvram_get_x("", "rt_sta_ssid"); %>">
				<input type="hidden" name="wl_sta_ssid" id="wl_sta_ssid" value="<% nvram_get_x("", "wl_sta_ssid"); %>">
			</div>
		</div>
		<div class="row">
			<label><#Wl_AuthMethod#></label>
			<div class="ctrl">
				<select id="sta_auth_mode" onchange="toggleStaPsk()">
					<option value="open"><#Wl_Open#></option>
					<option value="psk" selected><#Wl_WpaWpa2Personal#></option>
				</select>
			</div>
		</div>
		<div id="staPskRow" class="row">
			<label><#Wl_UpstreamWifiPassword#></label>
			<div class="ctrl">
				<input type="text" id="sta_psk" placeholder="<#Wl_UpstreamWifiPasswordPlaceholder#>">
				<input type="hidden" name="rt_sta_wpa_psk" id="rt_sta_wpa_psk" value="<% nvram_get_x("", "rt_sta_wpa_psk"); %>">
				<input type="hidden" name="wl_sta_wpa_psk" id="wl_sta_wpa_psk" value="<% nvram_get_x("", "wl_sta_wpa_psk"); %>">
			</div>
		</div>

	</div>

		<div class="btn-row">
			<button type="submit" class="btn" onclick="return onBridgeApply()"><#Wl_ApplyBridgeSettings#></button>
		</div>
	</form>

	</div>
</div>

</div>

<script type="text/javascript" src="/bootstrap/js/wireless.js"></script>
</body>
</html>
