wds_aplist_2g = <% wl_scan_2g(); %>;
