<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="/bootstrap/css/toggle.css">
<link rel="stylesheet" type="text/css" href="/bootstrap/css/page.css">
<link rel="stylesheet" type="text/css" href="/bootstrap/css/more.css">
</head>
<body>
<div class="container">

<!-- WORK_MODE_BEGIN -->
<!-- 工作模式（编译开关 CONFIG_FIRMWARE_INCLUDE_WORK_MODE） -->
<div class="card">
	<h3><#More_WorkMode#></h3>
	<iframe name="hidden_frame_mode" id="hidden_frame_mode" src="" width="0" height="0" frameborder="0"></iframe>
	<form method="post" name="formMode" action="/start_apply.htm" target="hidden_frame_mode">
		<input type="hidden" name="current_page" value="more.asp">
		<input type="hidden" name="next_page" value="more.asp">
		<input type="hidden" name="next_host" value="">
		<input type="hidden" name="sid_list" value="IPConnection;">
		<input type="hidden" name="group_id" value="">
		<input type="hidden" name="action_mode" value=" Apply ">
		<input type="hidden" name="action_script" value="">

		<label class="mode-opt" onclick="syncModeSel()">
			<input type="radio" name="sw_mode" value="1" onchange="syncModeSel()" <% nvram_match_x("", "sw_mode", "1", "checked"); %>>
			<span><b><#More_RouterMode#></b><small><#More_RouterModeDesc#></small></span>
		</label>
		<label class="mode-opt" onclick="syncModeSel()">
			<input type="radio" name="sw_mode" value="3" onchange="syncModeSel()" <% nvram_match_x("", "sw_mode", "3", "checked"); %>>
			<span><b><#More_ApMode#></b><small><#More_ApModeDesc#></small></span>
		</label>

		<div class="btn-row">
			<button type="submit" class="btn" onclick="return onModeApply()"><#More_ApplyReboot#></button>
		</div>
	</form>
</div>
<!-- WORK_MODE_END -->

<!-- 自动重启 -->
<div class="card">
	<h3><#More_AutoReboot#></h3>
	<iframe name="hidden_frame_reboot" id="hidden_frame_reboot" src="" width="0" height="0" frameborder="0"></iframe>
	<form method="post" name="formAutoReboot" action="/start_apply.htm" target="hidden_frame_reboot">
		<input type="hidden" name="current_page" value="more.asp">
		<input type="hidden" name="next_page" value="more.asp">
		<input type="hidden" name="next_host" value="">
		<input type="hidden" name="sid_list" value="MoreConfig;">
		<input type="hidden" name="group_id" value="">
		<input type="hidden" name="action_mode" value=" Apply ">
		<input type="hidden" name="action_script" value="">

		<input type="hidden" name="sched_reboot_enable" id="sched_reboot_enable" value="<% nvram_get_x("", "sched_reboot_enable"); %>">
		<div class="row">
			<label><#More_AutoRebootEnable#></label>
			<div class="ctrl">
				<label class="enable-switch">
					<input type="checkbox" id="schedRebootEnableCb" onchange="syncAutoReboot()" <% nvram_match_x("", "sched_reboot_enable", "1", "checked"); %>>
					<span class="enable-slider"></span>
				</label>
			</div>
		</div>
		<div class="row" id="schedRebootDaysRow">
			<label><#More_AutoRebootDays#></label>
			<div class="ctrl">
				<input type="hidden" name="sched_reboot_days" id="sched_reboot_days" value="<% nvram_get_x("", "sched_reboot_days"); %>">
				<div class="day-chips" id="schedRebootDays">
					<label class="day"><input type="checkbox" class="day-cb" onchange="syncRebootDays()"><span><#More_DaySun#></span></label>
					<label class="day"><input type="checkbox" class="day-cb" onchange="syncRebootDays()"><span><#More_DayMon#></span></label>
					<label class="day"><input type="checkbox" class="day-cb" onchange="syncRebootDays()"><span><#More_DayTue#></span></label>
					<label class="day"><input type="checkbox" class="day-cb" onchange="syncRebootDays()"><span><#More_DayWed#></span></label>
					<label class="day"><input type="checkbox" class="day-cb" onchange="syncRebootDays()"><span><#More_DayThu#></span></label>
					<label class="day"><input type="checkbox" class="day-cb" onchange="syncRebootDays()"><span><#More_DayFri#></span></label>
					<label class="day"><input type="checkbox" class="day-cb" onchange="syncRebootDays()"><span><#More_DaySat#></span></label>
				</div>
			</div>
		</div>
		<div class="row" id="schedRebootTimeRow">
			<label><#More_AutoRebootTime#></label>
			<div class="ctrl">
				<input type="time" name="sched_reboot_time" id="sched_reboot_time" value="<% nvram_get_x("", "sched_reboot_time"); %>">
			</div>
		</div>

		<div class="btn-row">
			<button type="submit" class="btn" onclick="return onAutoRebootApply()"><#More_Save#></button>
		</div>
	</form>
</div>

<!-- 恢复出厂设置 -->
<div class="card">
	<h3><#More_FactoryReset#></h3>
	<p class="tip"><#More_FactoryResetTip#></p>
	<div class="btn-row">
		<button type="button" class="danger-btn" onclick="doFactoryReset()"><#More_FactoryReset#></button>
	</div>
</div>

</div>
<script type="text/javascript" src="/bootstrap/js/more.js"></script>
</body>
</html>