<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="/bootstrap/css/toggle.css">
<style>
* { box-sizing: border-box; }
body { margin: 0; padding: 14px 24px; font-family: Arial, "Microsoft YaHei", sans-serif; background: #fff; color: #000; font-size: 14px; }
.container { max-width: 760px; margin: 0 auto; }
.card { background: #fff; border-radius: 8px; padding: 0 0 16px; margin-bottom: 16px; }
.card h3 { margin: 0 0 16px 0; font-size: 16px; color: #000; border-bottom: 1px solid #eee; padding-bottom: 10px; }
.tip { color: #888; font-size: 13px; line-height: 1.8; margin: 0 0 18px 0; }
/* Work mode options */
form { max-width: 460px; margin: 0 auto; }
.mode-opt { display: flex; align-items: flex-start; gap: 10px; padding: 12px 14px; border: 1px solid #e5e5e5; border-radius: 6px; cursor: pointer; margin-bottom: 10px; transition: all .15s; }
.mode-opt:hover { border-color: #ffb066; background: #fffaf5; }
.mode-opt.selected { border-color: #ff6a00; background: #fff6ee; }
.mode-opt input[type="radio"] { margin: 2px 0 0 0; flex-shrink: 0; accent-color: #ff6a00; }
.mode-opt b { display: block; color: #000; font-size: 14px; margin-bottom: 3px; }
.mode-opt small { color: #999; font-size: 12px; line-height: 1.5; }
/* .btn / .danger-btn / .btn-row 已移至公用样式 /bootstrap/css/toggle.css */
@media (max-width: 600px) {
	body { padding: 10px 10px; }
	form { max-width: none; }
}
</style>
</head>
<body>
<div class="container">

<!-- 工作模式 -->
<div class="card">
	<h3>工作模式</h3>
	<iframe name="hidden_frame_mode" id="hidden_frame_mode" src="" width="0" height="0" frameborder="0"></iframe>
	<form method="post" name="formMode" action="/start_apply.htm" target="hidden_frame_mode">
		<input type="hidden" name="current_page" value="more.asp">
		<input type="hidden" name="next_page" value="more.asp">
		<input type="hidden" name="next_host" value="">
		<input type="hidden" name="sid_list" value="IPConnection;">
		<input type="hidden" name="group_id" value="">
		<input type="hidden" name="action_mode" value=" Apply ">
		<input type="hidden" name="action_script" value="">

		<label class="mode-opt" onclick="syncModeSel()">
			<input type="radio" name="sw_mode" value="1" onchange="syncModeSel()" <% nvram_match_x("", "sw_mode", "1", "checked"); %>>
			<span><b>路由模式</b><small>WAN 口接入外网，提供 NAT、防火墙与 DHCP，作为主路由器。</small></span>
		</label>
		<label class="mode-opt" onclick="syncModeSel()">
			<input type="radio" name="sw_mode" value="3" onchange="syncModeSel()" <% nvram_match_x("", "sw_mode", "3", "checked"); %>>
			<span><b>AP 模式</b><small>WAN 口桥接为 LAN，仅作为无线接入点/交换机，由上级路由器分配 IP。</small></span>
		</label>

		<div class="btn-row">
			<button type="submit" class="btn" onclick="return onModeApply()">应用并重启</button>
		</div>
	</form>
</div>

<!-- 恢复出厂设置 -->
<div class="card">
	<h3>恢复出厂设置</h3>
	<p class="tip">此操作会清空设备的全部配置并自动重启，恢复到出厂状态。</p>
	<div class="btn-row">
		<button type="button" class="danger-btn" onclick="doFactoryReset()">恢复出厂设置</button>
	</div>
</div>

</div>
<script>
/* ── 工作模式 ── */
function syncModeSel() {
	var opts = document.querySelectorAll(".mode-opt");
	for (var i = 0; i < opts.length; i++) {
		var r = opts[i].querySelector("input[type=radio]");
		opts[i].className = "mode-opt" + (r && r.checked ? " selected" : "");
	}
}
function onModeApply() {
	if (!confirm("切换工作模式后设备将自动重启，是否继续？"))
		return false;
	if (parent && parent.showLoading)
		parent.showLoading(40, "正在切换工作模式，设备重启中，请稍候...");
	return true;
}
syncModeSel();

/* ── 恢复出厂设置 ──
 * NVRAM 与 /etc/storage 由后端同步复位，随后设备重启；
 * 恢复后管理地址回到默认的 192.168.2.1。 */
function doFactoryReset() {
	if (!confirm("确定要恢复出厂设置吗？\n\n设备全部配置（NVRAM 与 /etc/storage）将被清除，并自动重启。此操作不可撤销。"))
		return;

	/* 提交复位请求（后端会同步复位 NVRAM 与 /etc/storage 并重启） */
	var iframe = document.createElement("iframe");
	iframe.name = "reset_frame";
	iframe.style.display = "none";
	document.body.appendChild(iframe);
	var form = document.createElement("form");
	form.method = "post";
	form.action = "/apply.cgi";
	form.target = iframe.name;
	form.innerHTML = '<input type="hidden" name="action_mode" value=" RestoreAll ">'
		+ '<input type="hidden" name="current_page" value="more.asp">'
		+ '<input type="hidden" name="next_page" value="more.asp">';
	document.body.appendChild(form);
	form.submit();

	/* 全屏加载提示，并在设备重启后跳转到默认管理地址 */
	try {
		if (parent && typeof parent.showLoading === "function")
			parent.showLoading(0, "正在恢复出厂设置，设备重启中，请稍候...");
	} catch(e) {}
	setTimeout(function() {
		try { parent.location.href = "http://192.168.2.1/"; } catch(e) { location.href = "http://192.168.2.1/"; }
	}, 45000);
}
</script>
</body>
</html>