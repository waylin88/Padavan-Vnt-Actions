<% wanlink(); %>
var bridge_status = {
	mode: parseInt("<% nvram_get_x("", "rt_mode_x"); %>") || 0,
	mode5g: parseInt("<% nvram_get_x("", "wl_mode_x"); %>") || 0,
	wisp: parseInt("<% nvram_get_x("", "rt_sta_wisp"); %>") || 0,
	wisp5g: parseInt("<% nvram_get_x("", "wl_sta_wisp"); %>") || 0,
	upstream_ssid: (parseInt("<% nvram_get_x("", "wl_mode_x"); %>") === 4) ? "<% nvram_get_x("", "wl_sta_ssid"); %>" : "<% nvram_get_x("", "rt_sta_ssid"); %>",
	upstream_band: (parseInt("<% nvram_get_x("", "wl_mode_x"); %>") === 4) ? "5G" : "2.4G",
	/* WISP 模式下 wanlink 提供状态；中继模式下需命令行查询 apcli 接口 */
	connected: (typeof wanlink_apclilink === 'function') ? (wanlink_apclilink() !== "---" && wanlink_apclilink() !== "") : false,
	apcli_bssid: (typeof wanlink_apclilink === 'function') ? wanlink_apclilink() : "",
	ipaddr: (typeof wanlink_ip4_wan === 'function') ? wanlink_ip4_wan() : "",
	wan_status: (typeof wanlink_status === 'function') ? wanlink_status() : -1,
	wan_type: (typeof wanlink_type === 'function') ? wanlink_type() : "",
	signal: "<% nvram_get_x("", "wlan_sta_rssi"); %>"
};

/* 注意：信号强度来自 nvram(wlan_sta_rssi)。
   自动 WiFi 扫描(wl_scan_2g/5g) 会阻塞 httpd 5秒以上，已移除此处的自动扫描。
   用户在无线页面点击"扫描"时才触发扫描。 */
