<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex,nofollow">
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Expires" content="-1">
<title>系统日志</title>
<link rel="shortcut icon" href="/bootstrap/img/favicon.ico">
<link rel="icon" href="/bootstrap/img/favicon.png">
<style>
* { box-sizing: border-box; }
html, body { margin: 0; height: 100%; }
body {
	background: #fff; color: #000;
	font-family: Arial, "Microsoft YaHei", sans-serif;
	display: flex; flex-direction: column;
}
.bar {
	flex: 0 0 auto; display: flex; align-items: center; gap: 14px;
	padding: 10px 14px; border-bottom: 1px solid #ddd;
}
.bar h1 { margin: 0; font-size: 15px; font-weight: bold; color: #000; }
.bar .stamp { color: #888; font-size: 12px; }
.bar .spacer { margin-left: auto; }
.bar label {
	display: flex; align-items: center; gap: 6px;
	color: #333; font-size: 13px; cursor: pointer; user-select: none;
}
.bar input[type="checkbox"] { accent-color: #ff6a00; }
.bar button {
	padding: 5px 14px; font-size: 13px; color: #333; background: #f5f5f5;
	border: 1px solid #ccc; border-radius: 4px; cursor: pointer;
}
.bar button:hover { background: #eee; }
.bar button:active { background: #e5e5e5; }
#logBox {
	flex: 1 1 auto; margin: 10px 14px 14px; padding: 8px 10px;
	background: #fff; color: #000;
	border: 1px solid #ccc; border-radius: 4px;
	overflow: auto; white-space: pre; font-size: 12px; line-height: 1.55;
	font-family: "Courier New", Consolas, monospace;
}
@media (max-width: 600px) {
	#logBox { font-size: 11px; }
	.bar .stamp { display: none; }
}
</style>
</head>
<body>
<div class="bar">
	<h1>系统日志</h1>
	<span class="stamp" id="stamp">加载中…</span>
	<span class="spacer"></span>
	<label><input type="checkbox" id="autoRefresh" checked>自动刷新</label>
	<button type="button" id="refreshBtn">刷新</button>
</div>
<pre id="logBox">正在加载…</pre>
<script>
(function () {
	var REFRESH_MS = 5000;
	var box = document.getElementById("logBox");
	var stamp = document.getElementById("stamp");
	var auto = document.getElementById("autoRefresh");
	var timer = null;
	var stickBottom = true;

	/* 用户停留在底部时跟随最新日志，手动上翻后保持当前位置 */
	function checkFollow() {
		stickBottom = (box.scrollHeight - box.clientHeight - box.scrollTop) < 8;
	}

	function load() {
		var xhr = new XMLHttpRequest();
		xhr.open("GET", "/syslog.txt?t=" + (new Date()).getTime(), true);
		xhr.onload = function () {
			if (xhr.status === 200) {
				box.textContent = xhr.responseText;
				if (stickBottom)
					box.scrollTop = box.scrollHeight;
				stamp.textContent = "更新于 " + (new Date()).toLocaleTimeString();
			} else {
				stamp.textContent = "加载失败（" + xhr.status + "）";
			}
		};
		xhr.onerror = function () { stamp.textContent = "加载失败"; };
		xhr.send();
	}

	/* 按勾选状态（重新）启动定时刷新 */
	function schedule() {
		if (timer) { clearInterval(timer); timer = null; }
		if (auto.checked)
			timer = setInterval(load, REFRESH_MS);
	}

	box.addEventListener("scroll", checkFollow);
	box.addEventListener("touchmove", checkFollow);
	auto.addEventListener("change", function () {
		if (auto.checked) load();
		schedule();
	});
	document.getElementById("refreshBtn").addEventListener("click", function () {
		load();
		schedule();
	});

	load();
	schedule();
})();
</script>
</body>
</html>
