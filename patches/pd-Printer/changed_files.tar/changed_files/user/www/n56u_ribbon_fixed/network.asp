<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="/bootstrap/css/toggle.css">
<style>
* { box-sizing: border-box; }
body { margin: 0; padding: 14px 24px; font-family: Arial, "Microsoft YaHei", sans-serif; background: #fff; color: #000; font-size: 14px; }
.container { max-width: 760px; margin: 0 auto; }
.card { background: #fff; border-radius: 8px; padding: 0 0 8px; margin-bottom: 16px; }
.card h3 { margin: 0 0 16px 0; font-size: 16px; color: #000; border-bottom: 1px solid #eee; padding-bottom: 10px; display: flex; align-items: center; justify-content: space-between; }
.card h3 .title-btn { background: none; border: 1px solid #ff6a00; color: #ff6a00; padding: 4px 12px; border-radius: 4px; cursor: pointer; font-size: 12px; }
.card h3 .title-btn:hover { background: #fff0e0; }
.row { display: flex; align-items: center; margin-bottom: 12px; }
.row > label { width: 140px; flex-shrink: 0; color: #888; text-align: right; padding-right: 12px; }
.row .ctrl { flex: 1; }
form { max-width: 460px; margin: 0 auto; }
input[type="text"], input[type="password"], select { width: 100%; max-width: 320px; padding: 7px 10px; border: 1px solid #d0d0d0; border-radius: 4px; font-size: 14px; color: #333; height: 36px; }
input[type="text"]:focus, input[type="password"]:focus, select:focus { border-color: #ff6a00; outline: none; }
/* .btn / .btn-row 已移至公用样式 /bootstrap/css/toggle.css */
.dhcp-extra { margin: 4px 0 12px 0; }
.helper-text { font-size: 12px; color: #999; margin-top: 4px; line-height: 1.5; }
.client-table { width: 100%; border-collapse: collapse; font-size: 13px; }
.client-table th, .client-table td { text-align: left; padding: 8px 10px; border-bottom: 1px solid #f0f0f0; white-space: nowrap; }
.client-table th { color: #888; font-weight: normal; border-bottom: 1px solid #eee; }
.client-table td.name { max-width: 220px; overflow: hidden; text-overflow: ellipsis; }
.client-table tr:last-child td { border-bottom: none; }
.client-badge { display: inline-block; font-size: 12px; padding: 1px 8px; border-radius: 10px; }
.client-badge.on { background: #e8f5e9; color: #2e7d32; }
.client-badge.off { background: #f0f0f0; color: #999; }
@media (max-width: 600px) {
	body { padding: 10px 10px; }
	.row > label { width: 100px; }
	input[type="text"], input[type="password"], select { max-width: none; }
	form { max-width: none; }
}
</style>
</head>
<body>
<div class="container">

<!-- WAN 设置（仅路由模式显示） -->
<div class="card" id="cardWan">
	<h3>WAN 设置 <button type="button" class="title-btn" onclick="fixStaticIp()">一键固定设备IP</button></h3>
	<iframe name="hidden_frame_wan" id="hidden_frame_wan" src="" width="0" height="0" frameborder="0"></iframe>
	<form method="post" name="formWan" action="/start_apply.htm" target="hidden_frame_wan">
		<input type="hidden" name="current_page" value="network.asp">
		<input type="hidden" name="next_page" value="network.asp">
		<input type="hidden" name="next_host" value="">
		<input type="hidden" name="sid_list" value="Layer3Forwarding;LANHostConfig;IPConnection;PPPConnection;WLANConfig11b">
		<input type="hidden" name="group_id" value="">
		<input type="hidden" name="action_mode" value=" Apply ">
		<input type="hidden" name="action_script" value="">
		<input type="hidden" name="lan_ipaddr" value="<% nvram_get_x("", "lan_ipaddr"); %>">
		<input type="hidden" name="lan_netmask" value="<% nvram_get_x("", "lan_netmask"); %>">

		<div class="row">
			<label>连接类型</label>
			<div class="ctrl">
				<select name="wan_proto" onchange="toggleWanFields()">
					<option value="dhcp" <% nvram_match_x("", "wan_proto", "dhcp", "selected"); %>>自动获取</option>
					<option value="static" <% nvram_match_x("", "wan_proto", "static", "selected"); %>>静态地址</option>
					<option value="pppoe" <% nvram_match_x("", "wan_proto", "pppoe", "selected"); %>>宽带拨号</option>
				</select>
			</div>
		</div>

		<div id="staticFields" style="display:none;">
			<div class="row">
				<label>IP 地址</label>
				<div class="ctrl"><input type="text" name="wan_ipaddr" value="<% nvram_get_x("", "wan_ipaddr"); %>"></div>
			</div>
			<div class="row">
				<label>子网掩码</label>
				<div class="ctrl"><input type="text" name="wan_netmask" value="<% nvram_get_x("", "wan_netmask"); %>"></div>
			</div>
			<div class="row">
				<label>网关</label>
				<div class="ctrl"><input type="text" name="wan_gateway" value="<% nvram_get_x("", "wan_gateway"); %>"></div>
			</div>
		</div>

		<div id="pppoeFields" style="display:none;">
			<div class="row">
				<label>用户名</label>
				<div class="ctrl"><input type="text" name="wan_pppoe_username" value="<% nvram_get_x("", "wan_pppoe_username"); %>"></div>
			</div>
			<div class="row">
				<label>密码</label>
				<div class="ctrl"><input type="password" name="wan_pppoe_passwd" value="<% nvram_get_x("", "wan_pppoe_passwd"); %>"></div>
			</div>
		</div>

		<div class="row">
			<label>MTU</label>
			<div class="ctrl"><input type="text" name="wan_mtu" value="<% nvram_get_x("", "wan_mtu"); %>" style="max-width:120px;"></div>
		</div>

		<div id="dnsSelectRow" class="row">
			<label>DNS 设置</label>
			<div class="ctrl">
				<label class="enable-switch">
					<input type="checkbox" id="wanDnsEnable" onchange="toggleDns()">
					<span class="enable-slider"></span>
				</label>
				<input type="hidden" name="wan_dnsenable_x" id="wan_dnsenable_x" value="<% nvram_get_x("", "wan_dnsenable_x"); %>">
			</div>
		</div>

		<div id="dnsFields" style="display:none;">
			<div class="row">
				<label>DNS 1</label>
				<div class="ctrl"><input type="text" name="wan_dns1_x" value="<% nvram_get_x("", "wan_dns1_x"); %>"></div>
			</div>
			<div class="row">
				<label>DNS 2</label>
				<div class="ctrl"><input type="text" name="wan_dns2_x" value="<% nvram_get_x("", "wan_dns2_x"); %>"></div>
			</div>
		</div>

		<div class="btn-row">
			<button type="submit" class="btn" onclick="return onWanApply()">应用 WAN 设置</button>
		</div>
	</form>
</div>

<!-- 设备 IP 设置（仅 AP 模式显示） -->
<div class="card" id="cardApIp" style="display:none;">
	<h3>设备 IP 设置 <button type="button" class="title-btn" onclick="fixStaticIpAp()">一键固定设备IP</button></h3>
	<iframe name="hidden_frame_apip" id="hidden_frame_apip" src="" width="0" height="0" frameborder="0"></iframe>
	<form method="post" name="formApIp" action="/start_apply.htm" target="hidden_frame_apip">
		<input type="hidden" name="current_page" value="network.asp">
		<input type="hidden" name="next_page" value="network.asp">
		<input type="hidden" name="next_host" value="">
		<input type="hidden" name="sid_list" value="LANHostConfig;">
		<input type="hidden" name="group_id" value="">
		<input type="hidden" name="action_mode" value=" Apply ">
		<input type="hidden" name="action_script" value="">

		<div class="row">
			<label>获取方式</label>
			<div class="ctrl">
				<select name="lan_proto_x" onchange="toggleApIpFields()">
					<option value="1" <% nvram_match_x("", "lan_proto_x", "1", "selected"); %>>自动获取（从主路由）</option>
					<option value="0" <% nvram_match_x("", "lan_proto_x", "0", "selected"); %>>静态地址</option>
				</select>
			</div>
		</div>

		<div id="apStaticFields" style="display:none;">
			<div class="row">
				<label>IP 地址</label>
				<div class="ctrl"><input type="text" name="lan_ipaddr" value="<% nvram_get_x("", "lan_ipaddr"); %>"></div>
			</div>
			<div class="row">
				<label>子网掩码</label>
				<div class="ctrl"><input type="text" name="lan_netmask" value="<% nvram_get_x("", "lan_netmask"); %>"></div>
			</div>
			<div class="row">
				<label>网关</label>
				<div class="ctrl"><input type="text" name="lan_gateway" value="<% nvram_get_x("", "lan_gateway"); %>"></div>
			</div>
		</div>

		<div class="row">
			<label>DNS 设置</label>
			<div class="ctrl">
				<label class="enable-switch">
					<input type="checkbox" id="apDnsEnable" onchange="toggleApDns()">
					<span class="enable-slider"></span>
				</label>
				<input type="hidden" name="lan_dns_x" id="ap_lan_dns_x" value="<% nvram_get_x("", "lan_dns_x"); %>">
			</div>
		</div>
		<div id="apDnsFields" style="display:none;">
			<div class="row">
				<label>首选 DNS</label>
				<div class="ctrl"><input type="text" name="lan_dns1" value="<% nvram_get_x("", "lan_dns1"); %>"></div>
			</div>
			<div class="row">
				<label>备用 DNS</label>
				<div class="ctrl"><input type="text" name="lan_dns2" value="<% nvram_get_x("", "lan_dns2"); %>"></div>
			</div>
		</div>
		<p class="helper-text">AP 模式下设备通过桥接口从主路由自动获取地址（推荐）；如需固定，请选择「静态地址」并填写 IP、掩码与网关。</p>

		<div class="btn-row">
			<button type="submit" class="btn" onclick="return onApIpApply()">应用设备 IP 设置</button>
		</div>
	</form>
</div>

<!-- LAN 设置 -->
<div class="card" id="cardLan">
	<h3 id="cardLanTitle">LAN 设置</h3>
	<iframe name="hidden_frame_lan" id="hidden_frame_lan" src="" width="0" height="0" frameborder="0"></iframe>
	<form method="post" name="formLan" action="/start_apply.htm" target="hidden_frame_lan">
		<input type="hidden" name="current_page" value="network.asp">
		<input type="hidden" name="next_page" value="network.asp">
		<input type="hidden" name="next_host" value="">
		<input type="hidden" name="sid_list" value="LANHostConfig;">
		<input type="hidden" name="group_id" value="">
		<input type="hidden" name="action_mode" value=" Apply ">
		<input type="hidden" name="action_script" value="">
		<input type="hidden" name="wan_ipaddr" value="<% nvram_get_x("", "wan0_ipaddr"); %>">
		<input type="hidden" name="wan_netmask" value="<% nvram_get_x("", "wan0_netmask"); %>">

		<div id="lanIpRows">
			<div class="row">
				<label>IP 地址</label>
				<div class="ctrl"><input type="text" name="lan_ipaddr" value="<% nvram_get_x("", "lan_ipaddr"); %>"></div>
			</div>
			<div class="row">
				<label>子网掩码</label>
				<div class="ctrl"><input type="text" name="lan_netmask" value="<% nvram_get_x("", "lan_netmask"); %>"></div>
			</div>
		</div>

		<div class="row">
			<label>DHCP 服务器</label>
			<div class="ctrl">
				<label class="enable-switch">
					<input type="checkbox" id="dhcpEnable" onchange="toggleDhcp()">
					<span class="enable-slider"></span>
				</label>
				<input type="hidden" name="dhcp_enable_x" id="dhcp_enable_x" value="<% nvram_get_x("", "dhcp_enable_x"); %>">
				<input type="hidden" name="lan_dhcpd_x" id="lan_dhcpd_x" value="<% nvram_get_x("", "lan_dhcpd_x"); %>">
			</div>
		</div>
		<div id="dhcpExtra" class="dhcp-extra">
			<div class="row">
				<label>起始 IP</label>
				<div class="ctrl"><input type="text" name="dhcp_start" value="<% nvram_get_x("", "dhcp_start"); %>"></div>
			</div>
			<div class="row">
				<label>结束 IP</label>
				<div class="ctrl"><input type="text" name="dhcp_end" value="<% nvram_get_x("", "dhcp_end"); %>"></div>
			</div>
			<div class="row">
				<label>租约时间(秒)</label>
				<div class="ctrl"><input type="text" name="dhcp_lease" value="<% nvram_get_x("", "dhcp_lease"); %>" style="max-width:160px;"></div>
			</div>
		</div>

		<div id="lanDnsRows">
			<div class="row">
				<label>DNS</label>
				<div class="ctrl">
					<label class="enable-switch">
						<input type="checkbox" id="lanDnsEnable" onchange="toggleLanDns()" <% nvram_match_x("", "lan_dns_x", "1", "checked"); %>>
						<span class="enable-slider"></span>
					</label>
					<input type="hidden" name="lan_dns_x" id="lan_dns_x" value="<% nvram_get_x("", "lan_dns_x"); %>">
				</div>
			</div>
			<div id="lanDnsExtra" class="dhcp-extra">
				<div class="row">
					<label>首选 DNS</label>
					<div class="ctrl"><input type="text" name="lan_dns1" value="<% nvram_get_x("", "lan_dns1"); %>"></div>
				</div>
				<div class="row">
					<label>备用 DNS</label>
					<div class="ctrl"><input type="text" name="lan_dns2" value="<% nvram_get_x("", "lan_dns2"); %>"></div>
				</div>
			</div>
		</div>

		<div class="btn-row">
			<button type="submit" class="btn" onclick="return onLanApply()">应用 LAN 设置</button>
		</div>
	</form>
</div>

<!-- 客户端列表 -->
<div class="card">
	<h3>客户端列表 <button type="button" class="title-btn" onclick="refreshClients()">刷新</button></h3>
	<div id="clientEmpty" class="helper-text">暂无客户端</div>
	<div id="clientTableWrap" style="display:none; overflow-x:auto;">
		<table class="client-table">
			<thead>
				<tr><th>IP 地址</th><th>MAC 地址</th><th>设备名称</th><th>状态</th></tr>
			</thead>
			<tbody id="clientListBody"></tbody>
		</table>
	</div>
</div>

</div>
<script>
<% wanlink(); %>
var curWanMask = "<% nvram_get_x("", "wan0_netmask"); %>";

function fixStaticIp() {
	/* 自动将当前获取到的 IP 数据填入静态地址字段 */
	var ip = wanlink_ip4_wan();
	var gw = wanlink_gw4_wan();
	if (!ip || ip === '---') {
		alert("当前未获取到 IP 地址，请确保 WAN 已连接");
		return;
	}
	var form = document.formWan;
	form.wan_proto.value = "static";
	form.wan_ipaddr.value = ip;
	/* AP 模式固定填入 255.255.255.0；未获取到有效掩码（空/0.0.0.0）时同样回退 */
	var mask = curWanMask;
	if (isApModeUi() || !mask || mask === "0.0.0.0" || mask === "---")
		mask = "255.255.255.0";
	form.wan_netmask.value = mask;
	form.wan_gateway.value = (gw && gw !== '---') ? gw : "";
	toggleWanFields();
}

var lastWanProto = "<% nvram_get_x("", "wan_proto"); %>";

function toggleWanFields() {
	var p = document.formWan.wan_proto.value;
	document.getElementById("staticFields").style.display = (p === "static") ? "" : "none";
	document.getElementById("pppoeFields").style.display = (p === "pppoe") ? "" : "none";
	var form = document.formWan;
	var dnsSelectRow = document.getElementById("dnsSelectRow");
	if (p === "static") {
		/* 静态地址：隐藏 DNS 开关，开关默认关闭（手动），并显示 DNS 设置框 */
		dnsSelectRow.style.display = "none";
		form.wan_dnsenable_x.value = "0";
		fillWanDns();
	} else {
		/* 从静态切回动态/宽带拨号时，DNS 开关默认开启 */
		dnsSelectRow.style.display = "";
		if (lastWanProto === "static") form.wan_dnsenable_x.value = "1";
	}
	lastWanProto = p;
	updateDnsSwitch();
	toggleDns();
}
function updateDnsSwitch() {
	/* 同步开关状态到 wan_dnsenable_x 的值（未设置时默认开启=自动获取） */
	var d = document.getElementById("wan_dnsenable_x").value;
	document.getElementById("wanDnsEnable").checked = (d !== "0");
}
function toggleDns() {
	/* 开关：开 = 自动获取 DNS，关 = 手动设置 DNS（显示 DNS 设置框） */
	var enabled = document.getElementById("wanDnsEnable").checked;
	document.getElementById("wan_dnsenable_x").value = enabled ? "1" : "0";
	document.getElementById("dnsFields").style.display = enabled ? "none" : "";
	if (!enabled) fillWanDns();
}
function fillWanDns() {
	/* 手动模式下，若 DNS 编辑框为空则读取系统内置 DNS 填入 */
	var form = document.formWan;
	if (form.wan_dns1_x.value || form.wan_dns2_x.value) return;
	var sysDns = (typeof wanlink_dns === "function") ? wanlink_dns() : "";
	if (sysDns && sysDns !== "---") {
		var arr = sysDns.split(/[,;\s]+/);
		if (arr[0]) form.wan_dns1_x.value = arr[0];
		if (arr[1]) form.wan_dns2_x.value = arr[1];
	}
}
/* 工作模式：AP 模式下 DHCP 服务器由 lan_dhcpd_x 控制（默认关闭），
 * 路由模式由 dhcp_enable_x 控制。开关需绑定对应变量。 */
var swModeUi = "<% nvram_get_x("", "sw_mode"); %>";
function isApModeUi() { return swModeUi === "3"; }

function initDhcpSwitch() {
	var el = document.getElementById("dhcpEnable");
	if (!el) return;
	var v = isApModeUi()
		? document.getElementById("lan_dhcpd_x").value
		: document.getElementById("dhcp_enable_x").value;
	el.checked = (v === "1");
	toggleDhcp();
}

function toggleDhcp() {
	var checked = document.getElementById("dhcpEnable").checked;
	if (isApModeUi())
		document.getElementById("lan_dhcpd_x").value = checked ? "1" : "0";
	else
		document.getElementById("dhcp_enable_x").value = checked ? "1" : "0";
	document.getElementById("dhcpExtra").style.display = checked ? "" : "none";
}
function toggleLanDns() {
	var checked = document.getElementById("lanDnsEnable").checked;
	document.getElementById("lan_dns_x").value = checked ? "1" : "0";
	document.getElementById("lanDnsExtra").style.display = checked ? "" : "none";
	if (checked) fillLanDns();
}
function fillLanDns() {
	/* 读取系统内 DNS 填入编辑框（仅当为空时填充，避免覆盖已保存的值） */
	var d1 = document.formLan.elements["lan_dns1"];
	var d2 = document.formLan.elements["lan_dns2"];
	if (!d1 || !d2) return;
	if (d1.value || d2.value) return;
	var sysDns = (typeof wanlink_dns === "function") ? wanlink_dns() : "";
	if (sysDns && sysDns !== "---") {
		var arr = sysDns.split(/[,;\s]+/);
		if (arr[0]) d1.value = arr[0];
		if (arr[1]) d2.value = arr[1];
	}
}

/* ---------- AP 模式：设备 IP 设置 ---------- */
function applyModeVisibility() {
	var ap = isApModeUi();
	var wan = document.getElementById("cardWan");
	var apCard = document.getElementById("cardApIp");
	var lanIpRows = document.getElementById("lanIpRows");
	var lanDnsRows = document.getElementById("lanDnsRows");
	if (wan) wan.style.display = ap ? "none" : "";
	if (apCard) apCard.style.display = ap ? "" : "none";
	/* AP 模式下本机 IP/DNS 由「设备 IP 设置」管理：
	 * 隐藏并禁用 LAN 卡片中的重复字段，避免用页面加载时的旧值覆盖。 */
	if (lanIpRows) lanIpRows.style.display = ap ? "none" : "";
	if (lanDnsRows) lanDnsRows.style.display = ap ? "none" : "";
	var lanTitle = document.getElementById("cardLanTitle");
	if (lanTitle) lanTitle.textContent = ap ? "DHCP 服务器" : "LAN 设置";
	var lf = document.formLan;
	if (lf) {
		lf.lan_ipaddr.disabled = ap;
		lf.lan_netmask.disabled = ap;
		lf.lan_dns_x.disabled = ap;
		lf.lan_dns1.disabled = ap;
		lf.lan_dns2.disabled = ap;
		/* 这两个隐藏字段用于回填 WAN 运行时地址；AP 模式下 WAN 未运行，
		 * 不禁用会把空/陈旧值写回 WAN 配置，导致切回路由模式后配置丢失。 */
		lf.wan_ipaddr.disabled = ap;
		lf.wan_netmask.disabled = ap;
	}
}
function toggleApIpFields() {
	var p = document.formApIp.lan_proto_x.value;
	document.getElementById("apStaticFields").style.display = (p === "0") ? "" : "none";
}
function initApDns() {
	/* lan_dns_x: 1=从主路由自动获取 DNS，0=手动填写 */
	document.getElementById("apDnsEnable").checked = (document.getElementById("ap_lan_dns_x").value === "1");
	toggleApDns();
}
function toggleApDns() {
	var enabled = document.getElementById("apDnsEnable").checked;
	document.getElementById("ap_lan_dns_x").value = enabled ? "1" : "0";
	document.getElementById("apDnsFields").style.display = enabled ? "none" : "";
	if (!enabled) {
		var f = document.formApIp;
		if (!f.lan_dns1.value && !f.lan_dns2.value) {
			var sysDns = (typeof wanlink_dns === "function") ? wanlink_dns() : "";
			if (sysDns && sysDns !== "---") {
				var arr = sysDns.split(/[,;\s]+/);
				if (arr[0]) f.lan_dns1.value = arr[0];
				if (arr[1]) f.lan_dns2.value = arr[1];
			}
		}
	}
}
function fixStaticIpAp() {
	/* 将当前从主路由获取到的地址填入静态字段 */
	var ip = wanlink_ip4_wan();
	var gw = wanlink_gw4_wan();
	if (!ip || ip === '---') {
		alert("当前未获取到 IP 地址，请确保已连接主路由");
		return;
	}
	var f = document.formApIp;
	f.lan_proto_x.value = "0";
	f.lan_ipaddr.value = ip;
	f.lan_netmask.value = "255.255.255.0";
	f.lan_gateway.value = (gw && gw !== '---') ? gw : "";
	toggleApIpFields();
}
function onApIpApply() {
	if (parent && parent.showLoading) {
		parent.showLoading(5, "正在应用设备 IP 设置，请稍候...");
	}
	return true;
}
function onWanApply() {
	if (parent && parent.showLoading) {
		parent.showLoading(5, "正在应用 WAN 设置，请稍候...");
	}
	return true;
}
function onLanApply() {
	if (parent && parent.showLoading) {
		parent.showLoading(5, "正在应用 LAN 设置，请稍候...");
	}
	return true;
}
/* 客户端列表（数据来源：networkmap 生成的 /tmp/static_ip.inf） */
var clients = [<% get_static_client(); %>];

function escHtml(s) {
	return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}
function ipToLong(ip) {
	var p = String(ip).split(".");
	if (p.length !== 4) return 0;
	return ((+p[0]) << 24 >>> 0) + ((+p[1]) << 16) + ((+p[2]) << 8) + (+p[3]);
}
function renderClients() {
	var tbody = document.getElementById("clientListBody");
	var wrap = document.getElementById("clientTableWrap");
	var empty = document.getElementById("clientEmpty");
	var rows = [];
	for (var i = 0; i < clients.length; i++) {
		var c = clients[i];
		if (!c || !c[0]) continue;
		/* 字段顺序: ip, mac, device_name, type, http, staled */
		rows.push({ ip: c[0] || "", mac: c[1] || "", name: c[2] || "", online: (c[5] !== "1") });
	}
	if (rows.length === 0) {
		wrap.style.display = "none";
		empty.style.display = "";
		return;
	}
	empty.style.display = "none";
	wrap.style.display = "";
	rows.sort(function(a, b) {
		if (a.online !== b.online) return a.online ? -1 : 1;
		return ipToLong(a.ip) - ipToLong(b.ip);
	});
	var html = "";
	for (var j = 0; j < rows.length; j++) {
		var r = rows[j];
		html += "<tr>";
		html += "<td>" + escHtml(r.ip) + "</td>";
		html += "<td>" + escHtml(r.mac) + "</td>";
		html += '<td class="name">' + escHtml(r.name || "-") + "</td>";
		html += "<td>" + (r.online ? '<span class="client-badge on">在线</span>' : '<span class="client-badge off">离线</span>') + "</td>";
		html += "</tr>";
	}
	tbody.innerHTML = html;
}
function refreshClients() {
	location.reload();
}

applyModeVisibility();
toggleWanFields();
initDhcpSwitch();
toggleLanDns();
toggleApIpFields();
initApDns();
renderClients();
</script>
</body>
</html>
