<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="/bootstrap/css/toggle.css">
<link rel="stylesheet" type="text/css" href="/bootstrap/css/page.css">
<link rel="stylesheet" type="text/css" href="/bootstrap/css/network.css">
</head>
<body>
<div class="container">

<!-- WAN 设置（仅路由模式显示） -->
<div class="card" id="cardWan">
	<h3><#Net_WanTitle#> <button type="button" class="title-btn" onclick="fixStaticIp()"><#Net_FixStaticIp#></button></h3>
	<iframe name="hidden_frame_wan" id="hidden_frame_wan" src="" width="0" height="0" frameborder="0"></iframe>
	<form method="post" name="formWan" action="/start_apply.htm" target="hidden_frame_wan">
		<input type="hidden" name="current_page" value="network.asp">
		<input type="hidden" name="next_page" value="network.asp">
		<input type="hidden" name="next_host" value="">
		<input type="hidden" name="sid_list" value="Layer3Forwarding;LANHostConfig;IPConnection;PPPConnection;WLANConfig11b">
		<input type="hidden" name="group_id" value="">
		<input type="hidden" name="action_mode" value=" Apply ">
		<input type="hidden" name="action_script" value="">
		<input type="hidden" name="lan_ipaddr" value="<% nvram_get_x("", "lan_ipaddr"); %>">
		<input type="hidden" name="lan_netmask" value="<% nvram_get_x("", "lan_netmask"); %>">

		<div class="row">
			<label><#Net_ConnType#></label>
			<div class="ctrl">
				<select name="wan_proto" onchange="toggleWanFields()">
					<option value="dhcp" <% nvram_match_x("", "wan_proto", "dhcp", "selected"); %>><#Net_AutoGet#></option>
					<option value="static" <% nvram_match_x("", "wan_proto", "static", "selected"); %>><#Net_StaticAddr#></option>
					<option value="pppoe" <% nvram_match_x("", "wan_proto", "pppoe", "selected"); %>><#Net_PppoeDial#></option>
				</select>
			</div>
		</div>

		<div id="staticFields" style="display:none;">
			<div class="row">
				<label><#Net_IpAddr#></label>
				<div class="ctrl"><input type="text" name="wan_ipaddr" value="<% nvram_get_x("", "wan_ipaddr"); %>"></div>
			</div>
			<div class="row">
				<label><#Net_Netmask#></label>
				<div class="ctrl"><input type="text" name="wan_netmask" value="<% nvram_get_x("", "wan_netmask"); %>"></div>
			</div>
			<div class="row">
				<label><#Net_Gateway#></label>
				<div class="ctrl"><input type="text" name="wan_gateway" value="<% nvram_get_x("", "wan_gateway"); %>"></div>
			</div>
		</div>

		<div id="pppoeFields" style="display:none;">
			<div class="row">
				<label><#Net_Username#></label>
				<div class="ctrl"><input type="text" name="wan_pppoe_username" value="<% nvram_get_x("", "wan_pppoe_username"); %>"></div>
			</div>
			<div class="row">
				<label><#Net_Password#></label>
				<div class="ctrl"><input type="password" name="wan_pppoe_passwd" value="<% nvram_get_x("", "wan_pppoe_passwd"); %>"></div>
			</div>
		</div>

		<div class="row">
			<label>MTU</label>
			<div class="ctrl"><input type="text" name="wan_mtu" value="<% nvram_get_x("", "wan_mtu"); %>" style="max-width:120px;"></div>
		</div>

		<div id="dnsSelectRow" class="row">
			<label><#Net_DnsSettings#></label>
			<div class="ctrl">
				<label class="enable-switch">
					<input type="checkbox" id="wanDnsEnable" onchange="toggleDns()">
					<span class="enable-slider"></span>
				</label>
				<input type="hidden" name="wan_dnsenable_x" id="wan_dnsenable_x" value="<% nvram_get_x("", "wan_dnsenable_x"); %>">
			</div>
		</div>

		<div id="dnsFields" style="display:none;">
			<div class="row">
				<label>DNS 1</label>
				<div class="ctrl"><input type="text" name="wan_dns1_x" value="<% nvram_get_x("", "wan_dns1_x"); %>"></div>
			</div>
			<div class="row">
				<label>DNS 2</label>
				<div class="ctrl"><input type="text" name="wan_dns2_x" value="<% nvram_get_x("", "wan_dns2_x"); %>"></div>
			</div>
		</div>

		<div class="btn-row">
			<button type="submit" class="btn" onclick="return onWanApply()"><#Net_ApplyWan#></button>
		</div>
	</form>
</div>

<!-- 设备 IP 设置（仅 AP 模式显示） -->
<div class="card" id="cardApIp" style="display:none;">
	<h3><#Net_DevIpSettings#> <button type="button" class="title-btn" onclick="fixStaticIpAp()"><#Net_FixStaticIp#></button></h3>
	<iframe name="hidden_frame_apip" id="hidden_frame_apip" src="" width="0" height="0" frameborder="0"></iframe>
	<form method="post" name="formApIp" action="/start_apply.htm" target="hidden_frame_apip">
		<input type="hidden" name="current_page" value="network.asp">
		<input type="hidden" name="next_page" value="network.asp">
		<input type="hidden" name="next_host" value="">
		<input type="hidden" name="sid_list" value="LANHostConfig;">
		<input type="hidden" name="group_id" value="">
		<input type="hidden" name="action_mode" value=" Apply ">
		<input type="hidden" name="action_script" value="">

		<div class="row">
			<label><#Net_ObtainMethod#></label>
			<div class="ctrl">
				<select name="lan_proto_x" onchange="toggleApIpFields()">
					<option value="1" <% nvram_match_x("", "lan_proto_x", "1", "selected"); %>><#Net_AutoFromMainRouter#></option>
					<option value="0" <% nvram_match_x("", "lan_proto_x", "0", "selected"); %>><#Net_StaticAddr#></option>
				</select>
			</div>
		</div>

		<div id="apStaticFields" style="display:none;">
			<div class="row">
				<label><#Net_IpAddr#></label>
				<div class="ctrl"><input type="text" name="lan_ipaddr" value="<% nvram_get_x("", "lan_ipaddr"); %>"></div>
			</div>
			<div class="row">
				<label><#Net_Netmask#></label>
				<div class="ctrl"><input type="text" name="lan_netmask" value="<% nvram_get_x("", "lan_netmask"); %>"></div>
			</div>
			<div class="row">
				<label><#Net_Gateway#></label>
				<div class="ctrl"><input type="text" name="lan_gateway" value="<% nvram_get_x("", "lan_gateway"); %>"></div>
			</div>
		</div>

		<div class="row">
			<label><#Net_DnsSettings#></label>
			<div class="ctrl">
				<label class="enable-switch">
					<input type="checkbox" id="apDnsEnable" onchange="toggleApDns()">
					<span class="enable-slider"></span>
				</label>
				<input type="hidden" name="lan_dns_x" id="ap_lan_dns_x" value="<% nvram_get_x("", "lan_dns_x"); %>">
			</div>
		</div>
		<div id="apDnsFields" style="display:none;">
			<div class="row">
				<label><#Net_PrimaryDns#></label>
				<div class="ctrl"><input type="text" name="lan_dns1" value="<% nvram_get_x("", "lan_dns1"); %>"></div>
			</div>
			<div class="row">
				<label><#Net_SecondaryDns#></label>
				<div class="ctrl"><input type="text" name="lan_dns2" value="<% nvram_get_x("", "lan_dns2"); %>"></div>
			</div>
		</div>
		<p class="helper-text"><#Net_ApHelperText#></p>

		<div class="btn-row">
			<button type="submit" class="btn" onclick="return onApIpApply()"><#Net_ApplyDevIp#></button>
		</div>
	</form>
</div>

<!-- LAN 设置 -->
<div class="card" id="cardLan">
	<h3 id="cardLanTitle"><#Net_LanTitle#></h3>
	<iframe name="hidden_frame_lan" id="hidden_frame_lan" src="" width="0" height="0" frameborder="0"></iframe>
	<form method="post" name="formLan" action="/start_apply.htm" target="hidden_frame_lan">
		<input type="hidden" name="current_page" value="network.asp">
		<input type="hidden" name="next_page" value="network.asp">
		<input type="hidden" name="next_host" value="">
		<input type="hidden" name="sid_list" value="LANHostConfig;">
		<input type="hidden" name="group_id" value="">
		<input type="hidden" name="action_mode" value=" Apply ">
		<input type="hidden" name="action_script" value="">
		<input type="hidden" name="wan_ipaddr" value="<% nvram_get_x("", "wan0_ipaddr"); %>">
		<input type="hidden" name="wan_netmask" value="<% nvram_get_x("", "wan0_netmask"); %>">

		<div id="lanIpRows">
			<div class="row">
				<label><#Net_IpAddr#></label>
				<div class="ctrl"><input type="text" name="lan_ipaddr" value="<% nvram_get_x("", "lan_ipaddr"); %>"></div>
			</div>
			<div class="row">
				<label><#Net_Netmask#></label>
				<div class="ctrl"><input type="text" name="lan_netmask" value="<% nvram_get_x("", "lan_netmask"); %>"></div>
			</div>
		</div>

		<div class="row">
			<label><#Net_DhcpServer#></label>
			<div class="ctrl">
				<label class="enable-switch">
					<input type="checkbox" id="dhcpEnable" onchange="toggleDhcp()">
					<span class="enable-slider"></span>
				</label>
				<input type="hidden" name="dhcp_enable_x" id="dhcp_enable_x" value="<% nvram_get_x("", "dhcp_enable_x"); %>">
				<input type="hidden" name="lan_dhcpd_x" id="lan_dhcpd_x" value="<% nvram_get_x("", "lan_dhcpd_x"); %>">
			</div>
		</div>
		<div id="dhcpExtra" class="dhcp-extra">
			<div class="row">
				<label><#Net_StartIp#></label>
				<div class="ctrl"><input type="text" name="dhcp_start" value="<% nvram_get_x("", "dhcp_start"); %>"></div>
			</div>
			<div class="row">
				<label><#Net_EndIp#></label>
				<div class="ctrl"><input type="text" name="dhcp_end" value="<% nvram_get_x("", "dhcp_end"); %>"></div>
			</div>
			<div class="row">
				<label><#Net_LeaseTimeSec#></label>
				<div class="ctrl"><input type="text" name="dhcp_lease" value="<% nvram_get_x("", "dhcp_lease"); %>" style="max-width:160px;"></div>
			</div>
		</div>

		<div id="lanDnsRows">
			<div class="row">
				<label>DNS</label>
				<div class="ctrl">
					<label class="enable-switch">
						<input type="checkbox" id="lanDnsEnable" onchange="toggleLanDns()">
						<span class="enable-slider"></span>
					</label>
				</div>
			</div>
			<div id="lanDnsExtra" class="dhcp-extra">
				<div class="row">
					<label><#Net_PrimaryDns#></label>
					<div class="ctrl"><input type="text" name="dhcp_dns1_x" value="<% nvram_get_x("", "dhcp_dns1_x"); %>"></div>
				</div>
				<div class="row">
					<label><#Net_SecondaryDns#></label>
					<div class="ctrl"><input type="text" name="dhcp_dns2_x" value="<% nvram_get_x("", "dhcp_dns2_x"); %>"></div>
				</div>
			</div>
		</div>

		<div class="btn-row">
			<button type="submit" class="btn" onclick="return onLanApply()"><#Net_ApplyLan#></button>
		</div>
	</form>
</div>

<!-- 客户端列表 -->
<div class="card">
	<h3><#Net_ClientList#> <button type="button" class="title-btn" onclick="refreshClients()"><#Net_Refresh#></button></h3>
	<div id="clientEmpty" class="helper-text"><#Net_NoClients#></div>
	<div id="clientTableWrap" style="display:none; overflow-x:auto;">
		<table class="client-table">
			<thead>
				<tr><th><#Net_IpAddr#></th><th><#Net_MacAddr#></th><th><#Net_DeviceName#></th><th><#Net_Status#></th></tr>
			</thead>
			<tbody id="clientListBody"></tbody>
		</table>
	</div>
</div>

</div>
<script type="text/javascript" src="/bootstrap/js/network.js"></script>
</body>
</html>
