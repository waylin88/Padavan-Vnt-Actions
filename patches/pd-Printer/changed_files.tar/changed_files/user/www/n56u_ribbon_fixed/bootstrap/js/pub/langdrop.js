/* 语言切换下拉组件（登录页与主页共用）。
   从服务端渲染的 <select>（由 <% shown_language_option(); %> 输出）读取语言列表，
   构建自定义面板；选择后写入 NVRAM preferred_lang 并整页刷新。
   本文件位于 pub/ 免鉴权目录，登录前页面也能加载。 */
(function () {
	function changeLang(lang) {
		var xhr = new XMLHttpRequest();
		xhr.open("GET", "/setlang.cgi?lang=" + encodeURIComponent(lang), true);
		xhr.onload = xhr.onerror = function () { window.location.reload(); };
		xhr.send();
	}

	function build(root) {
		var sel = root.querySelector("select");
		if (!sel || sel.options.length === 0 || root.querySelector(".langdrop-trigger"))
			return;

		var current = sel.options[sel.selectedIndex] || sel.options[0];

		var label = document.createElement("span");
		label.className = "langdrop-label";
		label.textContent = current.text;

		var caret = document.createElement("span");
		caret.className = "langdrop-caret";

		var trigger = document.createElement("div");
		trigger.className = "langdrop-trigger";
		trigger.setAttribute("role", "button");
		trigger.setAttribute("aria-label", sel.getAttribute("aria-label") || "Language");
		trigger.appendChild(label);
		trigger.appendChild(caret);

		var list = document.createElement("ul");
		list.className = "langdrop-list";

		var panel = document.createElement("div");
		panel.className = "langdrop-panel";
		panel.appendChild(list);

		for (var i = 0; i < sel.options.length; i++) {
			(function (opt) {
				var item = document.createElement("li");
				item.className = "langdrop-item" + (opt.selected ? " active" : "");
				item.textContent = opt.text;
				item.onclick = function (e) {
					e.stopPropagation();
					panel.classList.remove("open");
					if (opt.value === sel.value) {
						label.textContent = opt.text;
						return;
					}
					changeLang(opt.value);
				};
				list.appendChild(item);
			})(sel.options[i]);
		}

		trigger.onclick = function (e) {
			e.stopPropagation();
			panel.classList.toggle("open");
		};
		document.addEventListener("click", function () {
			panel.classList.remove("open");
		});

		root.appendChild(trigger);
		root.appendChild(panel);
	}

	function init() {
		var roots = document.querySelectorAll("[data-langdrop]");
		for (var i = 0; i < roots.length; i++)
			build(roots[i]);
	}

	if (document.readyState === "loading")
		document.addEventListener("DOMContentLoaded", init);
	else
		init();
})();
