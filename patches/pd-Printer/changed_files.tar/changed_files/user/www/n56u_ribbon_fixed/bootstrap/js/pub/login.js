/* 登录页脚本：密码框显示/隐藏切换。
   本文件位于 pub/ 免鉴权目录（登录页在未登录状态下加载）。 */
function togglePassword() {
	var password = document.getElementById("password");
	var button = document.getElementById("passwordToggle");
	if (password.type == "password") {
		password.type = "text";
		button.innerHTML = "<#LoginPage_Hide#>";
	} else {
		password.type = "password";
		button.innerHTML = "<#LoginPage_Show#>";
	}
}
