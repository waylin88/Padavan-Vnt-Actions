<% wanlink(); %>
/* 网络页脚本：WAN / 设备 IP(AP) / LAN(DHCP) 设置与客户端列表。
   由 do_ej 处理（**.js 走 EJ 模板引擎）。 */
var curWanMask = "<% nvram_get_x("", "wan0_netmask"); %>";

function fixStaticIp() {
	/* 自动将当前获取到的 IP 数据填入静态地址字段 */
	var ip = wanlink_ip4_wan();
	var gw = wanlink_gw4_wan();
	if (!ip || ip === '---') {
		alert("<#Net_ErrWanNoIp#>");
		return;
	}
	var form = document.formWan;
	form.wan_proto.value = "static";
	form.wan_ipaddr.value = ip;
	/* AP 模式固定填入 255.255.255.0；未获取到有效掩码（空/0.0.0.0）时同样回退 */
	var mask = curWanMask;
	if (isApModeUi() || !mask || mask === "0.0.0.0" || mask === "---")
		mask = "255.255.255.0";
	form.wan_netmask.value = mask;
	form.wan_gateway.value = (gw && gw !== '---') ? gw : "";
	toggleWanFields();
}

var lastWanProto = "<% nvram_get_x("", "wan_proto"); %>";

function toggleWanFields() {
	var p = document.formWan.wan_proto.value;
	document.getElementById("staticFields").style.display = (p === "static") ? "" : "none";
	document.getElementById("pppoeFields").style.display = (p === "pppoe") ? "" : "none";
	var form = document.formWan;
	var dnsSelectRow = document.getElementById("dnsSelectRow");
	if (p === "static") {
		/* 静态地址：隐藏 DNS 开关，开关默认关闭（手动），并显示 DNS 设置框 */
		dnsSelectRow.style.display = "none";
		form.wan_dnsenable_x.value = "0";
		fillWanDns();
	} else {
		/* 从静态切回动态/宽带拨号时，DNS 开关默认开启 */
		dnsSelectRow.style.display = "";
		if (lastWanProto === "static") form.wan_dnsenable_x.value = "1";
	}
	lastWanProto = p;
	updateDnsSwitch();
	toggleDns();
}
function updateDnsSwitch() {
	/* 同步开关状态到 wan_dnsenable_x 的值（未设置时默认开启=自动获取） */
	var d = document.getElementById("wan_dnsenable_x").value;
	document.getElementById("wanDnsEnable").checked = (d !== "0");
}
function toggleDns() {
	/* 开关：开 = 自动获取 DNS，关 = 手动设置 DNS（显示 DNS 设置框） */
	var enabled = document.getElementById("wanDnsEnable").checked;
	document.getElementById("wan_dnsenable_x").value = enabled ? "1" : "0";
	document.getElementById("dnsFields").style.display = enabled ? "none" : "";
	if (!enabled) fillWanDns();
}
/* wanlink_dns() 用 <br/> 连接多条 DNS（状态页据此换行显示），
 * 解析时需把 <br/> 一并当作分隔符，否则多条 DNS 会全部塞进第一个输入框。 */
function splitDnsList(s) {
	if (!s || s === "---") return [];
	return String(s).replace(/<br\s*\/?>/gi, " ").split(/[,;\s]+/);
}
function fillWanDns() {
	/* 手动模式下，若 DNS 编辑框为空则读取系统内置 DNS 填入 */
	var form = document.formWan;
	if (form.wan_dns1_x.value || form.wan_dns2_x.value) return;
	var arr = splitDnsList((typeof wanlink_dns === "function") ? wanlink_dns() : "");
	if (arr[0]) form.wan_dns1_x.value = arr[0];
	if (arr[1]) form.wan_dns2_x.value = arr[1];
}
/* 工作模式：AP 模式下 DHCP 服务器由 lan_dhcpd_x 控制（默认关闭），
 * 路由模式由 dhcp_enable_x 控制。开关需绑定对应变量。 */
var swModeUi = "<% nvram_get_x("", "sw_mode"); %>";
function isApModeUi() { return swModeUi === "3"; }

function initDhcpSwitch() {
	var el = document.getElementById("dhcpEnable");
	if (!el) return;
	var v = isApModeUi()
		? document.getElementById("lan_dhcpd_x").value
		: document.getElementById("dhcp_enable_x").value;
	el.checked = (v === "1");
	toggleDhcp();
}

function toggleDhcp() {
	var checked = document.getElementById("dhcpEnable").checked;
	if (isApModeUi())
		document.getElementById("lan_dhcpd_x").value = checked ? "1" : "0";
	else
		document.getElementById("dhcp_enable_x").value = checked ? "1" : "0";
	document.getElementById("dhcpExtra").style.display = checked ? "" : "none";
}
function initLanDns() {
	/* DHCP 下发的 DNS(dhcp_dns1_x/dhcp_dns2_x)：以是否已填写值判定开关状态 */
	var lf = document.formLan;
	var d1 = lf && lf.elements["dhcp_dns1_x"];
	var d2 = lf && lf.elements["dhcp_dns2_x"];
	var on = !!(d1 && d2 && (d1.value || d2.value));
	document.getElementById("lanDnsEnable").checked = on;
	toggleLanDns();
}
function toggleLanDns() {
	var checked = document.getElementById("lanDnsEnable").checked;
	document.getElementById("lanDnsExtra").style.display = checked ? "" : "none";
	var lf = document.formLan;
	var d1 = lf && lf.elements["dhcp_dns1_x"];
	var d2 = lf && lf.elements["dhcp_dns2_x"];
	if (!d1 || !d2) return;
	if (checked) {
		/* 打开：首选 DNS 默认填入 LAN 网关（仅在为空时填，避免覆盖已保存的值） */
		if (!d1.value) {
			var gw = lf.elements["lan_ipaddr"];
			if (gw && gw.value) d1.value = gw.value;
		}
	} else {
		/* 关闭：清空，避免 DHCP 仍向客户端下发旧的 dhcp_dns1_x/dhcp_dns2_x */
		d1.value = "";
		d2.value = "";
	}
}

/* ---------- AP 模式：设备 IP 设置 ---------- */
function applyModeVisibility() {
	var ap = isApModeUi();
	var wan = document.getElementById("cardWan");
	var apCard = document.getElementById("cardApIp");
	var lanIpRows = document.getElementById("lanIpRows");
	var lanDnsRows = document.getElementById("lanDnsRows");
	if (wan) wan.style.display = ap ? "none" : "";
	if (apCard) apCard.style.display = ap ? "" : "none";
	/* AP 模式下本机 IP/DNS 由「设备 IP 设置」管理：
	 * 隐藏并禁用 LAN 卡片中的重复字段，避免用页面加载时的旧值覆盖。 */
	if (lanIpRows) lanIpRows.style.display = ap ? "none" : "";
	if (lanDnsRows) lanDnsRows.style.display = ap ? "none" : "";
	var lanTitle = document.getElementById("cardLanTitle");
	if (lanTitle) lanTitle.textContent = ap ? "<#Net_DhcpServer#>" : "<#Net_LanTitle#>";
	var lf = document.formLan;
	if (lf) {
		lf.lan_ipaddr.disabled = ap;
		lf.lan_netmask.disabled = ap;
		var dd1 = lf.elements["dhcp_dns1_x"];
		var dd2 = lf.elements["dhcp_dns2_x"];
		if (dd1) dd1.disabled = ap;
		if (dd2) dd2.disabled = ap;
		/* 这两个隐藏字段用于回填 WAN 运行时地址；AP 模式下 WAN 未运行，
		 * 不禁用会把空/陈旧值写回 WAN 配置，导致切回路由模式后配置丢失。 */
		lf.wan_ipaddr.disabled = ap;
		lf.wan_netmask.disabled = ap;
	}
}
function toggleApIpFields() {
	var p = document.formApIp.lan_proto_x.value;
	document.getElementById("apStaticFields").style.display = (p === "0") ? "" : "none";
}
function initApDns() {
	/* lan_dns_x: 1=从主路由自动获取 DNS，0=手动填写 */
	document.getElementById("apDnsEnable").checked = (document.getElementById("ap_lan_dns_x").value === "1");
	toggleApDns();
}
function toggleApDns() {
	var enabled = document.getElementById("apDnsEnable").checked;
	document.getElementById("ap_lan_dns_x").value = enabled ? "1" : "0";
	document.getElementById("apDnsFields").style.display = enabled ? "none" : "";
}
function fixStaticIpAp() {
	/* 将当前从主路由获取到的地址填入静态字段 */
	var ip = wanlink_ip4_wan();
	var gw = wanlink_gw4_wan();
	if (!ip || ip === '---') {
		alert("<#Net_ErrApNoIp#>");
		return;
	}
	var f = document.formApIp;
	f.lan_proto_x.value = "0";
	f.lan_ipaddr.value = ip;
	f.lan_netmask.value = "255.255.255.0";
	f.lan_gateway.value = (gw && gw !== '---') ? gw : "";
	toggleApIpFields();
}
function onApIpApply() {
	if (parent && parent.showLoading) {
		parent.showLoading(5, "<#Net_LoadingApplyDevIp#>");
	}
	return true;
}
function onWanApply() {
	if (parent && parent.showLoading) {
		parent.showLoading(5, "<#Net_LoadingApplyWan#>");
	}
	return true;
}
function onLanApply() {
	if (parent && parent.showLoading) {
		parent.showLoading(5, "<#Net_LoadingApplyLan#>");
	}
	return true;
}
/* 客户端列表（数据来源：networkmap 生成的 /tmp/static_ip.inf） */
var clients = [<% get_static_client(); %>];

function escHtml(s) {
	return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}
function ipToLong(ip) {
	var p = String(ip).split(".");
	if (p.length !== 4) return 0;
	return ((+p[0]) << 24 >>> 0) + ((+p[1]) << 16) + ((+p[2]) << 8) + (+p[3]);
}
function renderClients() {
	var tbody = document.getElementById("clientListBody");
	var wrap = document.getElementById("clientTableWrap");
	var empty = document.getElementById("clientEmpty");
	var rows = [];
	for (var i = 0; i < clients.length; i++) {
		var c = clients[i];
		if (!c || !c[0]) continue;
		/* 字段顺序: ip, mac, device_name, type, http, staled */
		rows.push({ ip: c[0] || "", mac: c[1] || "", name: c[2] || "", online: (c[5] !== "1") });
	}
	if (rows.length === 0) {
		wrap.style.display = "none";
		empty.style.display = "";
		return;
	}
	empty.style.display = "none";
	wrap.style.display = "";
	rows.sort(function(a, b) {
		if (a.online !== b.online) return a.online ? -1 : 1;
		return ipToLong(a.ip) - ipToLong(b.ip);
	});
	var html = "";
	for (var j = 0; j < rows.length; j++) {
		var r = rows[j];
		html += "<tr>";
		html += "<td>" + escHtml(r.ip) + "</td>";
		html += "<td>" + escHtml(r.mac) + "</td>";
		html += '<td class="name">' + escHtml(r.name || "-") + "</td>";
		html += "<td>" + (r.online ? '<span class="client-badge on"><#Net_Online#></span>' : '<span class="client-badge off"><#Net_Offline#></span>') + "</td>";
		html += "</tr>";
	}
	tbody.innerHTML = html;
}
function refreshClients() {
	location.reload();
}

applyModeVisibility();
toggleWanFields();
initDhcpSwitch();
initLanDns();
toggleApIpFields();
initApDns();
renderClients();
