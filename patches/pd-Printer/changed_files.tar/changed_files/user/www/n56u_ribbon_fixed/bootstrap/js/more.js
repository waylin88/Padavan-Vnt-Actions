/* 更多页脚本。由 do_ej 处理（**.js 走 EJ 模板引擎）。 */
/* WORK_MODE_BEGIN */
/* ── 工作模式（编译开关 CONFIG_FIRMWARE_INCLUDE_WORK_MODE）── */
function syncModeSel() {
	var opts = document.querySelectorAll(".mode-opt");
	for (var i = 0; i < opts.length; i++) {
		var r = opts[i].querySelector("input[type=radio]");
		opts[i].className = "mode-opt" + (r && r.checked ? " selected" : "");
	}
}
function onModeApply() {
	if (!confirm("<#More_ConfirmSwitchMode#>"))
		return false;
	if (parent && parent.showLoading)
		parent.showLoading(40, "<#More_SwitchingMode#>");
	return true;
}
syncModeSel();
/* WORK_MODE_END */

/* ── 自动重启（按星期 + 时间定时重启）──
 * 开关状态用隐藏域 sched_reboot_enable 提交（未勾选时 checkbox 不传值）；
 * 星期用 7 个复选框，拼成 7 位位图（周日..周六）写入隐藏域 sched_reboot_days；
 * 时间由后端统一格式化为 HH:MM，这里只做一次前端校验与补零。 */
var DAYS_DEFAULT = "1111111";

function syncRebootDays() {
	var cbs = document.querySelectorAll("#schedRebootDays .day-cb");
	var bits = "";
	for (var i = 0; i < cbs.length; i++)
		bits += cbs[i].checked ? "1" : "0";
	var hid = document.getElementById("sched_reboot_days");
	if (hid)
		hid.value = bits;
	return bits;
}

function loadRebootDays() {
	var hid = document.getElementById("sched_reboot_days");
	var bits = hid && hid.value.length === 7 ? hid.value : DAYS_DEFAULT;
	var cbs = document.querySelectorAll("#schedRebootDays .day-cb");
	for (var i = 0; i < cbs.length; i++)
		cbs[i].checked = bits.charAt(i) === "1";
	syncRebootDays();
}

function syncAutoReboot() {
	var cb = document.getElementById("schedRebootEnableCb");
	var hid = document.getElementById("sched_reboot_enable");
	var days = document.getElementById("schedRebootDaysRow");
	var time = document.getElementById("schedRebootTimeRow");
	var on = !!(cb && cb.checked);

	if (hid)
		hid.value = on ? "1" : "0";
	if (days)
		days.style.display = on ? "" : "none";
	if (time)
		time.style.display = on ? "" : "none";
}

function onAutoRebootApply() {
	var cb = document.getElementById("schedRebootEnableCb");
	if (cb && cb.checked && syncRebootDays().indexOf("1") < 0) {
		alert("<#More_AutoRebootDaysInvalid#>");
		return false;
	}

	var t = document.getElementById("sched_reboot_time");
	if (t) {
		var v = (t.value || "").replace(/^\s+|\s+$/g, "");
		var m = /^(\d{1,2}):(\d{1,2})$/.exec(v);
		if (!m || +m[1] > 23 || +m[2] > 59) {
			alert("<#More_AutoRebootTimeInvalid#>");
			return false;
		}
		t.value = ("0" + m[1]).slice(-2) + ":" + ("0" + m[2]).slice(-2);
	}
	return true;
}
loadRebootDays();
syncAutoReboot();

/* ── 恢复出厂设置 ──
 * NVRAM 与 /etc/storage 由后端同步复位，随后设备重启；
 * 恢复后管理地址回到默认的 192.168.2.1。 */
function doFactoryReset() {
	if (!confirm("<#More_ConfirmFactoryResetTitle#>"))
		return;

	/* 提交复位请求（后端会同步复位 NVRAM 与 /etc/storage 并重启） */
	var iframe = document.createElement("iframe");
	iframe.name = "reset_frame";
	iframe.style.display = "none";
	document.body.appendChild(iframe);
	var form = document.createElement("form");
	form.method = "post";
	form.action = "/apply.cgi";
	form.target = iframe.name;
	form.innerHTML = '<input type="hidden" name="action_mode" value=" RestoreAll ">'
		+ '<input type="hidden" name="current_page" value="more.asp">'
		+ '<input type="hidden" name="next_page" value="more.asp">';
	document.body.appendChild(form);
	form.submit();

	/* 全屏加载提示，并在设备重启后跳转到默认管理地址 */
	try {
		if (parent && typeof parent.showLoading === "function")
			parent.showLoading(0, "<#More_Resetting#>");
	} catch(e) {}
	setTimeout(function() {
		try { parent.location.href = "http://192.168.2.1/"; } catch(e) { location.href = "http://192.168.2.1/"; }
	}, 45000);
}
