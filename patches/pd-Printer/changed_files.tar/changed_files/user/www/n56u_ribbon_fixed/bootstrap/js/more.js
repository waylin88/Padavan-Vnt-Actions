/* 更多页脚本：工作模式切换与恢复出厂设置。
   由 do_ej 处理（**.js 走 EJ 模板引擎）。 */
/* ── 工作模式 ── */
function syncModeSel() {
	var opts = document.querySelectorAll(".mode-opt");
	for (var i = 0; i < opts.length; i++) {
		var r = opts[i].querySelector("input[type=radio]");
		opts[i].className = "mode-opt" + (r && r.checked ? " selected" : "");
	}
}
function onModeApply() {
	if (!confirm("<#More_ConfirmSwitchMode#>"))
		return false;
	if (parent && parent.showLoading)
		parent.showLoading(40, "<#More_SwitchingMode#>");
	return true;
}
syncModeSel();

/* ── 恢复出厂设置 ──
 * NVRAM 与 /etc/storage 由后端同步复位，随后设备重启；
 * 恢复后管理地址回到默认的 192.168.2.1。 */
function doFactoryReset() {
	if (!confirm("<#More_ConfirmFactoryResetTitle#>\n\n<#More_ConfirmFactoryResetBody#>"))
		return;

	/* 提交复位请求（后端会同步复位 NVRAM 与 /etc/storage 并重启） */
	var iframe = document.createElement("iframe");
	iframe.name = "reset_frame";
	iframe.style.display = "none";
	document.body.appendChild(iframe);
	var form = document.createElement("form");
	form.method = "post";
	form.action = "/apply.cgi";
	form.target = iframe.name;
	form.innerHTML = '<input type="hidden" name="action_mode" value=" RestoreAll ">'
		+ '<input type="hidden" name="current_page" value="more.asp">'
		+ '<input type="hidden" name="next_page" value="more.asp">';
	document.body.appendChild(form);
	form.submit();

	/* 全屏加载提示，并在设备重启后跳转到默认管理地址 */
	try {
		if (parent && typeof parent.showLoading === "function")
			parent.showLoading(0, "<#More_Resetting#>");
	} catch(e) {}
	setTimeout(function() {
		try { parent.location.href = "http://192.168.2.1/"; } catch(e) { location.href = "http://192.168.2.1/"; }
	}, 45000);
}
