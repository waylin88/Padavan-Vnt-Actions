<% wanlink(); %>
<% lanlink(); %>
<% get_usb_ports_info(); %>

/* 状态页脚本：WAN/LAN 状态与打印机状态渲染。
   由 do_ej 处理（**.js 走 EJ 模板引擎），页面内 <#...#> 与 <%...%> 均在此展开。 */

/* Bidirectional mode is per physical USB port (nvram lp_bidir<uid>).
 * Keep each port's state client-side so the 15s re-render does not reset switches. */
var g_bidirState = {};

/* ── 网口状态（物理链路）────────────────────────────────────────────
   WAN/LAN 卡片标题右侧的 RJ45 图标：绿色=已连接，灰色=未连接。
   ether_port_count() / ether_link_up(idx) 由 httpd 的 lanlink() 生成，
   idx 0 为 WAN，1..n 依次为 LAN1..LANn。 */
function portTagHtml(name, up) {
	var state = up ? "<#Stat_Connected#>" : "<#Stat_Disconnected#>";
	return '<span class="port-tag' + (up ? ' up' : '') + '" title="' + name + ' ' + state + '">'
		+ '<svg class="port-ico" viewBox="0 0 26 17" aria-hidden="true">'
		+ '<rect class="port-body" x="1" y="1" width="24" height="14" rx="2"/>'
		+ '<rect class="port-slot" x="6.5" y="4" width="13" height="6.5" rx="1"/>'
		+ '<path class="port-pin" d="M9.5 5.5v2.2M12 5.5v2.2M14.5 5.5v2.2M17 5.5v2.2"/>'
		+ '<circle class="port-led" cx="21.4" cy="12.6" r="1.1"/>'
		+ '</svg><span class="port-name">' + name + '</span></span>';
}

function showPortTags() {
	var count = (typeof ether_port_count === "function") ? parseInt(ether_port_count(), 10) : 1;
	if (isNaN(count) || count < 1) count = 1;
	var up = function (idx) {
		return (typeof ether_link_up === "function") && ether_link_up(idx) ? 1 : 0;
	};
	var wanEl = document.getElementById("wanPorts");
	var lanEl = document.getElementById("lanPorts");
	if (wanEl) wanEl.innerHTML = portTagHtml("WAN", up(0));
	if (lanEl) {
		var lh = '';
		for (var i = 1; i < count; i++)
			lh += portTagHtml("LAN" + i, up(i));
		lanEl.innerHTML = lh;
	}
}

function formatUptime(sec) {
	var s = parseInt(sec);
	if (isNaN(s) || s <= 0) return "0 <#Stat_Seconds#>";
	var d = Math.floor(s / 86400);
	var h = Math.floor((s % 86400) / 3600);
	var m = Math.floor((s % 3600) / 60);
	var ss = s % 60;
	var parts = [];
	if (d > 0) parts.push(d + " <#Stat_Days#>");
	if (h > 0 || d > 0) parts.push(h + " <#Stat_Hours#>");
	if (m > 0 || h > 0 || d > 0) parts.push(m + " <#Stat_Minutes#>");
	parts.push(ss + " <#Stat_Seconds#>");
	return parts.join(" ");
}

function showStatus() {
	var status = wanlink_status();
	var ip = wanlink_ip4_wan();
	var gw = wanlink_gw4_wan();
	var dns = wanlink_dns();
	var uptime = wanlink_uptime();
	var type = wanlink_type();
	var typeLow = (type || "").toLowerCase();
	var typeZh = "--";
	if (typeLow.indexOf("pppoe") >= 0 || typeLow.indexOf("ppp") >= 0) typeZh = "<#Stat_BroadbandDialup#>";
	else if (typeLow.indexOf("dhcp") >= 0 || typeLow.indexOf("dynamic") >= 0 || typeLow.indexOf("automatic") >= 0 || typeLow.indexOf("auto") >= 0) typeZh = "<#Stat_AutoObtain#>";
	else if (typeLow.indexOf("static") >= 0 || typeLow.indexOf("fixed") >= 0) typeZh = "<#Stat_StaticAddress#>";
	else if (type === "<#Stat_AutoObtain#>" || type === "<#Stat_StaticAddress#>" || type === "<#Stat_BroadbandDialup#>") typeZh = type;
	else if (type) typeZh = type;

	/* 三态：已连接(0) / 连接中(等待DHCP=5, 等待PPP=6) / 未连接(其他) */
	var up = (status === 0);
	var pending = (status === 5 || status === 6);
	var tag;
	if (up) tag = '<span class="tag ok"><#Stat_Connected#></span>';
	else if (pending) tag = '<span class="tag pending"><#Stat_Connecting#></span>';
	else tag = '<span class="tag bad"><#Stat_Disconnected#></span>';

	/* 未连接或连接中时清除 IP/网关/DNS/时长等旧数据 */
	var ipVal = up && ip && ip !== '---' ? ip : '-';
	var gwVal = up && gw && gw !== '---' ? gw : '-';
	var dnsVal = up && dns && dns !== '---' ? dns : '-';
	var upVal = up ? formatUptime(uptime) : '-';

	var h = '';
	h += '<div class="status-item"><div class="lbl"><#Stat_ConnectionStatus#></div><div class="val">' + tag + '</div></div>';
	h += '<div class="status-item"><div class="lbl"><#Stat_ConnectionType#></div><div class="val">' + typeZh + '</div></div>';
	h += '<div class="status-item"><div class="lbl"><#Stat_IpAddress#></div><div class="val">' + ipVal + '</div></div>';
	h += '<div class="status-item"><div class="lbl"><#Stat_Gateway#></div><div class="val">' + gwVal + '</div></div>';
	h += '<div class="status-item"><div class="lbl">DNS</div><div class="val">' + dnsVal + '</div></div>';
	h += '<div class="status-item"><div class="lbl"><#Stat_Uptime#></div><div class="val">' + upVal + '</div></div>';
	document.getElementById("wanStatus").innerHTML = h;

	/* LAN status — AP 模式下 DHCP 服务器由 lan_dhcpd_x 控制（默认关闭），
	 * 路由模式由 dhcp_enable_x 控制（默认启用，仅显式为 "0" 时禁用） */
	var lanIp = "<% nvram_get_x("", "lan_ipaddr"); %>";
	var lanMask = "<% nvram_get_x("", "lan_netmask"); %>";
	var lanMac = "<% nvram_get_x("", "lan_hwaddr"); %>";
	var dhcpText;
	if ("<% nvram_get_x("", "sw_mode"); %>" === "3")
		dhcpText = ("<% nvram_get_x("", "lan_dhcpd_x"); %>" === "1") ? '<#Stat_Enabled#>' : '<#Stat_Disabled#>';
	else
		dhcpText = ("<% nvram_get_x("", "dhcp_enable_x"); %>" !== "0") ? '<#Stat_Enabled#>' : '<#Stat_Disabled#>';
	var lh = '';
	lh += '<div class="status-item"><div class="lbl">LAN IP</div><div class="val">' + (lanIp || '-') + '</div></div>';
	lh += '<div class="status-item"><div class="lbl"><#Stat_SubnetMask#></div><div class="val">' + (lanMask || '-') + '</div></div>';
	lh += '<div class="status-item"><div class="lbl"><#Stat_MacAddress#></div><div class="val">' + (lanMac || '-') + '</div></div>';
	lh += '<div class="status-item"><div class="lbl">DHCP</div><div class="val">' + dhcpText + '</div></div>';
	document.getElementById("lanStatus").innerHTML = lh;

	showPortTags();
}

showStatus();
setInterval(showStatus, 15000);

/* ── Printer status (replica of printer page) ── */
/* Toggle bidirectional printing for one physical port (applied immediately) */
function toggleBidir(uid, enabled) {
	g_bidirState[uid] = enabled ? 1 : 0;
	/* sync desktop + mobile switch of this port only (other ports untouched) */
	var boxes = document.querySelectorAll('.bidir-switch input');
	for (var k = 0; k < boxes.length; k++) {
		if (boxes[k].getAttribute("data-uid") == String(uid))
			boxes[k].checked = enabled;
	}
	var iframe = document.createElement("iframe");
	iframe.name = "bidir_frame";
	iframe.style.display = "none";
	document.body.appendChild(iframe);
	var form = document.createElement("form");
	form.method = "post";
	form.action = "/start_apply.htm";
	form.target = iframe.name;
	form.innerHTML = '<input type="hidden" name="current_page" value="status.asp">'
		+ '<input type="hidden" name="next_page" value="status.asp">'
		+ '<input type="hidden" name="next_host" value="">'
		+ '<input type="hidden" name="sid_list" value="General;">'
		+ '<input type="hidden" name="group_id" value="">'
		+ '<input type="hidden" name="action_mode" value=" Apply ">'
		+ '<input type="hidden" name="action_script" value="">'
		+ '<input type="hidden" name="lp_bidir' + uid + '" value="' + (enabled ? '1' : '0') + '">';
	document.body.appendChild(form);
	form.submit();
}

function renderPrinters() {
	var usbPorts = printer_usbports();
	var models = printer_models();
	var manufs = printer_manufacts();
	var dataPorts = printer_dataports();
	var bidirs = printer_bidirs();
	var el = document.getElementById("printerList");
	if (!usbPorts || usbPorts.length === 0) {
		el.innerHTML = '<div class="empty"><span class="icon">&#128424;</span><#Stat_NoPrinterDetected#><br><small><#Stat_ConnectPrinterUsbHint#></small></div>';
		return;
	}
	/* Desktop: table layout */
	var h = '<table class="printer-table">';
	h += '<tr><th><#Stat_UsbPort#></th><th><#Stat_Manufacturer#></th><th><#Stat_Model#></th><th><#Stat_DataPort#></th><th><#Stat_Bidirectional#></th></tr>';
	for (var i = 0; i < usbPorts.length; i++) {
		var sepClass = (i < usbPorts.length - 1) ? ' class="printer-row-sep"' : '';
		var portNum = usbPorts[i];
		var dataPort = (dataPorts && dataPorts[i]) ? dataPorts[i] : 9100;
		if (g_bidirState[portNum] === undefined)
			g_bidirState[portNum] = (bidirs && bidirs[i]) ? 1 : 0;
		var checkedAttr = g_bidirState[portNum] ? ' checked' : '';
		var bidirId = 'bidir_' + portNum;
		h += '<tr' + sepClass + '>';
		h += '<td><#Stat_Port#>' + portNum + '</td>';
		h += '<td>' + (manufs[i] || 'Unknown') + '</td>';
		h += '<td>' + (models[i] || 'Unknown') + '</td>';
		h += '<td>' + dataPort + '</td>';
		h += '<td><label class="bidir-switch"><input type="checkbox" id="' + bidirId + '" data-uid="' + portNum + '"' + checkedAttr + ' onchange="toggleBidir(\'' + portNum + '\', this.checked)"><span class="bidir-slider"></span></label></td>';
		h += '</tr>';
	}
	h += '</table>';
	/* Mobile: vertical card layout */
	h += '<div class="printer-mobile">';
	for (var j = 0; j < usbPorts.length; j++) {
		var mPortNum = usbPorts[j];
		var mDataPort = (dataPorts && dataPorts[j]) ? dataPorts[j] : 9100;
		var mBidirId = 'bidir_m_' + mPortNum;
		if (g_bidirState[mPortNum] === undefined)
			g_bidirState[mPortNum] = (bidirs && bidirs[j]) ? 1 : 0;
		var mCheckedAttr = g_bidirState[mPortNum] ? ' checked' : '';
		h += '<div class="printer-mobile-item">';
		h += '<div class="pm-row"><span class="pm-label"><#Stat_UsbPort#></span><span class="pm-value"><#Stat_Port#>' + mPortNum + '</span></div>';
		h += '<div class="pm-row"><span class="pm-label"><#Stat_Manufacturer#></span><span class="pm-value">' + (manufs[j] || 'Unknown') + '</span></div>';
		h += '<div class="pm-row"><span class="pm-label"><#Stat_Model#></span><span class="pm-value">' + (models[j] || 'Unknown') + '</span></div>';
		h += '<div class="pm-row"><span class="pm-label"><#Stat_DataPort#></span><span class="pm-value">' + mDataPort + '</span></div>';
		h += '<div class="pm-row"><span class="pm-label"><#Stat_Bidirectional#></span><span class="pm-value"><label class="bidir-switch"><input type="checkbox" id="' + mBidirId + '" data-uid="' + mPortNum + '"' + mCheckedAttr + ' onchange="toggleBidir(\'' + mPortNum + '\', this.checked)"><span class="bidir-slider"></span></label></span></div>';
		h += '</div>';
	}
	h += '</div>';
	el.innerHTML = h;
}

renderPrinters();
setInterval(renderPrinters, 15000);
