<% firmware_caps_hook(); %>
/* 主页（父页面）脚本：标签切换、iframe 自适应、加载遮罩、密码修改、WiFi 扫描与桥接状态。
   由 do_ej 处理（**.js 走 EJ 模板引擎）。 */
/* 单频设备（无 5G 射频）时，搜索只扫 2.4G */
var has5gRadio = (typeof support_5g_radio === "function") ? !!support_5g_radio() : true;

var pages = {
	status: "status.asp",
	network: "network.asp",
	wireless: "wireless.asp",
	more: "more.asp"
};

function switchTab(name, btn) {
	var tabs = document.querySelectorAll(".nav-item");
	for (var i = 0; i < tabs.length; i++) {
		tabs[i].className = tabs[i].className.replace(" active", "");
	}
	btn.className += " active";
	try { localStorage.setItem("last_tab", name); } catch(e) {}
	var frame = document.getElementById("contentFrame");
	frame.src = pages[name];
}

/* Auto-resize iframe to fit content (no scrollbar) - throttled via rAF to avoid layout thrashing */
var _frameObserver = null;
var _resizePending = false;
function resizeFrame() {
	if (_resizePending) return;
	_resizePending = true;
	requestAnimationFrame(function() {
		_resizePending = false;
		var frame = document.getElementById("contentFrame");
		try {
			var win = frame.contentWindow;
			var doc = win.document || frame.contentDocument;
			/* Detect login redirect: marker, URL, title, or login form */
			var url = win.location.href || "";
			var title = doc.title || "";
			var hasLoginForm = doc.querySelector('form.login-form, #loginError, form[action*="Login.asp"], form[action*="login.asp"], form input[name="http_username"], form input[name="loginname"], form input[name="username"][type="text"]');
			if (win.__IS_LOGIN_PAGE__
				|| url.indexOf("Login.asp") >= 0 || url.indexOf("login.asp") >= 0 || url.indexOf("Logout") >= 0
				|| title.indexOf("Login") >= 0 || title.indexOf("登录") >= 0 || hasLoginForm) {
				top.location.href = "/Login.asp";
				return;
			}
			var h = doc.body.scrollHeight;
			if (h < 150) h = 150;
			frame.style.height = (h + 10) + "px";
		} catch(e) { /* cross-origin, ignore */ }
	});
}

/* Watch iframe content for structural changes only (no attributes/characterData to reduce noise) */
function setupFrameObserver() {
	var frame = document.getElementById("contentFrame");
	try {
		var doc = frame.contentDocument || frame.contentWindow.document;
		if (_frameObserver) _frameObserver.disconnect();
		_frameObserver = new MutationObserver(function() { resizeFrame(); });
		_frameObserver.observe(doc.body, { childList: true, subtree: true, attributes: true, attributeFilter: ["style", "class"] });
	} catch(e) {}
}

function initial() {
	var frame = document.getElementById("contentFrame");
	frame.onload = function() {
		resizeFrame();
		setupFrameObserver();
	};
	/* Restore last tab from localStorage (avoid jumping to WAN on refresh) */
	var lastTab = localStorage.getItem("last_tab") || "status";
	if (lastTab === "printer") lastTab = "more";
	if (!pages[lastTab]) lastTab = "status";
	/* Highlight the correct nav button */
	var navItems = document.querySelectorAll(".nav-item");
	for (var i = 0; i < navItems.length; i++) {
		navItems[i].className = navItems[i].className.replace(" active", "");
	}
	/* Find the button for lastTab */
	for (var j = 0; j < navItems.length; j++) {
		var onclickAttr = navItems[j].getAttribute("onclick") || "";
		if (onclickAttr.indexOf("'" + lastTab + "'") >= 0) {
			navItems[j].className += " active";
			break;
		}
	}
	frame.src = pages[lastTab];
	/* WIRELESS_BRIDGE_BEGIN */
	fetchBridgeStatus();
	setInterval(fetchBridgeStatus, 30000);
	/* WIRELESS_BRIDGE_END */
}

function showLoading(seconds, msg, noRefresh) {
	var overlay = document.getElementById("loadingOverlay");
	var txt = overlay.querySelector(".loading-text");
	txt.textContent = msg || "<#Msg_Applying#>";
	overlay.classList.remove("success");
	overlay.style.display = "flex";
	if (seconds) {
		setTimeout(function() {
			/* Switch to success checkmark animation */
			overlay.classList.add("success");
			txt.textContent = "<#Msg_ApplyOk#>";
			setTimeout(function() {
				overlay.style.display = "none";
				overlay.classList.remove("success");
				/* Refresh iframe to show new values (skip when noRefresh is true) */
				if (!noRefresh) {
					var frame = document.getElementById("contentFrame");
					if (frame.src) frame.src = frame.src;
				}
			}, 1200);
		}, seconds * 1000);
	}
}

function hideLoading() {
	var overlay = document.getElementById("loadingOverlay");
	overlay.style.display = "none";
	overlay.classList.remove("success");
}

function showToast(msg) {
	var t = document.getElementById("toast");
	t.textContent = msg;
	t.style.display = "block";
	t.style.background = "#c62828";
	setTimeout(function() {
		t.style.display = "none";
	}, 3000);
}

/* ── Password change modal ── */
function openPwdModal() {
	document.getElementById("pwd_old").value = "";
	document.getElementById("pwd_new").value = "";
	document.getElementById("pwd_confirm").value = "";
	document.getElementById("pwdMsg").textContent = "";
	document.getElementById("pwdModal").style.display = "flex";
}
function closePwdModal() {
	document.getElementById("pwdModal").style.display = "none";
}
function submitPwd() {
	var oldPwd = document.getElementById("pwd_old").value;
	var newPwd = document.getElementById("pwd_new").value;
	var confirmPwd = document.getElementById("pwd_confirm").value;
	var msg = document.getElementById("pwdMsg");
	var currentPwd = document.getElementById("http_passwd_current").value;
	if (!oldPwd) { msg.textContent = "<#Home_EnterCurrentPassword#>"; return false; }
	if (oldPwd !== currentPwd) { msg.textContent = "<#Home_CurrentPasswordWrong#>"; return false; }
	if (!newPwd) { msg.textContent = "<#Home_EnterNewPassword#>"; return false; }
	if (newPwd.length < 4) { msg.textContent = "<#Home_NewPasswordMin4#>"; return false; }
	if (newPwd !== confirmPwd) { msg.textContent = "<#Home_PasswordMismatch#>"; return false; }
	if (newPwd === oldPwd) { msg.textContent = "<#Home_NewPasswordSameAsOld#>"; return false; }
	document.getElementById("pwd_new_hidden").value = newPwd;
	closePwdModal();
	if (window.showLoading) showLoading(5, "<#Home_ChangingPassword#>");
	return true;
}

/* WIRELESS_BRIDGE_BEGIN */
/* ── WiFi scan modal (parent-level so overlay dims the whole page) ── */
var wifiScanResults = [];
function openWifiModal() {
	document.getElementById("wifiModalBody").innerHTML = '<div class="scan-empty"><#Home_ClickToSearchWifi#></div>';
	document.getElementById("wifiScanBtn").disabled = false;
	document.getElementById("wifiScanBtn").innerHTML = "<#Home_SearchWifi#>";
	document.getElementById("wifiModal").classList.add("show");
}
function closeWifiModal() {
	document.getElementById("wifiModal").classList.remove("show");
}
document.getElementById("wifiModal").addEventListener("click", function(e) {
	if (e.target === this) closeWifiModal();
});
function doScan() {
	var scanBtn = document.getElementById("wifiScanBtn");
	var body = document.getElementById("wifiModalBody");
	scanBtn.disabled = true;
	scanBtn.innerHTML = '<span class="scan-spin"></span><#Home_Searching#>';
	body.innerHTML = '<div class="scan-empty"><span class="scan-spin"></span><#Home_SearchingNearby#></div>';
	wifiScanResults = [];
	var done = 0, total = has5gRadio ? 2 : 1;
	function checkDone() {
		done++;
		if (done >= total) {
			wifiScanResults.sort(function(a, b) { return (parseInt(b[3]) || 0) - (parseInt(a[3]) || 0); });
			renderWifiList();
		}
	}
	jQuery.ajax({ url: '/wds_aplist_2g.asp', dataType: 'script', timeout: 20000,
		success: function() {
			if (window.wds_aplist_2g && wds_aplist_2g.length > 0) {
				for (var i = 0; i < wds_aplist_2g.length; i++) wifiScanResults.push(wds_aplist_2g[i]);
			}
			checkDone();
		},
		error: function() { checkDone(); }
	});
	if (!has5gRadio) return;
	jQuery.ajax({ url: '/wds_aplist_5g.asp', dataType: 'script', timeout: 20000,
		success: function() {
			if (window.wds_aplist_5g && wds_aplist_5g.length > 0) {
				for (var i = 0; i < wds_aplist_5g.length; i++) wifiScanResults.push(wds_aplist_5g[i]);
			}
			checkDone();
		},
		error: function() { checkDone(); }
	});
}
function renderWifiList() {
	var scanBtn = document.getElementById("wifiScanBtn");
	var body = document.getElementById("wifiModalBody");
	scanBtn.disabled = false;
	scanBtn.innerHTML = "<#Home_RescanWifi#>";
	if (!wifiScanResults || wifiScanResults.length === 0) {
		body.innerHTML = '<div class="scan-empty"><#Home_NoWifiFound#></div>';
		return;
	}
	var html = "";
	for (var i = 0; i < wifiScanResults.length; i++) {
		var item = wifiScanResults[i];
		var ssid = item[0] || "???";
		var bssid = item[1] || "";
		var channel = parseInt(item[2]) || 0;
		var signal = item[3] || "";
		var sec = item[4] || "";
		var is5g = channel >= 36;
		var bandLabel = is5g ? '<span class="ap-band ap-band-5g">5G</span>' : '<span class="ap-band ap-band-2g">2.4G</span>';
		var bandVal = is5g ? "5g" : "2g";
		html += '<div class="ap-item" onclick="selectAP(\'' + ssid.replace(/'/g, "\\'") + '\', \'' + bandVal + '\', ' + i + ', \'' + (sec ? sec.replace(/'/g, "\\'") : "") + '\')" data-idx="' + i + '">';
		html += '<div class="ap-info"><div class="ap-name">' + decodeSSID(ssid) + bandLabel + '</div>';
		html += '<div class="ap-meta"><#Home_Channel#> ' + channel + (bssid ? ' · ' + bssid : '') + (sec ? ' · ' + sec : '') + '</div></div>';
		html += '<div class="ap-signal">' + signal + '</div>';
		html += '</div>';
	}
	body.innerHTML = html;
}
function decodeSSID(s) {
	if (!s || s === "???") return "???";
	try { return decodeURIComponent(s); } catch(e) { return s; }
}
function selectAP(ssid, band, idx, sec) {
	var items = document.querySelectorAll("#wifiModal .ap-item");
	for (var i = 0; i < items.length; i++) {
		items[i].className = items[i].className.replace(" selected", "");
	}
	if (items[idx]) items[idx].className += " selected";
	var decoded;
	try { decoded = decodeURIComponent(ssid); } catch(e) { decoded = ssid; }
	var frame = document.getElementById("contentFrame");
	if (frame && frame.contentWindow && typeof frame.contentWindow.applySelectedAP === "function") {
		frame.contentWindow.applySelectedAP(decoded, band, sec);
	}
	closeWifiModal();
}

function fetchBridgeStatus() {
	var xhr = new XMLHttpRequest();
	xhr.open("GET", "/bridge_status.asp", true);
	xhr.onreadystatechange = function() {
		if (xhr.readyState === 4 && xhr.status === 200) {
			try {
				eval(xhr.responseText);
				if (typeof bridge_status !== "undefined") {
					updateHomeStatus(bridge_status);
				}
			} catch(e) { console.log("bridge status parse error:", e); }
		}
	};
	xhr.send();
}

function updateHomeStatus(s) {
	var strip = document.getElementById("bridgeStatusStrip");
	var activeMode = s.mode === 4 ? 4 : (s.mode5g === 4 ? 4 : 0);
	if (activeMode === 0) {
		strip.style.display = "none";
		return;
	}
	strip.style.display = "flex";
	var activeWisp = s.mode === 4 ? s.wisp : (s.mode5g === 4 ? s.wisp5g : 0);
	/* Display as "客户端" per requirement */
	document.getElementById("hsBridgeMode").textContent = "<#Home_Client#>";
	document.getElementById("hsBridgeBand").textContent = s.upstream_band || "--";
	document.getElementById("hsBridgeSsid").textContent = s.upstream_ssid || "--";
	var conn = document.getElementById("hsBridgeConn");
	if (s.connected) {
		conn.textContent = "<#Home_Connected#>";
		conn.className = "ss-value ok";
	} else {
		conn.textContent = "<#Home_Disconnected#>";
		conn.className = "ss-value bad";
	}
	document.getElementById("hsBridgeIp").textContent = s.ipaddr || "--";
}

/* WIRELESS_BRIDGE_END */
