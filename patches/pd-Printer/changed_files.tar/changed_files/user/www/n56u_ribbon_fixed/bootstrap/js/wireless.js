<% firmware_caps_hook(); %>
/* 无线页脚本：WiFi 设置、无线桥接与桥接状态查询。
   由 do_ej 处理（**.js 走 EJ 模板引擎）。 */
var selectedBand = "";
var $j = jQuery.noConflict();
var has5gRadio = (typeof support_5g_radio === "function") ? !!support_5g_radio() : true;

function togglePsk2g() {
	var open = document.formAP.rt_auth_mode.value === "open";
	document.getElementById("rtPskRow").style.display = open ? "none" : "";
}
function togglePsk5g() {
	var open = document.formAP.wl_auth_mode.value === "open";
	document.getElementById("wlPskRow").style.display = open ? "none" : "";
}
/* WIRELESS_BRIDGE_BEGIN */
function toggleStaPsk() {
	var open = document.getElementById("sta_auth_mode").value === "open";
	document.getElementById("staPskRow").style.display = open ? "none" : "";
}
/* WIRELESS_BRIDGE_END */

/* WIRELESS_BRIDGE_BEGIN */
/* ── Bridge enable/disable toggle ── */
function toggleBridge() {
	var enabled = document.getElementById("bridgeEnable").checked;
	var settings = document.getElementById("bridgeSettings");
	if (enabled) {
		settings.style.display = "";
		settings.classList.remove("disabled");
	} else {
		settings.style.display = "none";
		/* Set both modes to 0 (AP only) to disable bridging */
		document.getElementById("rt_mode_x").value = "0";
		document.getElementById("wl_mode_x").value = "0";
		document.getElementById("rt_sta_wisp").value = "0";
		document.getElementById("wl_sta_wisp").value = "0";
	}
}

/* ── Apply selected AP (called from parent WiFi scan modal) ── */
function applySelectedAP(decoded, band, sec) {
	selectedBand = band;
	document.getElementById("upstream_ssid").value = decoded;

	/* Auto-fill auth mode based on security info */
	var authSelect = document.getElementById("sta_auth_mode");
	if (sec && sec.toUpperCase().indexOf("WPA") >= 0) {
		authSelect.value = "psk";
	} else if (sec && sec.toUpperCase().indexOf("OPEN") >= 0) {
		authSelect.value = "open";
	} else {
		/* default to psk (most common) */
		authSelect.value = "psk";
	}
	toggleStaPsk();

	/* Set mode_x=4 (AP-Client+AP), wisp=1 (WISP) by default */
	if (band === "2g") {
		document.getElementById("rt_sta_ssid").value = decoded;
		document.getElementById("wl_sta_ssid").value = "";
		document.getElementById("rt_mode_x").value = "4";
		document.getElementById("wl_mode_x").value = "0";
		document.getElementById("rt_sta_wisp").value = "1";
		document.getElementById("wl_sta_wisp").value = "0";
	} else {
		document.getElementById("wl_sta_ssid").value = decoded;
		document.getElementById("rt_sta_ssid").value = "";
		document.getElementById("wl_mode_x").value = "4";
		document.getElementById("rt_mode_x").value = "0";
		document.getElementById("wl_sta_wisp").value = "1";
		document.getElementById("rt_sta_wisp").value = "0";
	}

	/* Focus password field for quick entry */
	setTimeout(function() { document.getElementById("sta_psk").focus(); }, 150);
}

function onBridgeApply() {
	var enabled = document.getElementById("bridgeEnable").checked;
	if (!enabled) {
		/* Bridge disabled: mode_x already set to 0 by toggleBridge(), just submit */
		if (parent && parent.showLoading) {
			parent.showLoading(8, "<#Wl_DisablingBridge#>", true);
		}
		return true;
	}
	var ssid = document.getElementById("upstream_ssid").value;
	if (!ssid) {
		alert("<#Wl_AlertSelectUpstreamWifi#>");
		return false;
	}
	var psk = document.getElementById("sta_psk").value;
	var auth = document.getElementById("sta_auth_mode").value;
	document.getElementById("rt_sta_wpa_psk").value = psk;
	document.getElementById("wl_sta_wpa_psk").value = psk;
	document.getElementById("rt_sta_auth_mode").value = auth;
	document.getElementById("wl_sta_auth_mode").value = auth;
	/* Default WISP mode */
	if (document.getElementById("rt_mode_x").value === "4") {
		document.getElementById("rt_sta_wisp").value = "1";
	}
	if (document.getElementById("wl_mode_x").value === "4") {
		document.getElementById("wl_sta_wisp").value = "1";
	}
	if (auth === "psk" && psk.length < 8) {
		alert("<#Wl_AlertPasswordMin8#>");
		return false;
	}
	/* 无线会重启复位，loading 后停留在当前页面不刷新 */
	if (parent && parent.showLoading) {
		parent.showLoading(20, "<#Wl_ApplyingBridgeRestart#>", true);
	}
	return true;
}

/* ── Bridge status (mode row removed per requirement) ── */
function loadBridgeStatus() {
	$j.ajax({
		url: '/bridge_status.asp',
		dataType: 'script',
		timeout: 5000,
		success: function() {
			if (typeof bridge_status !== 'undefined') {
				updateStatusDisplay(bridge_status);
			}
		},
		error: function() {
			var el = document.getElementById("curStatus");
			if (el) {
				el.textContent = "<#Wl_QueryFailed#>";
				el.className = "bridge-conn-badge disconnected";
			}
		}
	});
}

function updateStatusDisplay(s) {
	var statusEl = document.getElementById("curStatus");
	if (!statusEl) return;
	var activeMode = s.mode === 4 ? s.mode : (s.mode5g === 4 ? s.mode5g : 0);
	if (activeMode === 0) {
		statusEl.textContent = "<#Wl_BridgeNotEnabled#>";
		statusEl.className = "bridge-conn-badge disconnected";
		return;
	}
	if (s.connected) {
		statusEl.textContent = "<#Wl_Connected#>";
		statusEl.className = "bridge-conn-badge connected";
	} else {
		statusEl.textContent = "<#Wl_NotConnected#>";
		statusEl.className = "bridge-conn-badge disconnected";
	}
}

/* WIRELESS_BRIDGE_END */
togglePsk2g();
togglePsk5g();
/* WIRELESS_BRIDGE_BEGIN */
toggleStaPsk();
/* WIRELESS_BRIDGE_END */

/* Initialize WiFi radio toggles from nvram */
(function() {
	var rtRadio = document.getElementById("rt_radio_x").value;
	var wlRadio = document.getElementById("wl_radio_x").value;
	document.getElementById("rt_radio_x_cb").checked = (rtRadio === "1" || rtRadio === "");
	document.getElementById("wl_radio_x_cb").checked = (wlRadio === "1" || wlRadio === "");
})();

/* WIRELESS_BRIDGE_BEGIN */
/* ── Auto-fill bridge settings from NVRAM (original firmware style) ── */
function initBridgeSettings() {
	var rtMode = document.getElementById("rt_mode_x").value;
	var wlMode = document.getElementById("wl_mode_x").value;
	var rtSsid = document.getElementById("rt_sta_ssid").value;
	var wlSsid = document.getElementById("wl_sta_ssid").value;
	var rtPsk = document.getElementById("rt_sta_wpa_psk").value;
	var wlPsk = document.getElementById("wl_sta_wpa_psk").value;
	var rtAuth = document.getElementById("rt_sta_auth_mode").value;
	var wlAuth = document.getElementById("wl_sta_auth_mode").value;

	/* Set toggle state: bridge enabled if either mode is 4 (AP-Client+AP) */
	var bridgeEnabled = (rtMode === "4" || wlMode === "4");
	document.getElementById("bridgeEnable").checked = bridgeEnabled;
	toggleBridge();

	/* Determine active band: 2.4G if rt_mode_x==4, 5G if wl_mode_x==4 */
	if (rtMode === "4" && rtSsid) {
		/* 2.4G bridge active, fill fields */
		document.getElementById("upstream_ssid").value = rtSsid;
		document.getElementById("sta_auth_mode").value = rtAuth || "psk";
		document.getElementById("sta_psk").value = rtPsk || "";
		selectedBand = "2g";
	} else if (wlMode === "4" && wlSsid) {
		/* 5G bridge active, fill fields */
		document.getElementById("upstream_ssid").value = wlSsid;
		document.getElementById("sta_auth_mode").value = wlAuth || "psk";
		document.getElementById("sta_psk").value = wlPsk || "";
		selectedBand = "5g";
	}
	toggleStaPsk();
}
initBridgeSettings();
/* WIRELESS_BRIDGE_END */

/* ── Single-band device: hide & strip all 5G related options ── */
if (!has5gRadio) {
	var s5 = document.getElementById("band5gSection");
	if (s5) {
		s5.style.display = "none";
		var sels = s5.querySelectorAll("input, select, textarea");
		for (var i = 0; i < sels.length; i++) sels[i].disabled = true;
	}
	var b5 = document.getElementById("bridge5gFields");
	if (b5) {
		var bels = b5.querySelectorAll("input");
		for (var k = 0; k < bels.length; k++) bels[k].disabled = true;
	}
	/* bridge SSID / PSK hidden fields that also write the 5G radio */
	var wlSsidEl = document.getElementById("wl_sta_ssid");
	if (wlSsidEl) wlSsidEl.disabled = true;
	var wlPskEl = document.getElementById("wl_sta_wpa_psk");
	if (wlPskEl) wlPskEl.disabled = true;
}

/* WIRELESS_BRIDGE_BEGIN */
loadBridgeStatus();
setInterval(loadBridgeStatus, 15000);
/* WIRELESS_BRIDGE_END */
