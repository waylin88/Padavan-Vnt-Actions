<!DOCTYPE html>
<html>
<head>
<title><#Web_Title#></title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Expires" content="-1">

<link rel="shortcut icon" href="/bootstrap/img/favicon.ico">
<link rel="icon" href="/bootstrap/img/favicon.png">
<link rel="stylesheet" type="text/css" href="/bootstrap/css/nologin.css">

<script>
<% login_state_hook(); %>

function initial(){
  document.getElementById("logined_ip_str").innerHTML = login_ip_str();
}
</script>
</head>

<body onload="initial()">
<center>
    <div class="alert alert-info">
        <p><#login_hint1#> <span id="logined_ip_str"></span></p>
        <p><#login_hint2#></p>
    </div>
</center>
</body>
</html>
