wds_aplist_5g = <% wl_scan_5g(); %>;
