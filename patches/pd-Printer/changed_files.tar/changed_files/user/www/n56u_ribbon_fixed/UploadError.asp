<!DOCTYPE html>
<html>
<head>
<title></title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Expires" content="-1">

<link rel="shortcut icon" href="/bootstrap/img/favicon.ico">
<link rel="icon" href="/bootstrap/img/favicon.png">
</head>
<body>
<script>
	alert("<#SET_fail_desc#>");
</script>
</body>
</html>
