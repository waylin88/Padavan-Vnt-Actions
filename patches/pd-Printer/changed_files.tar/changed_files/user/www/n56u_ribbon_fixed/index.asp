<!DOCTYPE html>
<html>
<head>
<title><% nvram_get_x("", "productid"); %> Print Server</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Expires" content="-1">
<link rel="shortcut icon" href="images/favicon.ico">
<link rel="icon" href="images/favicon.png">
<style type="text/css">
* { box-sizing: border-box; }
html, body { margin: 0; padding: 0; height: 100%; font-family: Arial, "Microsoft YaHei", sans-serif; }
body {
	background: linear-gradient(180deg, #fdf6ec 0%, #f8edda 40%, #f0f2f5 100%);
	min-height: 100vh; color: #000;
}
/* Top bar (aligned with content card edges) */
.top-bar {
	display: flex; align-items: center; justify-content: space-between;
	max-width: 820px; margin: 0 auto; width: 100%;
	padding: 16px 16px 0;
}
.top-left { display: flex; align-items: baseline; }
.logo { font-size: 22px; font-weight: bold; color: #ff6a00; }
.subtitle { font-size: 14px; color: #999; margin-left: 10px; }
.top-right { font-size: 13px; color: #888; }
.top-right a { color: #ff6a00; text-decoration: none; margin-left: 8px; }
.top-right a:hover { text-decoration: underline; }
/* Icon nav (spread evenly, aligned with card) */
.nav-bar {
	display: flex; justify-content: space-around; align-items: flex-start;
	max-width: 820px; margin: 0 auto; width: 100%;
	padding: 20px 16px 16px; overflow-x: auto; -webkit-overflow-scrolling: touch;
}
.nav-item {
	display: flex; flex-direction: column; align-items: center;
	flex: 1; min-width: 100px; padding: 4px 12px; cursor: pointer;
	border: none; background: none; transition: all .2s;
}
.nav-icon {
	width: 52px; height: 52px; border-radius: 50%;
	display: flex; align-items: center; justify-content: center;
	background: #fff; color: #ffb066; margin-bottom: 6px;
	transition: all .2s; border: 2px solid transparent;
	box-shadow: 0 2px 6px rgba(0,0,0,.06);
}
.nav-icon svg { width: 26px; height: 26px; fill: currentColor; }
.nav-item.active .nav-icon {
	background: #ff6a00; color: #fff; box-shadow: 0 3px 12px rgba(255,106,0,.3);
}
.nav-item:hover .nav-icon { background: #fff0e0; }
.nav-item.active:hover .nav-icon { background: #ff6a00; color: #fff; }
.nav-label { font-size: 13px; color: #999; white-space: nowrap; }
.nav-item.active .nav-label { color: #ff6a00; font-weight: bold; }
/* Content card (auto height, no scrollbar) */
.content-wrap { padding: 0 16px 16px; max-width: 860px; margin: 0 auto; }
.content-card {
	background: #fff; border-radius: 12px; min-height: 200px;
	box-shadow: 0 2px 12px rgba(0,0,0,.06); overflow: hidden;
	transition: min-height .2s;
}
.content-frame { width: 100%; height: 100px; border: none; display: block; overflow: hidden; }
/* Loading overlay (with success checkmark animation) */
#loadingOverlay {
	display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%;
	background: rgba(0,0,0,.2); z-index: 9999;
	justify-content: center; align-items: center;
}
#loadingOverlay .loading-box {
	background: #fff; border-radius: 10px; padding: 32px 48px; text-align: center;
	box-shadow: 0 4px 20px rgba(0,0,0,.12); min-width: 200px;
}
#loadingOverlay .icon-wrap {
	width: 48px; height: 48px; margin: 0 auto 14px; position: relative;
}
#loadingOverlay .spinner {
	width: 48px; height: 48px; border: 3px solid #ffe8d0;
	border-top-color: #ff6a00; border-radius: 50%;
	animation: spin .8s linear infinite;
}
#loadingOverlay .checkmark {
	display: none; width: 48px; height: 48px;
}
#loadingOverlay .checkmark svg { width: 48px; height: 48px; }
#loadingOverlay .checkmark path {
	stroke: #2e7d32; stroke-width: 4; fill: none;
	stroke-dasharray: 60; stroke-dashoffset: 60;
}
#loadingOverlay.success .spinner { display: none; }
#loadingOverlay.success .checkmark { display: block; animation: pop .3s ease; }
#loadingOverlay.success .checkmark path { animation: draw .4s ease forwards; }
@keyframes spin { to { transform: rotate(360deg); } }
@keyframes draw { to { stroke-dashoffset: 0; } }
@keyframes pop { 0% { transform: scale(0); } 70% { transform: scale(1.2); } 100% { transform: scale(1); } }
#loadingOverlay .loading-text { font-size: 14px; color: #555; }
#loadingOverlay.success .loading-text { color: #2e7d32; }
/* Toast (kept for errors only) */
#toast {
	display: none; position: fixed; top: 90px; left: 50%; transform: translateX(-50%);
	background: #c62828; color: #fff; padding: 10px 24px; border-radius: 4px;
	font-size: 14px; z-index: 9998; box-shadow: 0 2px 8px rgba(0,0,0,.12);
}
/* Bridge status strip (home page) */
.status-strip-wrap { max-width: 860px; margin: 0 auto; padding: 0 16px; }
.status-strip {
	background: #fff; border-radius: 10px; padding: 10px 16px; margin-bottom: 12px;
	display: flex; justify-content: space-between; align-items: center;
	box-shadow: 0 2px 8px rgba(0,0,0,.05); flex-wrap: wrap; gap: 8px;
}
.status-strip .ss-item { display: flex; flex-direction: column; align-items: center; flex: 1; min-width: 70px; }
.status-strip .ss-label { font-size: 11px; color: #888; }
.status-strip .ss-value { font-size: 13px; color: #333; font-weight: 500; margin-top: 2px; }
.status-strip .ss-value.ok { color: #2e7d32; }
.status-strip .ss-value.bad { color: #c62828; }
/* Password change modal */
#pwdModal {
	display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%;
	background: rgba(0,0,0,.3); z-index: 10000; justify-content: center; align-items: center;
}
#pwdModal .pwd-box {
	background: #fff; border-radius: 10px; padding: 24px 28px; width: 90%; max-width: 360px;
	box-shadow: 0 4px 20px rgba(0,0,0,.15);
}
#pwdModal .pwd-title { font-size: 16px; font-weight: bold; color: #000; margin-bottom: 16px; }
#pwdModal .pwd-row { margin-bottom: 12px; }
#pwdModal .pwd-row label { display: block; font-size: 13px; color: #666; margin-bottom: 4px; }
#pwdModal .pwd-row input { width: 100%; padding: 8px 10px; border: 1px solid #d0d0d0; border-radius: 4px; font-size: 14px; color: #000; }
#pwdModal .pwd-row input:focus { border-color: #ff6a00; outline: none; }
#pwdModal .pwd-btns { display: flex; justify-content: space-between; gap: 12px; margin-top: 16px; }
#pwdModal .pwd-btn { padding: 7px 20px; border-radius: 4px; cursor: pointer; font-size: 14px; border: none; }
#pwdModal .pwd-btn.primary { background: #ff6a00; color: #fff; }
#pwdModal .pwd-btn.primary:hover { background: #e55f00; }
#pwdModal .pwd-btn.cancel { background: #f0f0f0; color: #666; }
#pwdModal .pwd-btn.cancel:hover { background: #e0e0e0; }
#pwdModal .pwd-msg { font-size: 12px; color: #c62828; margin-top: 4px; min-height: 16px; }
/* WiFi scan modal (parent-level so the overlay dims the whole page) */
#wifiModal {
	display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%;
	background: rgba(0,0,0,.3); z-index: 10000; justify-content: center; align-items: center;
}
#wifiModal.show { display: flex; }
#wifiModal .wifi-box {
	background: #fff; border-radius: 10px; width: 90%; max-width: 420px;
	max-height: 80vh; display: flex; flex-direction: column; overflow: hidden;
	box-shadow: 0 4px 20px rgba(0,0,0,.15);
}
#wifiModal .wifi-head {
	display: flex; align-items: center; justify-content: space-between;
	padding: 14px 16px; border-bottom: 1px solid #eee;
}
#wifiModal .wifi-head h4 { margin: 0; font-size: 15px; color: #000; }
#wifiModal .wifi-close { background: none; border: none; font-size: 20px; color: #999; cursor: pointer; line-height: 1; }
#wifiModal .wifi-body { flex: 1; overflow-y: auto; padding: 8px 0; min-height: 120px; }
#wifiModal .wifi-foot { padding: 10px 16px; border-top: 1px solid #eee; text-align: center; }
.wifi-scan-btn { background: #ff6a00; color: #fff; border: none; padding: 8px 24px; border-radius: 4px; cursor: pointer; font-size: 14px; }
.wifi-scan-btn:hover { background: #e55f00; }
.wifi-scan-btn:disabled { background: #ccc; cursor: default; }
.scan-empty { padding: 24px; text-align: center; color: #999; font-size: 13px; }
.scan-spin { display: inline-block; width: 12px; height: 12px; border: 2px solid #e0e0e0; border-top-color: #ff6a00; border-radius: 50%; animation: spin .8s linear infinite; vertical-align: middle; margin-right: 6px; }
.ap-item { display: flex; align-items: center; padding: 10px 16px; border-bottom: 1px solid #f5f5f5; cursor: pointer; }
.ap-item:last-child { border-bottom: none; }
.ap-item:hover { background: #fff0e0; }
.ap-item.selected { background: #ffe0b2; }
.ap-info { flex: 1; min-width: 0; }
.ap-name { font-weight: 500; color: #000; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.ap-meta { font-size: 11px; color: #999; margin-top: 2px; }
.ap-band { font-size: 11px; padding: 1px 6px; border-radius: 3px; margin-left: 6px; flex-shrink: 0; }
.ap-band-2g { background: #fff3e0; color: #e65100; }
.ap-band-5g { background: #e3f2fd; color: #1565c0; }
.ap-signal { font-size: 12px; color: #666; width: 44px; text-align: right; flex-shrink: 0; }
@media (max-width: 480px) {
	.top-bar { padding: 12px 8px 0; }
	.logo { font-size: 19px; }
	.subtitle { display: none; }
	.nav-item { min-width: 70px; padding: 4px 4px; }
	.nav-icon { width: 44px; height: 44px; }
	.nav-icon svg { width: 22px; height: 22px; }
	.nav-label { font-size: 12px; }
	.content-frame { height: calc(100vh - 150px); }
	/* Mobile: reduce card padding, widen to fit screen */
	.content-wrap { padding: 0 6px 12px; }
	.status-strip-wrap { padding: 0 6px; }
	.nav-bar { padding: 16px 6px 12px; }
	/* Mobile: bridge status strip shows only connection status + IP */
	.status-strip .ss-item[data-hide-mobile] { display: none; }
	.status-strip { justify-content: space-around; }
	.status-strip .ss-item { min-width: 0; flex: 1; }
	.status-strip .ss-label { font-size: 10px; }
	.status-strip .ss-value { font-size: 12px; }
}
</style>
<script type="text/javascript" src="/jquery.js"></script>
</head>
<body onload="initial()">
<div class="top-bar">
	<div class="top-left">
		<span class="logo"><% nvram_get_x("", "productid"); %></span>
		<span class="subtitle">打印服务器</span>
	</div>
	<div class="top-right">
		<a href="javascript:void(0)" onclick="openPwdModal()">修改密码</a>
		<a href="/Logout.asp">退出</a>
	</div>
</div>
<nav class="nav-bar">
	<button class="nav-item active" onclick="switchTab('status', this)">
		<div class="nav-icon"><svg viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 17.93c-3.95-.49-7-3.85-7-7.93 0-.62.08-1.21.21-1.79L9 15v1c0 1.1.9 2 2 2v1.93zm6.9-2.54c-.26-.81-1-1.39-1.9-1.39h-1v-3c0-.55-.45-1-1-1H8v-2h2c.55 0 1-.45 1-1V7h2c1.1 0 2-.9 2-2v-.41c2.93 1.19 5 4.07 5 7.41 0 2.08-.8 3.97-2.1 5.39z"/></svg></div>
		<span class="nav-label">状态</span>
	</button>
	<button class="nav-item" onclick="switchTab('network', this)">
		<div class="nav-icon"><svg viewBox="0 0 24 24"><path d="M20 18c1.1 0 1.99-.9 1.99-2L22 6c0-1.1-.9-2-2-2H4c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2H0v2h24v-2h-4zM4 6h16v10H4V6z"/></svg></div>
		<span class="nav-label">网络</span>
	</button>
	<button class="nav-item" onclick="switchTab('wireless', this)">
		<div class="nav-icon"><svg viewBox="0 0 24 24"><path d="M12 21l3.6-4.5c-1-0.8-2.3-1.3-3.6-1.3s-2.6 0.5-3.6 1.3L12 21zm0-9c2.7 0 5.2 1.1 7 2.9l2-2C19 10.8 15.7 9.5 12 9.5S5 10.8 3 12.9l2 2C6.8 13.1 9.3 12 12 12zm0-4c4.2 0 8 1.6 10.9 4.1l2-2.2C21.5 6.8 16.9 5 12 5S2.5 6.8 0 9.9l2 2.2C4.8 9.6 8.6 8 12 8z"/></svg></div>
		<span class="nav-label">无线</span>
	</button>
	<button class="nav-item" onclick="switchTab('more', this)">
		<div class="nav-icon"><svg viewBox="0 0 24 24"><path d="M19.14 12.94c.04-.3.06-.61.06-.94 0-.32-.02-.64-.07-.94l2.03-1.58c.18-.14.23-.41.12-.61l-1.92-3.32c-.12-.22-.37-.29-.59-.22l-2.39.96c-.5-.38-1.03-.7-1.62-.94l-.36-2.54c-.04-.24-.24-.41-.48-.41h-3.84c-.24 0-.43.17-.47.41l-.36 2.54c-.59.24-1.13.57-1.62.94l-2.39-.96c-.22-.08-.47 0-.59.22L2.74 8.87c-.12.21-.08.47.12.61l2.03 1.58c-.05.3-.09.63-.09.94s.02.64.07.94l-2.03 1.58c-.18.14-.23.41-.12.61l1.92 3.32c.12.22.37.29.59.22l2.39-.96c.5.38 1.03.7 1.62.94l.36 2.54c.05.24.24.41.48.41h3.84c.24 0 .44-.17.47-.41l.36-2.54c.59-.24 1.13-.56 1.62-.94l2.39.96c.22.08.47 0 .59-.22l1.92-3.32c.12-.22.07-.47-.12-.61l-2.01-1.58zM12 15.6c-1.98 0-3.6-1.62-3.6-3.6s1.62-3.6 3.6-3.6 3.6 1.62 3.6 3.6-1.62 3.6-3.6 3.6z"/></svg></div>
		<span class="nav-label">更多设置</span>
	</button>
</nav>
<div class="status-strip-wrap">
	<div class="status-strip" id="bridgeStatusStrip" style="display:none;">
		<div class="ss-item" data-hide-mobile><span class="ss-label">桥接模式</span><span class="ss-value" id="hsBridgeMode">--</span></div>
		<div class="ss-item" data-hide-mobile><span class="ss-label">频段</span><span class="ss-value" id="hsBridgeBand">--</span></div>
		<div class="ss-item" data-hide-mobile><span class="ss-label">上级WiFi</span><span class="ss-value" id="hsBridgeSsid">--</span></div>
		<div class="ss-item"><span class="ss-label">连接状态</span><span class="ss-value" id="hsBridgeConn">--</span></div>
		<div class="ss-item"><span class="ss-label">获取IP</span><span class="ss-value" id="hsBridgeIp">--</span></div>
	</div>
</div>
<div class="content-wrap">
	<div class="content-card">
		<iframe id="contentFrame" class="content-frame" src=""></iframe>
	</div>
</div>
<div id="loadingOverlay">
	<div class="loading-box">
		<div class="icon-wrap">
			<div class="spinner"></div>
			<div class="checkmark"><svg viewBox="0 0 52 52"><path d="M14 27 L22 35 L38 17"/></svg></div>
		</div>
		<div class="loading-text">正在应用设置，请稍候...</div>
	</div>
</div>
<div id="toast"></div>
<div id="pwdModal">
	<div class="pwd-box">
		<div class="pwd-title">修改管理密码</div>
		<iframe name="pwd_hidden_frame" id="pwd_hidden_frame" src="" width="0" height="0" frameborder="0"></iframe>
		<form method="post" name="pwdForm" action="/start_apply.htm" target="pwd_hidden_frame" onsubmit="return submitPwd()">
			<div class="pwd-row">
				<label>当前密码</label>
				<input type="password" id="pwd_old" autocomplete="off">
			</div>
			<div class="pwd-row">
				<label>新密码</label>
				<input type="password" id="pwd_new" autocomplete="off">
			</div>
			<div class="pwd-row">
				<label>确认新密码</label>
				<input type="password" id="pwd_confirm" autocomplete="off">
			</div>
			<div class="pwd-msg" id="pwdMsg"></div>
			<input type="hidden" name="current_page" value="index.asp">
			<input type="hidden" name="next_page" value="index.asp">
			<input type="hidden" name="next_host" value="">
			<input type="hidden" name="sid_list" value="General;">
			<input type="hidden" name="group_id" value="">
			<input type="hidden" name="action_mode" value=" Apply ">
			<input type="hidden" name="action_script" value="">
			<input type="hidden" name="http_passwd" id="pwd_new_hidden" value="">
			<div class="pwd-btns">
				<button type="button" class="pwd-btn cancel" onclick="closePwdModal()">取消</button>
				<button type="submit" class="pwd-btn primary">确认修改</button>
			</div>
		</form>
	</div>
	<input type="hidden" id="http_passwd_current" value="<% nvram_get_x("", "http_passwd"); %>">
</div>
<div id="wifiModal">
	<div class="wifi-box">
		<div class="wifi-head">
			<h4>搜索 WiFi</h4>
			<button type="button" class="wifi-close" onclick="closeWifiModal()">&times;</button>
		</div>
		<div class="wifi-body" id="wifiModalBody">
			<div class="scan-empty">点击下方按钮搜索附近 WiFi</div>
		</div>
		<div class="wifi-foot">
			<button type="button" class="wifi-scan-btn" id="wifiScanBtn" onclick="doScan()">搜索 WiFi</button>
		</div>
	</div>
</div>
<script type="text/javascript">
<% firmware_caps_hook(); %>
/* 单频设备（无 5G 射频）时，搜索只扫 2.4G */
var has5gRadio = (typeof support_5g_radio === "function") ? !!support_5g_radio() : true;
var pages = {
	status: "status.asp",
	network: "network.asp",
	wireless: "wireless.asp",
	more: "more.asp"
};

function switchTab(name, btn) {
	var tabs = document.querySelectorAll(".nav-item");
	for (var i = 0; i < tabs.length; i++) {
		tabs[i].className = tabs[i].className.replace(" active", "");
	}
	btn.className += " active";
	try { localStorage.setItem("last_tab", name); } catch(e) {}
	var frame = document.getElementById("contentFrame");
	frame.src = pages[name];
}

/* Auto-resize iframe to fit content (no scrollbar) - throttled via rAF to avoid layout thrashing */
var _frameObserver = null;
var _resizePending = false;
function resizeFrame() {
	if (_resizePending) return;
	_resizePending = true;
	requestAnimationFrame(function() {
		_resizePending = false;
		var frame = document.getElementById("contentFrame");
		try {
			var win = frame.contentWindow;
			var doc = win.document || frame.contentDocument;
			/* Detect login redirect: marker, URL, title, or login form */
			var url = win.location.href || "";
			var title = doc.title || "";
			var hasLoginForm = doc.querySelector('form.login-form, #loginError, form[action*="Login.asp"], form[action*="login.asp"], form input[name="http_username"], form input[name="loginname"], form input[name="username"][type="text"]');
			if (win.__IS_LOGIN_PAGE__
				|| url.indexOf("Login.asp") >= 0 || url.indexOf("login.asp") >= 0 || url.indexOf("Logout") >= 0
				|| title.indexOf("Login") >= 0 || title.indexOf("登录") >= 0 || hasLoginForm) {
				top.location.href = "/Login.asp";
				return;
			}
			var h = doc.body.scrollHeight;
			if (h < 150) h = 150;
			frame.style.height = (h + 10) + "px";
		} catch(e) { /* cross-origin, ignore */ }
	});
}

/* Watch iframe content for structural changes only (no attributes/characterData to reduce noise) */
function setupFrameObserver() {
	var frame = document.getElementById("contentFrame");
	try {
		var doc = frame.contentDocument || frame.contentWindow.document;
		if (_frameObserver) _frameObserver.disconnect();
		_frameObserver = new MutationObserver(function() { resizeFrame(); });
		_frameObserver.observe(doc.body, { childList: true, subtree: true, attributes: true, attributeFilter: ["style", "class"] });
	} catch(e) {}
}

function initial() {
	var frame = document.getElementById("contentFrame");
	frame.onload = function() {
		resizeFrame();
		setupFrameObserver();
	};
	/* Restore last tab from localStorage (avoid jumping to WAN on refresh) */
	var lastTab = localStorage.getItem("last_tab") || "status";
	if (lastTab === "printer") lastTab = "more";
	if (!pages[lastTab]) lastTab = "status";
	/* Highlight the correct nav button */
	var navItems = document.querySelectorAll(".nav-item");
	for (var i = 0; i < navItems.length; i++) {
		navItems[i].className = navItems[i].className.replace(" active", "");
	}
	/* Find the button for lastTab */
	for (var j = 0; j < navItems.length; j++) {
		var onclickAttr = navItems[j].getAttribute("onclick") || "";
		if (onclickAttr.indexOf("'" + lastTab + "'") >= 0) {
			navItems[j].className += " active";
			break;
		}
	}
	frame.src = pages[lastTab];
	fetchBridgeStatus();
	setInterval(fetchBridgeStatus, 30000);
}

function showLoading(seconds, msg, noRefresh) {
	var overlay = document.getElementById("loadingOverlay");
	var txt = overlay.querySelector(".loading-text");
	txt.textContent = msg || "正在应用设置，请稍候...";
	overlay.classList.remove("success");
	overlay.style.display = "flex";
	if (seconds) {
		setTimeout(function() {
			/* Switch to success checkmark animation */
			overlay.classList.add("success");
			txt.textContent = "设置成功";
			setTimeout(function() {
				overlay.style.display = "none";
				overlay.classList.remove("success");
				/* Refresh iframe to show new values (skip when noRefresh is true) */
				if (!noRefresh) {
					var frame = document.getElementById("contentFrame");
					if (frame.src) frame.src = frame.src;
				}
			}, 1200);
		}, seconds * 1000);
	}
}

function hideLoading() {
	var overlay = document.getElementById("loadingOverlay");
	overlay.style.display = "none";
	overlay.classList.remove("success");
}

function showToast(msg) {
	var t = document.getElementById("toast");
	t.textContent = msg;
	t.style.display = "block";
	t.style.background = "#c62828";
	setTimeout(function() {
		t.style.display = "none";
	}, 3000);
}

/* ── Password change modal ── */
function openPwdModal() {
	document.getElementById("pwd_old").value = "";
	document.getElementById("pwd_new").value = "";
	document.getElementById("pwd_confirm").value = "";
	document.getElementById("pwdMsg").textContent = "";
	document.getElementById("pwdModal").style.display = "flex";
}
function closePwdModal() {
	document.getElementById("pwdModal").style.display = "none";
}
function submitPwd() {
	var oldPwd = document.getElementById("pwd_old").value;
	var newPwd = document.getElementById("pwd_new").value;
	var confirmPwd = document.getElementById("pwd_confirm").value;
	var msg = document.getElementById("pwdMsg");
	var currentPwd = document.getElementById("http_passwd_current").value;
	if (!oldPwd) { msg.textContent = "请输入当前密码"; return false; }
	if (oldPwd !== currentPwd) { msg.textContent = "当前密码不正确"; return false; }
	if (!newPwd) { msg.textContent = "请输入新密码"; return false; }
	if (newPwd.length < 4) { msg.textContent = "新密码至少 4 位"; return false; }
	if (newPwd !== confirmPwd) { msg.textContent = "两次输入的新密码不一致"; return false; }
	if (newPwd === oldPwd) { msg.textContent = "新密码不能与当前密码相同"; return false; }
	document.getElementById("pwd_new_hidden").value = newPwd;
	closePwdModal();
	if (window.showLoading) showLoading(5, "正在修改密码...");
	return true;
}

/* ── WiFi scan modal (parent-level so overlay dims the whole page) ── */
var wifiScanResults = [];
function openWifiModal() {
	document.getElementById("wifiModalBody").innerHTML = '<div class="scan-empty">点击下方按钮搜索附近 WiFi</div>';
	document.getElementById("wifiScanBtn").disabled = false;
	document.getElementById("wifiScanBtn").innerHTML = "搜索 WiFi";
	document.getElementById("wifiModal").classList.add("show");
}
function closeWifiModal() {
	document.getElementById("wifiModal").classList.remove("show");
}
document.getElementById("wifiModal").addEventListener("click", function(e) {
	if (e.target === this) closeWifiModal();
});
function doScan() {
	var scanBtn = document.getElementById("wifiScanBtn");
	var body = document.getElementById("wifiModalBody");
	scanBtn.disabled = true;
	scanBtn.innerHTML = '<span class="scan-spin"></span>搜索中...';
	body.innerHTML = '<div class="scan-empty"><span class="scan-spin"></span>正在搜索附近的 WiFi...</div>';
	wifiScanResults = [];
	var done = 0, total = has5gRadio ? 2 : 1;
	function checkDone() {
		done++;
		if (done >= total) {
			wifiScanResults.sort(function(a, b) { return (parseInt(b[3]) || 0) - (parseInt(a[3]) || 0); });
			renderWifiList();
		}
	}
	jQuery.ajax({ url: '/wds_aplist_2g.asp', dataType: 'script', timeout: 20000,
		success: function() {
			if (window.wds_aplist_2g && wds_aplist_2g.length > 0) {
				for (var i = 0; i < wds_aplist_2g.length; i++) wifiScanResults.push(wds_aplist_2g[i]);
			}
			checkDone();
		},
		error: function() { checkDone(); }
	});
	if (!has5gRadio) return;
	jQuery.ajax({ url: '/wds_aplist_5g.asp', dataType: 'script', timeout: 20000,
		success: function() {
			if (window.wds_aplist_5g && wds_aplist_5g.length > 0) {
				for (var i = 0; i < wds_aplist_5g.length; i++) wifiScanResults.push(wds_aplist_5g[i]);
			}
			checkDone();
		},
		error: function() { checkDone(); }
	});
}
function renderWifiList() {
	var scanBtn = document.getElementById("wifiScanBtn");
	var body = document.getElementById("wifiModalBody");
	scanBtn.disabled = false;
	scanBtn.innerHTML = "重新搜索 WiFi";
	if (!wifiScanResults || wifiScanResults.length === 0) {
		body.innerHTML = '<div class="scan-empty">未找到 WiFi 网络</div>';
		return;
	}
	var html = "";
	for (var i = 0; i < wifiScanResults.length; i++) {
		var item = wifiScanResults[i];
		var ssid = item[0] || "???";
		var bssid = item[1] || "";
		var channel = parseInt(item[2]) || 0;
		var signal = item[3] || "";
		var sec = item[4] || "";
		var is5g = channel >= 36;
		var bandLabel = is5g ? '<span class="ap-band ap-band-5g">5G</span>' : '<span class="ap-band ap-band-2g">2.4G</span>';
		var bandVal = is5g ? "5g" : "2g";
		html += '<div class="ap-item" onclick="selectAP(\'' + ssid.replace(/'/g, "\\'") + '\', \'' + bandVal + '\', ' + i + ', \'' + (sec ? sec.replace(/'/g, "\\'") : "") + '\')" data-idx="' + i + '">';
		html += '<div class="ap-info"><div class="ap-name">' + decodeSSID(ssid) + bandLabel + '</div>';
		html += '<div class="ap-meta">信道 ' + channel + (bssid ? ' · ' + bssid : '') + (sec ? ' · ' + sec : '') + '</div></div>';
		html += '<div class="ap-signal">' + signal + '</div>';
		html += '</div>';
	}
	body.innerHTML = html;
}
function decodeSSID(s) {
	if (!s || s === "???") return "???";
	try { return decodeURIComponent(s); } catch(e) { return s; }
}
function selectAP(ssid, band, idx, sec) {
	var items = document.querySelectorAll("#wifiModal .ap-item");
	for (var i = 0; i < items.length; i++) {
		items[i].className = items[i].className.replace(" selected", "");
	}
	if (items[idx]) items[idx].className += " selected";
	var decoded;
	try { decoded = decodeURIComponent(ssid); } catch(e) { decoded = ssid; }
	var frame = document.getElementById("contentFrame");
	if (frame && frame.contentWindow && typeof frame.contentWindow.applySelectedAP === "function") {
		frame.contentWindow.applySelectedAP(decoded, band, sec);
	}
	closeWifiModal();
}

function fetchBridgeStatus() {
	var xhr = new XMLHttpRequest();
	xhr.open("GET", "/bridge_status.asp", true);
	xhr.onreadystatechange = function() {
		if (xhr.readyState === 4 && xhr.status === 200) {
			try {
				eval(xhr.responseText);
				if (typeof bridge_status !== "undefined") {
					updateHomeStatus(bridge_status);
				}
			} catch(e) { console.log("bridge status parse error:", e); }
		}
	};
	xhr.send();
}

function updateHomeStatus(s) {
	var strip = document.getElementById("bridgeStatusStrip");
	var activeMode = s.mode === 4 ? 4 : (s.mode5g === 4 ? 4 : 0);
	if (activeMode === 0) {
		strip.style.display = "none";
		return;
	}
	strip.style.display = "flex";
	var activeWisp = s.mode === 4 ? s.wisp : (s.mode5g === 4 ? s.wisp5g : 0);
	/* Display as "客户端" per requirement */
	document.getElementById("hsBridgeMode").textContent = "客户端";
	document.getElementById("hsBridgeBand").textContent = s.upstream_band || "--";
	document.getElementById("hsBridgeSsid").textContent = s.upstream_ssid || "--";
	var conn = document.getElementById("hsBridgeConn");
	if (s.connected) {
		conn.textContent = "已连接";
		conn.className = "ss-value ok";
	} else {
		conn.textContent = "未连接";
		conn.className = "ss-value bad";
	}
	document.getElementById("hsBridgeIp").textContent = s.ipaddr || "--";
}
</script>
</body>
</html>
