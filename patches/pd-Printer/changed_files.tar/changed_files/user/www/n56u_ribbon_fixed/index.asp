<!DOCTYPE html>
<html>
<head>
<title><% nvram_get_x("", "productid"); %> <#Home_TitleSuffix#></title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Expires" content="-1">
<link rel="shortcut icon" href="/bootstrap/img/favicon.ico">
<link rel="icon" href="/bootstrap/img/favicon.png">
<link rel="stylesheet" type="text/css" href="/bootstrap/css/langdrop.css">
<link rel="stylesheet" type="text/css" href="/bootstrap/css/index.css">
<script type="text/javascript" src="/jquery.js"></script>
</head>
<body onload="initial()">
<div class="top-bar">
	<div class="top-left">
		<span class="logo"><% nvram_get_x("", "productid"); %></span>
		<span class="subtitle"><#Home_Subtitle#></span>
	</div>
	<div class="top-right">
		<div class="langdrop" data-langdrop>
			<select id="langSelect">
				<% shown_language_option(); %>
			</select>
		</div>
		<a href="javascript:void(0)" onclick="openPwdModal()"><#Home_ChangePassword#></a>
		<a href="/Logout.asp"><#Home_Logout#></a>
	</div>
</div>
<nav class="nav-bar">
	<button class="nav-item active" onclick="switchTab('status', this)">
		<div class="nav-icon"><svg viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 17.93c-3.95-.49-7-3.85-7-7.93 0-.62.08-1.21.21-1.79L9 15v1c0 1.1.9 2 2 2v1.93zm6.9-2.54c-.26-.81-1-1.39-1.9-1.39h-1v-3c0-.55-.45-1-1-1H8v-2h2c.55 0 1-.45 1-1V7h2c1.1 0 2-.9 2-2v-.41c2.93 1.19 5 4.07 5 7.41 0 2.08-.8 3.97-2.1 5.39z"/></svg></div>
		<span class="nav-label"><#Home_TabStatus#></span>
	</button>
	<button class="nav-item" onclick="switchTab('network', this)">
		<div class="nav-icon"><svg viewBox="0 0 24 24"><path d="M20 18c1.1 0 1.99-.9 1.99-2L22 6c0-1.1-.9-2-2-2H4c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2H0v2h24v-2h-4zM4 6h16v10H4V6z"/></svg></div>
		<span class="nav-label"><#Home_TabNetwork#></span>
	</button>
	<button class="nav-item" onclick="switchTab('wireless', this)">
		<div class="nav-icon"><svg viewBox="0 0 24 24"><path d="M12 21l3.6-4.5c-1-0.8-2.3-1.3-3.6-1.3s-2.6 0.5-3.6 1.3L12 21zm0-9c2.7 0 5.2 1.1 7 2.9l2-2C19 10.8 15.7 9.5 12 9.5S5 10.8 3 12.9l2 2C6.8 13.1 9.3 12 12 12zm0-4c4.2 0 8 1.6 10.9 4.1l2-2.2C21.5 6.8 16.9 5 12 5S2.5 6.8 0 9.9l2 2.2C4.8 9.6 8.6 8 12 8z"/></svg></div>
		<span class="nav-label"><#Home_TabWireless#></span>
	</button>
	<button class="nav-item" onclick="switchTab('more', this)">
		<div class="nav-icon"><svg viewBox="0 0 24 24"><path d="M19.14 12.94c.04-.3.06-.61.06-.94 0-.32-.02-.64-.07-.94l2.03-1.58c.18-.14.23-.41.12-.61l-1.92-3.32c-.12-.22-.37-.29-.59-.22l-2.39.96c-.5-.38-1.03-.7-1.62-.94l-.36-2.54c-.04-.24-.24-.41-.48-.41h-3.84c-.24 0-.43.17-.47.41l-.36 2.54c-.59.24-1.13.57-1.62.94l-2.39-.96c-.22-.08-.47 0-.59.22L2.74 8.87c-.12.21-.08.47.12.61l2.03 1.58c-.05.3-.09.63-.09.94s.02.64.07.94l-2.03 1.58c-.18.14-.23.41-.12.61l1.92 3.32c.12.22.37.29.59.22l2.39-.96c.5.38 1.03.7 1.62.94l.36 2.54c.05.24.24.41.48.41h3.84c.24 0 .44-.17.47-.41l.36-2.54c.59-.24 1.13-.56 1.62-.94l2.39.96c.22.08.47 0 .59-.22l1.92-3.32c.12-.22.07-.47-.12-.61l-2.01-1.58zM12 15.6c-1.98 0-3.6-1.62-3.6-3.6s1.62-3.6 3.6-3.6 3.6 1.62 3.6 3.6-1.62 3.6-3.6 3.6z"/></svg></div>
		<span class="nav-label"><#Home_TabMore#></span>
	</button>
</nav>
<div class="status-strip-wrap">
	<div class="status-strip" id="bridgeStatusStrip" style="display:none;">
		<div class="ss-item" data-hide-mobile><span class="ss-label"><#Home_BridgeMode#></span><span class="ss-value" id="hsBridgeMode">--</span></div>
		<div class="ss-item" data-hide-mobile><span class="ss-label"><#Home_Band#></span><span class="ss-value" id="hsBridgeBand">--</span></div>
		<div class="ss-item" data-hide-mobile><span class="ss-label"><#Home_UpstreamWifi#></span><span class="ss-value" id="hsBridgeSsid">--</span></div>
		<div class="ss-item"><span class="ss-label"><#Home_ConnStatus#></span><span class="ss-value" id="hsBridgeConn">--</span></div>
		<div class="ss-item"><span class="ss-label"><#Home_GetIp#></span><span class="ss-value" id="hsBridgeIp">--</span></div>
	</div>
</div>
<div class="content-wrap">
	<div class="content-card">
		<iframe id="contentFrame" class="content-frame" src="" scrolling="no"></iframe>
	</div>
</div>
<div id="loadingOverlay">
	<div class="loading-box">
		<div class="icon-wrap">
			<div class="spinner"></div>
			<div class="checkmark"><svg viewBox="0 0 52 52"><path d="M14 27 L22 35 L38 17"/></svg></div>
		</div>
		<div class="loading-text"><#Msg_Applying#></div>
	</div>
</div>
<div id="toast"></div>
<div id="pwdModal">
	<div class="pwd-box">
		<div class="pwd-title"><#Home_ChangeMgmtPassword#></div>
		<iframe name="pwd_hidden_frame" id="pwd_hidden_frame" src="" width="0" height="0" frameborder="0"></iframe>
		<form method="post" name="pwdForm" action="/start_apply.htm" target="pwd_hidden_frame" onsubmit="return submitPwd()">
			<div class="pwd-row">
				<label><#Home_CurrentPassword#></label>
				<input type="password" id="pwd_old" autocomplete="off">
			</div>
			<div class="pwd-row">
				<label><#Home_NewPassword#></label>
				<input type="password" id="pwd_new" autocomplete="off">
			</div>
			<div class="pwd-row">
				<label><#Home_ConfirmPassword#></label>
				<input type="password" id="pwd_confirm" autocomplete="off">
			</div>
			<div class="pwd-msg" id="pwdMsg"></div>
			<input type="hidden" name="current_page" value="index.asp">
			<input type="hidden" name="next_page" value="index.asp">
			<input type="hidden" name="next_host" value="">
			<input type="hidden" name="sid_list" value="General;">
			<input type="hidden" name="group_id" value="">
			<input type="hidden" name="action_mode" value=" Apply ">
			<input type="hidden" name="action_script" value="">
			<input type="hidden" name="http_passwd" id="pwd_new_hidden" value="">
			<div class="pwd-btns">
				<button type="button" class="pwd-btn cancel" onclick="closePwdModal()"><#Home_Cancel#></button>
				<button type="submit" class="pwd-btn primary"><#Home_ConfirmChange#></button>
			</div>
		</form>
	</div>
	<input type="hidden" id="http_passwd_current" value="<% nvram_get_x("", "http_passwd"); %>">
</div>
<div id="wifiModal">
	<div class="wifi-box">
		<div class="wifi-head">
			<h4><#Home_SearchWifi#></h4>
			<button type="button" class="wifi-close" onclick="closeWifiModal()">&times;</button>
		</div>
		<div class="wifi-body" id="wifiModalBody">
			<div class="scan-empty"><#Home_ClickToSearchWifi#></div>
		</div>
		<div class="wifi-foot">
			<button type="button" class="wifi-scan-btn" id="wifiScanBtn" onclick="doScan()"><#Home_SearchWifi#></button>
		</div>
	</div>
</div>
<script type="text/javascript" src="/bootstrap/js/index.js"></script>
<script type="text/javascript" src="/bootstrap/js/pub/langdrop.js"></script>
</body>
</html>
