<!DOCTYPE html>
<html>
<head>
<title><#Web_Title#></title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Expires" content="-1">
<link rel="shortcut icon" href="images/favicon.ico">
<link rel="icon" href="images/favicon.png">
<link rel="stylesheet" type="text/css" href="/bootstrap/css/toggle.css">
<script type="text/javascript">
function initial(){
	var xmlhttp;
	try{
		if (window.XMLHttpRequest)
			xmlhttp=new XMLHttpRequest();
		else
			xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}catch (e){
		xmlhttp=null;
	}
	if (xmlhttp != null){
		xmlhttp.onreadystatechange=function(){
			if (xmlhttp.readyState == 4)
				location.replace("/Login.asp");
		};
		xmlhttp.open("HEAD","logout",true,"logout","");
		xmlhttp.send(null);
		setTimeout(function(){ location.replace("/Login.asp"); }, 1000);
	} else {
		location.replace("/Login.asp");
	}
}
</script>
</head>
<body onload="initial()">
<div class="auth-screen">
    <div class="auth-panel auth-center">
        <h2 class="auth-title"><#logoutmessage#></h2>
        <p class="auth-subtitle"><#Not_authpage_login_again#></p>
    </div>
</div>
</body>
</html>