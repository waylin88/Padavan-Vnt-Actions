<!DOCTYPE html>
<html>
<head>
<title><#Web_Title#></title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Expires" content="-1">
<link rel="shortcut icon" href="/bootstrap/img/favicon.ico">
<link rel="icon" href="/bootstrap/img/favicon.png">
<link rel="stylesheet" type="text/css" href="/bootstrap/css/toggle.css">
<link rel="stylesheet" type="text/css" href="/bootstrap/css/langdrop.css">
<script type="text/javascript">
/* Marker for detecting login page when it is (wrongly) loaded inside an iframe */
window.__IS_LOGIN_PAGE__ = true;

/* initial() 依赖请求参数 ?error=1，必须内联，不能外置 */
function initial() {
    var error = '<% get_parameter("error"); %>';
    var errorBox = document.getElementById("loginError");
    var password = document.getElementById("password");

    if (error == "1") {
        errorBox.className = "auth-error visible";
    }
    password.focus();
}
</script>
<script type="text/javascript" src="/bootstrap/js/pub/login.js"></script>
</head>
<body onload="initial()">
<div class="auth-screen">
    <div class="auth-panel">
        <div class="auth-lang">
            <div class="langdrop" data-langdrop>
                <select id="langSelect" aria-label="<#LoginPage_LangAria#>">
                    <% shown_language_option(); %>
                </select>
            </div>
        </div>
        <h1 class="auth-title"><#Web_Title#></h1>
        <p class="auth-subtitle"><#LoginPage_Subtitle#></p>
        <div id="loginError" class="auth-error" role="alert"><#LoginPage_Error#></div>
        <form class="auth-form" method="post" action="Login.asp" autocomplete="on">
            <div class="auth-password-row">
                <input id="password" class="auth-input" name="password" type="password" placeholder="<#LoginPage_PasswordHint#>" aria-label="<#LoginPage_PasswordAria#>" autocomplete="current-password" required>
                <button id="passwordToggle" class="auth-password-toggle" type="button" onclick="togglePassword()"><#LoginPage_Show#></button>
            </div>
            <button class="auth-submit" type="submit"><#Login#></button>
        </form>
        <div class="auth-footer"><#Web_Title#></div>
    </div>
</div>
<script type="text/javascript" src="/bootstrap/js/pub/langdrop.js"></script>
</body>
</html>