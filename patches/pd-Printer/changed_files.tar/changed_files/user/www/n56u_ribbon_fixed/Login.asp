<!DOCTYPE html>
<html>
<head>
<title><#Web_Title#></title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Expires" content="-1">
<link rel="shortcut icon" href="images/favicon.ico">
<link rel="icon" href="images/favicon.png">
<link rel="stylesheet" type="text/css" href="/bootstrap/css/toggle.css">
<script type="text/javascript">
/* Marker for detecting login page when it is (wrongly) loaded inside an iframe */
window.__IS_LOGIN_PAGE__ = true;

function initial() {
    var error = '<% get_parameter("error"); %>';
    var errorBox = document.getElementById("loginError");
    var password = document.getElementById("password");

    if (error == "1") {
        errorBox.className = "auth-error visible";
    }
    password.focus();
}

function togglePassword() {
    var password = document.getElementById("password");
    var button = document.getElementById("passwordToggle");
    if (password.type == "password") {
        password.type = "text";
        button.innerHTML = "隐藏";
    } else {
        password.type = "password";
        button.innerHTML = "显示";
    }
}
</script>
</head>
<body onload="initial()">
<div class="auth-screen">
    <div class="auth-panel">
        <div class="auth-lang">
            <select id="langSelect" class="auth-lang-select" aria-label="语言">
                <option value="cn" selected>简体中文</option>
            </select>
        </div>
        <h1 class="auth-title"><#Web_Title#></h1>
        <p class="auth-subtitle">登录路由器管理页面</p>
        <div id="loginError" class="auth-error" role="alert">密码错误，请重试。</div>
        <form class="auth-form" method="post" action="Login.asp" autocomplete="on">
            <div class="auth-password-row">
                <input id="password" class="auth-input" name="password" type="password" placeholder="请输入登录密码" aria-label="密码" autocomplete="current-password" required>
                <button id="passwordToggle" class="auth-password-toggle" type="button" onclick="togglePassword()">显示</button>
            </div>
            <button class="auth-submit" type="submit"><#Login#></button>
        </form>
        <div class="auth-footer"><#Web_Title#></div>
    </div>
</div>
</body>
</html>