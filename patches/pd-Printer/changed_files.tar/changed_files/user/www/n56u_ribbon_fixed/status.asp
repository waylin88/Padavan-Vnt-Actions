<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="/bootstrap/css/page.css">
<link rel="stylesheet" type="text/css" href="/bootstrap/css/status.css">
</head>
<body>
<div class="container">

<div class="card">
	<h3><#Stat_WanConnectionStatus#><span id="wanPorts" class="port-tags"></span></h3>
	<div id="wanStatus" class="status-grid"></div>
</div>

<div class="card">
	<h3><#Stat_LanStatus#><span id="lanPorts" class="port-tags"></span></h3>
	<div id="lanStatus" class="status-grid"></div>
</div>

<div class="card">
	<h3><#Stat_PrinterStatus#></h3>
	<div class="card-body">
		<div id="printerList"></div>
	</div>
</div>

</div>
<script type="text/javascript" src="/bootstrap/js/status.js"></script>
</body>
</html>
