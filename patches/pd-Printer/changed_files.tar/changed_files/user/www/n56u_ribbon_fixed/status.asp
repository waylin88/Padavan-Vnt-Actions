<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
* { box-sizing: border-box; }
body { margin: 0; padding: 14px 24px; font-family: Arial, "Microsoft YaHei", sans-serif; background: #fff; color: #000; font-size: 14px; }
.container { max-width: 760px; margin: 0 auto; }
.card { background: #fff; border-radius: 8px; padding: 0 0 8px; margin-bottom: 16px; }
.card h3 { margin: 0 0 16px 0; font-size: 16px; color: #000; border-bottom: 1px solid #eee; padding-bottom: 10px; }
.status-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 0; }
.status-item { display: flex; padding: 10px 12px; border-bottom: 1px solid #f0f0f0; }
.status-item .lbl { width: 110px; color: #888; flex-shrink: 0; text-align: right; padding-right: 12px; }
.status-item .val { color: #333; font-weight: 500; word-break: break-all; }
.tag { display: inline-block; padding: 2px 10px; border-radius: 10px; font-size: 12px; }
.tag.ok { background: #e8f5e9; color: #2e7d32; }
.tag.bad { background: #ffebee; color: #c62828; }
.tag.pending { background: #fff3e0; color: #e65100; }
.refresh-row { display: flex; justify-content: flex-end; padding: 8px 12px 0; }
.refresh-btn { background: none; border: 1px solid #ff6a00; color: #ff6a00; padding: 5px 16px; border-radius: 4px; cursor: pointer; font-size: 13px; }
.refresh-btn:hover { background: #fff0e0; }
/* Printer status (replica of printer page) */
.card-body { padding: 0; }
.printer-table { width: 100%; border-collapse: collapse; }
.printer-table th { background: #fafafa; color: #888; font-weight: 500; text-align: center; padding: 10px 12px; border-bottom: 1px solid #f0f0f0; font-size: 13px; }
.printer-table td { padding: 10px 12px; border-bottom: 1px solid #f0f0f0; color: #333; text-align: center; }
.printer-row-sep td { border-bottom: 2px solid #e0e0e0; }
.bidir-switch { position: relative; display: inline-block; width: 40px; height: 22px; }
.bidir-switch input { opacity: 0; width: 0; height: 0; }
.bidir-slider { position: absolute; cursor: pointer; top: 0; left: 0; right: 0; bottom: 0; background: #ccc; border-radius: 22px; transition: .3s; }
.bidir-slider:before { content: ""; position: absolute; height: 16px; width: 16px; left: 3px; bottom: 3px; background: #fff; border-radius: 50%; transition: .3s; }
.bidir-switch input:checked + .bidir-slider { background: #ff6a00; }
.bidir-switch input:checked + .bidir-slider:before { transform: translateX(18px); }
.bidir-switch.disabled .bidir-slider { background: #e0e0e0; cursor: not-allowed; }
.bidir-switch.disabled .bidir-slider:before { background: #f5f5f5; }
.bidir-switch.disabled input:checked + .bidir-slider { background: #bbb; }
.empty { text-align: center; padding: 32px; color: #999; }
.empty .icon { font-size: 36px; display: block; margin-bottom: 8px; }
.printer-mobile { display: none; }
@media (max-width: 600px) {
	body { padding: 10px 10px; }
	.status-grid { grid-template-columns: 1fr; }
	.status-item .lbl { width: 90px; }
	.printer-table { display: none !important; }
	.printer-mobile { display: block !important; }
	.printer-mobile-item { padding: 12px 0; border-bottom: 2px solid #e0e0e0; }
	.printer-mobile-item:last-child { border-bottom: none; }
	.pm-row { display: flex; justify-content: space-between; align-items: center; padding: 6px 0; }
	.pm-label { color: #888; font-size: 13px; flex-shrink: 0; }
	.pm-value { color: #333; font-weight: 500; text-align: right; }
}
</style>
</head>
<body>
<div class="container">

<div class="card">
	<h3>WAN 连接状态</h3>
	<div id="wanStatus" class="status-grid"></div>
	<div class="refresh-row"><button class="refresh-btn" onclick="showStatus()">刷新</button></div>
</div>

<div class="card">
	<h3>LAN 状态</h3>
	<div id="lanStatus" class="status-grid"></div>
</div>

<div class="card">
	<h3>打印机状态</h3>
	<div class="card-body">
		<div id="printerList"></div>
	</div>
</div>

</div>
<script>
<% wanlink(); %>
<% get_usb_ports_info(); %>

/* Bidirectional mode is per physical USB port (nvram lp_bidir<uid>).
 * Keep each port's state client-side so the 15s re-render does not reset switches. */
var g_bidirState = {};

function formatUptime(sec) {
	var s = parseInt(sec);
	if (isNaN(s) || s <= 0) return "0 秒";
	var d = Math.floor(s / 86400);
	var h = Math.floor((s % 86400) / 3600);
	var m = Math.floor((s % 3600) / 60);
	var ss = s % 60;
	var parts = [];
	if (d > 0) parts.push(d + " 天");
	if (h > 0 || d > 0) parts.push(h + " 时");
	if (m > 0 || h > 0 || d > 0) parts.push(m + " 分");
	parts.push(ss + " 秒");
	return parts.join(" ");
}

function showStatus() {
	var status = wanlink_status();
	var ip = wanlink_ip4_wan();
	var gw = wanlink_gw4_wan();
	var dns = wanlink_dns();
	var uptime = wanlink_uptime();
	var type = wanlink_type();
	var typeLow = (type || "").toLowerCase();
	var typeZh = "--";
	if (typeLow.indexOf("pppoe") >= 0 || typeLow.indexOf("ppp") >= 0) typeZh = "宽带拨号";
	else if (typeLow.indexOf("dhcp") >= 0 || typeLow.indexOf("dynamic") >= 0 || typeLow.indexOf("automatic") >= 0 || typeLow.indexOf("auto") >= 0) typeZh = "自动获取";
	else if (typeLow.indexOf("static") >= 0 || typeLow.indexOf("fixed") >= 0) typeZh = "静态地址";
	else if (type === "自动获取" || type === "静态地址" || type === "宽带拨号") typeZh = type;
	else if (type) typeZh = type;

	/* 三态：已连接(0) / 连接中(等待DHCP=5, 等待PPP=6) / 未连接(其他) */
	var up = (status === 0);
	var pending = (status === 5 || status === 6);
	var tag;
	if (up) tag = '<span class="tag ok">已连接</span>';
	else if (pending) tag = '<span class="tag pending">连接中</span>';
	else tag = '<span class="tag bad">未连接</span>';

	/* 未连接或连接中时清除 IP/网关/DNS/时长等旧数据 */
	var ipVal = up && ip && ip !== '---' ? ip : '-';
	var gwVal = up && gw && gw !== '---' ? gw : '-';
	var dnsVal = up && dns && dns !== '---' ? dns : '-';
	var upVal = up ? formatUptime(uptime) : '-';

	var h = '';
	h += '<div class="status-item"><div class="lbl">连接状态</div><div class="val">' + tag + '</div></div>';
	h += '<div class="status-item"><div class="lbl">连接类型</div><div class="val">' + typeZh + '</div></div>';
	h += '<div class="status-item"><div class="lbl">IP 地址</div><div class="val">' + ipVal + '</div></div>';
	h += '<div class="status-item"><div class="lbl">网关</div><div class="val">' + gwVal + '</div></div>';
	h += '<div class="status-item"><div class="lbl">DNS</div><div class="val">' + dnsVal + '</div></div>';
	h += '<div class="status-item"><div class="lbl">在线时长</div><div class="val">' + upVal + '</div></div>';
	document.getElementById("wanStatus").innerHTML = h;

	/* LAN status — AP 模式下 DHCP 服务器由 lan_dhcpd_x 控制（默认关闭），
	 * 路由模式由 dhcp_enable_x 控制（默认启用，仅显式为 "0" 时禁用） */
	var lanIp = "<% nvram_get_x("", "lan_ipaddr"); %>";
	var lanMask = "<% nvram_get_x("", "lan_netmask"); %>";
	var lanMac = "<% nvram_get_x("", "lan_hwaddr"); %>";
	var dhcpText;
	if ("<% nvram_get_x("", "sw_mode"); %>" === "3")
		dhcpText = ("<% nvram_get_x("", "lan_dhcpd_x"); %>" === "1") ? '启用' : '禁用';
	else
		dhcpText = ("<% nvram_get_x("", "dhcp_enable_x"); %>" !== "0") ? '启用' : '禁用';
	var lh = '';
	lh += '<div class="status-item"><div class="lbl">LAN IP</div><div class="val">' + (lanIp || '-') + '</div></div>';
	lh += '<div class="status-item"><div class="lbl">子网掩码</div><div class="val">' + (lanMask || '-') + '</div></div>';
	lh += '<div class="status-item"><div class="lbl">MAC 地址</div><div class="val">' + (lanMac || '-') + '</div></div>';
	lh += '<div class="status-item"><div class="lbl">DHCP</div><div class="val">' + dhcpText + '</div></div>';
	document.getElementById("lanStatus").innerHTML = lh;
}

showStatus();
setInterval(showStatus, 15000);

/* ── Printer status (replica of printer page) ── */
/* Toggle bidirectional printing for one physical port (applied immediately) */
function toggleBidir(uid, enabled) {
	g_bidirState[uid] = enabled ? 1 : 0;
	/* sync desktop + mobile switch of this port only (other ports untouched) */
	var boxes = document.querySelectorAll('.bidir-switch input');
	for (var k = 0; k < boxes.length; k++) {
		if (boxes[k].getAttribute("data-uid") == String(uid))
			boxes[k].checked = enabled;
	}
	var iframe = document.createElement("iframe");
	iframe.name = "bidir_frame";
	iframe.style.display = "none";
	document.body.appendChild(iframe);
	var form = document.createElement("form");
	form.method = "post";
	form.action = "/start_apply.htm";
	form.target = iframe.name;
	form.innerHTML = '<input type="hidden" name="current_page" value="status.asp">'
		+ '<input type="hidden" name="next_page" value="status.asp">'
		+ '<input type="hidden" name="next_host" value="">'
		+ '<input type="hidden" name="sid_list" value="General;">'
		+ '<input type="hidden" name="group_id" value="">'
		+ '<input type="hidden" name="action_mode" value=" Apply ">'
		+ '<input type="hidden" name="action_script" value="">'
		+ '<input type="hidden" name="lp_bidir' + uid + '" value="' + (enabled ? '1' : '0') + '">';
	document.body.appendChild(form);
	form.submit();
}

function renderPrinters() {
	var usbPorts = printer_usbports();
	var models = printer_models();
	var manufs = printer_manufacts();
	var dataPorts = printer_dataports();
	var bidirs = printer_bidirs();
	var el = document.getElementById("printerList");
	if (!usbPorts || usbPorts.length === 0) {
		el.innerHTML = '<div class="empty"><span class="icon">&#128424;</span>未检测到打印机<br><small>请将打印机通过 USB 连接到路由器</small></div>';
		return;
	}
	/* Desktop: table layout */
	var h = '<table class="printer-table">';
	h += '<tr><th>USB端口</th><th>厂商</th><th>型号</th><th>数据端口</th><th>双向</th></tr>';
	for (var i = 0; i < usbPorts.length; i++) {
		var sepClass = (i < usbPorts.length - 1) ? ' class="printer-row-sep"' : '';
		var portNum = usbPorts[i];
		var dataPort = (dataPorts && dataPorts[i]) ? dataPorts[i] : 9100;
		if (g_bidirState[portNum] === undefined)
			g_bidirState[portNum] = (bidirs && bidirs[i]) ? 1 : 0;
		var checkedAttr = g_bidirState[portNum] ? ' checked' : '';
		var bidirId = 'bidir_' + portNum;
		h += '<tr' + sepClass + '>';
		h += '<td>端口' + portNum + '</td>';
		h += '<td>' + (manufs[i] || 'Unknown') + '</td>';
		h += '<td>' + (models[i] || 'Unknown') + '</td>';
		h += '<td>' + dataPort + '</td>';
		h += '<td><label class="bidir-switch"><input type="checkbox" id="' + bidirId + '" data-uid="' + portNum + '"' + checkedAttr + ' onchange="toggleBidir(\'' + portNum + '\', this.checked)"><span class="bidir-slider"></span></label></td>';
		h += '</tr>';
	}
	h += '</table>';
	/* Mobile: vertical card layout */
	h += '<div class="printer-mobile">';
	for (var j = 0; j < usbPorts.length; j++) {
		var mPortNum = usbPorts[j];
		var mDataPort = (dataPorts && dataPorts[j]) ? dataPorts[j] : 9100;
		var mBidirId = 'bidir_m_' + mPortNum;
		if (g_bidirState[mPortNum] === undefined)
			g_bidirState[mPortNum] = (bidirs && bidirs[j]) ? 1 : 0;
		var mCheckedAttr = g_bidirState[mPortNum] ? ' checked' : '';
		h += '<div class="printer-mobile-item">';
		h += '<div class="pm-row"><span class="pm-label">USB端口</span><span class="pm-value">端口' + mPortNum + '</span></div>';
		h += '<div class="pm-row"><span class="pm-label">厂商</span><span class="pm-value">' + (manufs[j] || 'Unknown') + '</span></div>';
		h += '<div class="pm-row"><span class="pm-label">型号</span><span class="pm-value">' + (models[j] || 'Unknown') + '</span></div>';
		h += '<div class="pm-row"><span class="pm-label">数据端口</span><span class="pm-value">' + mDataPort + '</span></div>';
		h += '<div class="pm-row"><span class="pm-label">双向</span><span class="pm-value"><label class="bidir-switch"><input type="checkbox" id="' + mBidirId + '" data-uid="' + mPortNum + '"' + mCheckedAttr + ' onchange="toggleBidir(\'' + mPortNum + '\', this.checked)"><span class="bidir-slider"></span></label></span></div>';
		h += '</div>';
	}
	h += '</div>';
	el.innerHTML = h;
}

renderPrinters();
setInterval(renderPrinters, 15000);
</script>
</body>
</html>
